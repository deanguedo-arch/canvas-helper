# Math 10C Chapter 4 mastery coverage

This matrix describes the canonical blocked review candidate. Practice guides learning and never raises mastery. Each lesson workshop scores its four linked targets together; a stage is credited only by a fully correct, unaided first mathematical check on the named fresh identity. Retention also requires a different browser session at least 48 hours after qualifying transfer.

| Target | Learning target | Lesson | Authored practice IDs | Independent identities | Transfer identities | Retention identities |
|---|---|---:|---|---|---|---|
| C4-41a | Interpret roots | 4.1 | 41a-1, 41a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-41b | Bracket and estimate roots | 4.1 | 41b-1, 41b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-41c | Classify rational and irrational numbers | 4.1 | 41c-1, 41c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-41d | Order real numbers | 4.1 | 41d-1, 41d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-42a | Read radical form | 4.2 | 42a-1, 42a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-42b | Simplify to mixed form | 4.2 | 42b-1, 42b-2, 42b-3 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-42c | Convert to entire form | 4.2 | 42c-1, 42c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-42d | Verify equivalent radicals | 4.2 | 42d-1 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-43a | Product of powers | 4.3 | 43a-1, 43a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-43b | Quotient of powers | 4.3 | 43b-1, 43b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-43c | Zero exponents | 4.3 | 43c-1, 43c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-43d | Coefficients and variables | 4.3 | 43d-1, 43d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-44a | Power of a power | 4.4 | 44a-1, 44a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-44b | Power of a product | 4.4 | 44b-1, 44b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-44c | Power of a quotient | 4.4 | 44c-1, 44c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-44d | Combine exponent laws | 4.4 | 44d-1, 44d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-45a | Interpret a negative exponent | 4.5 | 45a-1, 45a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-45b | Rewrite with positive exponents | 4.5 | 45b-1, 45b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-45c | Simplify rational bases | 4.5 | 45c-1, 45c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-45d | Preserve restrictions | 4.5 | 45d-1, 45d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-46a | Read a rational exponent | 4.6 | 46a-1, 46a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-46b | Convert between forms | 4.6 | 46b-1, 46b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-46c | Evaluate rational exponents | 4.6 | 46c-1, 46c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-46d | Respect the real-number domain | 4.6 | 46d-1, 46d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-47a | Choose a law | 4.7 | 47a-1, 47a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-47b | Simplify multi-step expressions | 4.7 | 47b-1, 47b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-47c | Evaluate exponential models | 4.7 | 47c-1, 47c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-47d | Explain equivalence | 4.7 | 47d-1, 47d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-48a | Connect roots and exponents | 4.8 | 48a-1, 48a-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-48b | Compare solution strategies | 4.8 | 48b-1, 48b-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-48c | Solve an unfamiliar problem | 4.8 | 48c-1, 48c-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |
| C4-48d | Check and communicate | 4.8 | 48d-1, 48d-2 | initial / fresh / fresh2 | transfer / transfer2 | retention / retention2 |

## Shared evidence rules

- Incorrect checks identify the wrong filled fields; blanks are marked without spending a check.
- Checks one through four earn 100%, 75%, 50% or 25% practice credit when eventually correct. Mathematical help lowers practice credit one additional step.
- Supported or corrected success routes to an unused task identity and does not raise mastery.
- First checked work, final correction, check count, help provenance and prior task identities are retained.
- Completion IDs are emitted only after all four lesson targets reach the independent stage.
- Optional textbook work is outside this matrix and outside automated mastery.
