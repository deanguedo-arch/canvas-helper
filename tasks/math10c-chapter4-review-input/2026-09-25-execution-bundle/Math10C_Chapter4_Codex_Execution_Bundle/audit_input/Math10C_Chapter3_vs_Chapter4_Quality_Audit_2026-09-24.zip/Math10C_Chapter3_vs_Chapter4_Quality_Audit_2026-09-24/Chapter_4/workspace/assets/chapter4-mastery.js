(function () {
  "use strict";
  var api = window.Chapter4Checkers;
  var policy = window.Chapter4Policy;
  if (!api || !policy) return;

  var STORAGE_KEY = window.Chapter4Save ? window.Chapter4Save.key("mastery") : "math10c-unit4-pilot:review:v1";
  var STATE_VERSION = "chapter4-review-state-2";
  var SESSION_ID=(function(){try{var id=sessionStorage.getItem(STORAGE_KEY+":session");if(!id){id=Date.now()+"-"+Math.random().toString(36).slice(2);sessionStorage.setItem(STORAGE_KEY+":session",id);}return id;}catch(_){return "memory-"+Date.now();}}());
  var targetMap = {
    "41":["C4-41a","C4-41b","C4-41c","C4-41d"], "42":["C4-42a","C4-42b","C4-42c","C4-42d"],
    "43":["C4-43a","C4-43b","C4-43c","C4-43d"], "44":["C4-44a","C4-44b","C4-44c","C4-44d"],
    "45":["C4-45a","C4-45b","C4-45c","C4-45d"], "46":["C4-46a","C4-46b","C4-46c","C4-46d"],
    "47":["C4-47a","C4-47b","C4-47c","C4-47d"], "48":["C4-48a","C4-48b","C4-48c","C4-48d"]
  };

  function blankState() { return { version:STATE_VERSION, tasks:{}, targetScores:{}, completedIds:[], updatedAt:"" }; }
  function load() {
    try {
      var parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      var migrated=false;
      if(parsed&&parsed.version==="chapter4-review-state-1"){parsed.version=STATE_VERSION;migrated=true;}
      if(parsed&&parsed.version===STATE_VERSION){
        var derivedCompleted=Object.keys(targetMap).filter(function(taskId){return targetMap[taskId].every(function(id){return Number(parsed.targetScores&&parsed.targetScores[id]||0)>=25;});}).map(function(taskId){return "u4-check-"+taskId;});
        if(JSON.stringify(parsed.completedIds||[])!==JSON.stringify(derivedCompleted)){parsed.completedIds=derivedCompleted;migrated=true;}
        Object.keys(parsed.tasks||{}).forEach(function(id){
          var task=parsed.tasks[id], scores=targetMap[id]||[];
          var transferEstablished=scores.length&&scores.every(function(targetId){return Number(parsed.targetScores&&parsed.targetScores[targetId]||0)>=75;});
          var retentionEstablished=scores.length&&scores.every(function(targetId){return Number(parsed.targetScores&&parsed.targetScores[targetId]||0)>=100;});
          if(task&&task.closed&&(task.variant==="transfer"||task.variant==="transfer2")&&transferEstablished&&!retentionEstablished){
            var completedAt=Date.parse(task.finalSubmission&&task.finalSubmission.checkedAt||"");
            if(!Number.isFinite(completedAt))completedAt=Date.now();
            if(!task.retentionAvailableAt){task.retentionAvailableAt=completedAt+policy.RETENTION_DELAY_MS;migrated=true;}
            if(!task.transferSessionId){task.transferSessionId=SESSION_ID;migrated=true;}
            if(task.nextVariant!=="retention"){task.nextVariant="retention";migrated=true;}
          }
        });
        if(migrated){var admission=policy.preflight(parsed);if(admission.allowed)localStorage.setItem(STORAGE_KEY,admission.serialized);}
      }
      return parsed && parsed.version === STATE_VERSION ? parsed : blankState();
    } catch (_) { return blankState(); }
  }
  var state = load();

  function taskState(id) {
    if (!state.tasks[id]) state.tasks[id] = { variant:"initial", answers:{}, checks:0, help:false, supportSources:[], practiceCredit:null, closed:false, firstSubmission:null, finalSubmission:null, lastResult:null, history:[], nextVariant:null };
    if (!state.tasks[id].variant) state.tasks[id].variant="initial";
    if (!Array.isArray(state.tasks[id].history)) state.tasks[id].history=[];
    var scores=targetMap[id]||[];
    var transferEstablished=scores.length&&scores.every(function(targetId){return Number(state.targetScores[targetId]||0)>=75;});
    var retentionEstablished=scores.length&&scores.every(function(targetId){return Number(state.targetScores[targetId]||0)>=100;});
    if (state.tasks[id].closed && (state.tasks[id].variant === "transfer"||state.tasks[id].variant === "transfer2") && transferEstablished && !retentionEstablished) {
      var completedAt=Date.parse(state.tasks[id].finalSubmission&&state.tasks[id].finalSubmission.checkedAt||"");
      if (!Number.isFinite(completedAt)) completedAt=Date.now();
      if (!state.tasks[id].retentionAvailableAt) state.tasks[id].retentionAvailableAt=completedAt+policy.RETENTION_DELAY_MS;
      if (!state.tasks[id].transferSessionId) state.tasks[id].transferSessionId=SESSION_ID;
      state.tasks[id].nextVariant="retention";
    }
    if (state.tasks[id].closed && typeof state.tasks[id].nextVariant === "undefined") {
      var alreadyIndependent=scores.every(function(targetId){return Number(state.targetScores[targetId]||0)>=25;});
      state.tasks[id].nextVariant=alreadyIndependent?"transfer":(state.tasks[id].variant==="initial"?"fresh":null);
    }
    return state.tasks[id];
  }

  function setStatus(message, error) {
    var node = document.getElementById("build-status");
    if (!node) return;
    node.textContent = message;
    node.parentElement.classList.toggle("error", Boolean(error));
  }

  function save() {
    state.updatedAt = new Date().toISOString();
    state.completedIds=Object.keys(targetMap).filter(function(taskId){return targetMap[taskId].every(function(id){return Number(state.targetScores[id]||0)>=25;});}).map(function(taskId){return "u4-check-"+taskId;});
    try {
      var admission=policy.preflight(state);
      if(!admission.allowed){setStatus("Save refused: protected Chapter 4 evidence exceeds "+admission.limit+" characters. The visible draft is retained in this tab.",true);return false;}
      if(admission.compacted)state=admission.state;
      localStorage.setItem(STORAGE_KEY, admission.serialized);
      window.dispatchEvent(new CustomEvent("chapter4:state-changed",{detail:{area:"mastery"}}));
      setStatus(window.Chapter4Save&&window.Chapter4Save.managed?"Current work changed · Brightspace save pending":"Saved in this browser · not submitted", false);
      renderSummary(); renderRetained();
      return true;
    } catch (_) {
      setStatus("Could not save this draft in the browser. No evidence was recorded.", true);
      return false;
    }
  }

  function masteryScore() {
    var sum = Object.keys(state.targetScores).reduce(function (total, id) { return total + Number(state.targetScores[id] || 0); }, 0);
    return sum / 32;
  }
  function renderSummary() {
    var score = masteryScore();
    var count = Object.keys(state.targetScores).filter(function (id) { return Number(state.targetScores[id]) > 0; }).length;
    var scoreNode = document.getElementById("mastery-score");
    var countNode = document.getElementById("mastery-count");
    var bar = document.getElementById("mastery-progress");
    if (scoreNode) scoreNode.textContent = score.toFixed(1) + " of 100";
    if (countNode) countNode.textContent = count + " of 32 targets assessed";
    if (bar) bar.style.width = Math.max(0, Math.min(100, score)) + "%";
    Object.keys(targetMap).forEach(function (taskId) {
      targetMap[taskId].forEach(function (targetId) {
        var row = document.querySelector('[data-target-id="' + targetId + '"] span');
        if (row) row.textContent = state.targetScores[targetId] ? "Independent stage " + state.targetScores[targetId] + "/100" : "Not yet shown";
      });
    });
  }

  function buildField(taskId, name, config, saved) {
    var wrap = document.createElement("div");
    wrap.className = "mastery-field";
    var id = "u4-task-" + taskId + "-" + name;
    var label = document.createElement("label"); label.htmlFor = id; label.textContent = config.label;
    var input;
    if (config.type === "select") {
      input = document.createElement("select");
      config.options.forEach(function (pair) { var option=document.createElement("option"); option.value=pair[0]; option.textContent=pair[1]; input.appendChild(option); });
    } else {
      input = document.createElement("input"); input.type="text"; input.autocomplete="off"; input.maxLength=64; input.placeholder=config.placeholder || "";
    }
    input.id=id; input.dataset.field=name; input.value=saved || "";
    var hint=document.createElement("p"); hint.className="field-hint"; hint.id=id+"-hint"; hint.hidden=true;
    input.addEventListener("input", function () {
      var t=taskState(taskId); t.answers[name]=input.value; input.removeAttribute("aria-invalid"); hint.hidden=true; hint.textContent=""; save();
    });
    wrap.appendChild(label); wrap.appendChild(input);
    if(config.type!=="select"){
      var tools=document.createElement("div");tools.className="mastery-equation-tools";var toolsLabel=document.createElement("span");toolsLabel.textContent="Insert:";tools.appendChild(toolsLabel);
      ["x","y","²","³","√","∛","^","×","−","(",")","/","≠","≥"].forEach(function(symbol){var button=document.createElement("button");button.type="button";button.textContent=symbol;button.setAttribute("aria-label","Insert "+symbol+" in "+config.label);button.addEventListener("click",function(){var start=input.selectionStart==null?input.value.length:input.selectionStart,end=input.selectionEnd==null?start:input.selectionEnd;input.value=input.value.slice(0,start)+symbol+input.value.slice(end);input.focus();input.setSelectionRange(start+symbol.length,start+symbol.length);input.dispatchEvent(new Event("input",{bubbles:true}));});tools.appendChild(button);});
      wrap.appendChild(tools);
    }
    wrap.appendChild(hint); return wrap;
  }

  function applyResult(taskId, result) {
    var section=document.querySelector('[data-chapter4-task="'+taskId+'"]');
    Object.keys(result.fields).forEach(function (name) {
      var input=section.querySelector('[data-field="'+name+'"]');
      var hint=section.querySelector("#"+input.id+"-hint");
      var field=result.fields[name];
      if (field.correct) { input.removeAttribute("aria-invalid"); hint.hidden=true; hint.textContent=""; }
      else {
        input.setAttribute("aria-invalid","true");
        hint.textContent=field.hint || ""; hint.hidden=!field.hint;
      }
    });
  }

  function feedback(taskId, message, status) {
    var node=document.querySelector('[data-chapter4-task="'+taskId+'"] [data-task-feedback]');
    node.hidden=false; node.dataset.status=status; node.textContent=message; node.scrollIntoView({block:"nearest"});
  }

  function check(taskId) {
    var t=taskState(taskId), task=api.getTask(taskId,t.variant);
    if (t.closed) return;
    var result=api.checkTask(taskId,t.answers,t.variant); t.lastResult=result;
    var hasBlank=Object.keys(result.fields).some(function (name) { return result.fields[name].blank; });
    if (hasBlank) {
      t.help=true;
      if (!save()) return;
      applyResult(taskId,result);
      feedback(taskId,"Complete the red fields. Filled answers that need repair include a small hint; blanks do not use a mathematical check.","input");
      updateWorkshop(taskId); return;
    }
    if (!t.firstSubmission) t.firstSubmission={answers:Object.assign({},t.answers),helpBefore:Boolean(t.help),checkedAt:new Date().toISOString()};
    t.checks=Math.min(4,t.checks+1);
    if (!result.correct) {
      t.help=true;
      if (t.checks>=4) t.closed=true;
      if (!save()) return;
      applyResult(taskId,result);
      feedback(taskId,t.closed?"Fourth check used. Your work is retained with no practice credit; use repair before a different fresh demonstration.":"Check "+t.checks+" of 4: repair the red answers, then check this task again.","incorrect");
      updateWorkshop(taskId); return;
    }
    var step=Math.min(3,(t.checks-1)+(t.help?1:0));
    t.practiceCredit=[100,75,50,25][step]; t.closed=true; t.finalSubmission={answers:Object.assign({},t.answers),checkedAt:new Date().toISOString()};
    var priorScores={}; targetMap[taskId].forEach(function(id){priorScores[id]=state.targetScores[id];});
    var unaidedFirst=t.checks===1&&!t.help;
    var priorIndependent=targetMap[taskId].every(function(id){return Number(state.targetScores[id]||0)>=25;});
    var stageMessage="";
    if (unaidedFirst && (t.variant==="retention"||t.variant==="retention2") && targetMap[taskId].every(function(id){return Number(state.targetScores[id]||0)>=75;})) {
      targetMap[taskId].forEach(function(id){state.targetScores[id]=100;});
      stageMessage="Later-session retention established stage 100 for these four targets.";
      t.nextVariant=null;
    } else if (unaidedFirst && (t.variant==="transfer"||t.variant==="transfer2") && priorIndependent) {
      targetMap[taskId].forEach(function(id){state.targetScores[id]=Math.max(Number(state.targetScores[id]||0),75);});
      stageMessage="Changed-form transfer established stage 75 for these four targets. Retention remains locked until a later session after 48 hours.";
      t.retentionAvailableAt=Date.now()+policy.RETENTION_DELAY_MS; t.transferSessionId=SESSION_ID; t.nextVariant="retention";
    } else if (unaidedFirst) {
      targetMap[taskId].forEach(function(id){state.targetScores[id]=Math.max(Number(state.targetScores[id]||0),25);});
      stageMessage="Fresh unaided first-check evidence established the independent stage for these four targets.";
      t.nextVariant="transfer";
    } else {
      stageMessage="This supported or corrected success is retained as practice. A different fresh task is still required for independent mastery.";
      t.nextVariant=t.variant==="initial"?"fresh":(t.variant==="fresh"?"fresh2":(t.variant==="transfer"?"transfer2":(t.variant==="retention"?"retention2":null)));
      if(!t.nextVariant)stageMessage+=" No unused in-course task remains at this stage; the retained evidence is ready for teacher review.";
    }
    if (!save()) { t.practiceCredit=null; t.closed=false; targetMap[taskId].forEach(function(id){if(priorScores[id]==null)delete state.targetScores[id];else state.targetScores[id]=priorScores[id];}); return; }
    applyResult(taskId,result);
    feedback(taskId,"Correct · "+t.practiceCredit+"% practice credit. "+stageMessage,"correct");
    updateWorkshop(taskId);
  }

  function useHelp(taskId) {
    var t=taskState(taskId); if(t.closed)return; t.help=true;
    if(!save())return;
    var current=api.getTask(taskId,t.variant), candidates=[];
    if(t.lastResult)Object.keys(t.lastResult.fields).forEach(function(name){if(!t.lastResult.fields[name].correct&&t.answers[name])candidates.push(name);});
    if(!candidates.length)candidates=[Object.keys(current.fields)[0]];
    var guidance=candidates.slice(0,2).map(function(name){return current.fields[name].label+": "+current.fields[name].hint;}).join(" ");
    feedback(taskId,"Focused repair: "+guidance+" Your answers are preserved. Correcting this task can still earn reduced practice credit; independent mastery will require a different fresh task.","equivalent");
    updateWorkshop(taskId);
  }

  function recordSupport(taskId,source) {
    if(!targetMap[taskId])return false;
    var t=taskState(taskId);if(t.closed)return false;
    t.help=true;if(!Array.isArray(t.supportSources))t.supportSources=[];
    if(t.supportSources.indexOf(source)<0)t.supportSources.push(source);
    if(!save())return false;
    feedback(taskId,"Learning support recorded: "+source+". Your draft remains here. Correct work can still earn practice credit; independent mastery will use a different fresh task.","equivalent");
    updateWorkshop(taskId);return true;
  }

  function startNext(taskId) {
    var t=taskState(taskId); if(!t.closed||!t.nextVariant)return;
    if((t.nextVariant==="retention"||t.nextVariant==="retention2")&&!policy.retentionAdmission(t,Date.now(),SESSION_ID).allowed)return;
    t.history.push({variant:t.variant,checks:t.checks,help:t.help,supportSources:(t.supportSources||[]).slice(),practiceCredit:t.practiceCredit,firstSubmission:t.firstSubmission,finalSubmission:t.finalSubmission});
    t.variant=t.nextVariant; t.answers={}; t.checks=0; t.help=false; t.supportSources=[]; t.practiceCredit=null; t.closed=false; t.firstSubmission=null; t.finalSubmission=null; t.lastResult=null; t.nextVariant=null;
    if(!save())return;
    var section=document.querySelector('[data-chapter4-task="'+taskId+'"]');
    var old=section.querySelector(".mastery-workshop"); if(old)old.remove();
    renderWorkshop(section); section.querySelector(".mastery-workshop h3").focus();
  }

  function updateWorkshop(taskId) {
    var t=taskState(taskId), section=document.querySelector('[data-chapter4-task="'+taskId+'"]');
    if(!section)return;
    section.querySelectorAll("input,select").forEach(function(input){input.disabled=t.closed;});
    section.querySelector("[data-check-task]").disabled=t.closed;
    section.querySelector("[data-help-task]").disabled=t.closed;
    var next=section.querySelector("[data-next-task]");
    var retention=(t.nextVariant==="retention"||t.nextVariant==="retention2")?policy.retentionAdmission(t,Date.now(),SESSION_ID):null;
    next.hidden=!(t.closed&&t.nextVariant); next.disabled=!(t.closed&&t.nextVariant)||(retention&&!retention.allowed);
    if(t.nextVariant==="fresh")next.textContent="Start a different fresh task";
    if(t.nextVariant==="fresh2")next.textContent="Try another unused fresh task";
    if(t.nextVariant==="transfer")next.textContent=targetMap[taskId].every(function(id){return Number(state.targetScores[id]||0)>=25;})?"Start changed-form transfer":"Try another fresh task";
    if(t.nextVariant==="transfer2")next.textContent="Start a different changed-form transfer";
    if(t.nextVariant==="retention")next.textContent=retention.allowed?"Start later-session retention":retention.reason;
    if(t.nextVariant==="retention2")next.textContent=retention.allowed?"Start a different later-session task":retention.reason;
    var meta=section.querySelector("[data-task-meta]");
    meta.textContent="Task identity: 4."+taskId.slice(1)+"-"+t.variant+" · "+(t.practiceCredit!=null?"Practice credit: "+t.practiceCredit+"%. ":"")+"Mathematical checks used: "+t.checks+" of 4"+(t.help?" · support used":"");
    if(t.lastResult)applyResult(taskId,t.lastResult);
  }

  function renderWorkshop(section) {
    var taskId=section.dataset.chapter4Task, t=taskState(taskId), config=api.getTask(taskId,t.variant);
    var wrap=document.createElement("div"); wrap.className="mastery-workshop";
    var title=document.createElement("h3"); title.textContent=config.title;
    var prompt=document.createElement("p"); prompt.className="mastery-prompt"; prompt.textContent=config.prompt;
    var fields=document.createElement("div"); fields.className="mastery-fields";
    Object.keys(config.fields).forEach(function(name){fields.appendChild(buildField(taskId,name,config.fields[name],t.answers[name]));});
    var actions=document.createElement("div"); actions.className="actions";
    var checkButton=document.createElement("button"); checkButton.type="button"; checkButton.className="button"; checkButton.dataset.checkTask=""; checkButton.textContent="Check this task"; checkButton.addEventListener("click",function(){check(taskId);});
    var helpButton=document.createElement("button"); helpButton.type="button"; helpButton.className="button secondary"; helpButton.dataset.helpTask=""; helpButton.textContent="Focused repair"; helpButton.addEventListener("click",function(){useHelp(taskId);});
    var nextButton=document.createElement("button"); nextButton.type="button"; nextButton.className="button secondary"; nextButton.dataset.nextTask=""; nextButton.hidden=true; nextButton.addEventListener("click",function(){startNext(taskId);});
    var meta=document.createElement("p"); meta.className="small"; meta.dataset.taskMeta="";
    var result=document.createElement("div"); result.className="feedback"; result.dataset.taskFeedback=""; result.setAttribute("role","status"); result.hidden=true;
    actions.appendChild(checkButton); actions.appendChild(helpButton); actions.appendChild(nextButton); wrap.appendChild(title); wrap.appendChild(prompt); wrap.appendChild(fields); wrap.appendChild(actions); wrap.appendChild(meta); wrap.appendChild(result); section.appendChild(wrap);
    updateWorkshop(taskId);
  }

  function renderRetained() {
    var root=document.getElementById("retained-work-list"); if(!root)return; root.textContent="";
    var ids=Object.keys(state.tasks).filter(function(id){var t=state.tasks[id];return t.firstSubmission||Object.values(t.answers||{}).some(Boolean);}).sort();
    if(!ids.length){var empty=document.createElement("p");empty.textContent="No Chapter 4 workshop work has been retained in this browser.";root.appendChild(empty);return;}
    ids.forEach(function(id){var t=state.tasks[id], details=document.createElement("details"), summary=document.createElement("summary");summary.textContent="Lesson 4."+id.slice(1)+" · "+(t.practiceCredit!=null?t.practiceCredit+"% practice credit":"draft retained");details.appendChild(summary);
      var first=document.createElement("p");first.textContent="Current task "+t.variant+" · first checked work: "+(t.firstSubmission?JSON.stringify(t.firstSubmission.answers):"not checked");
      var final=document.createElement("p");final.textContent="Latest retained work: "+JSON.stringify(t.answers||{});
      var support=document.createElement("p");support.textContent="Support before completion: "+(t.help?"yes":"no")+" · mathematical checks: "+t.checks+(t.supportSources&&t.supportSources.length?" · sources: "+t.supportSources.join(", "):"");
      details.appendChild(first);details.appendChild(final);details.appendChild(support);
      (t.history||[]).forEach(function(item){var prior=document.createElement("p");prior.textContent="Prior "+item.variant+" task · first check: "+(item.firstSubmission?JSON.stringify(item.firstSubmission.answers):"not checked")+" · final work: "+(item.finalSubmission?JSON.stringify(item.finalSubmission.answers):JSON.stringify(item.answers))+" · "+(item.practiceCredit==null?"no credit":item.practiceCredit+"% practice credit")+(item.supportSources&&item.supportSources.length?" · support: "+item.supportSources.join(", "):"");details.appendChild(prior);});root.appendChild(details);
    });
  }

  document.querySelectorAll("[data-chapter4-task]").forEach(renderWorkshop);
  renderSummary(); renderRetained(); setStatus(window.Chapter4Save&&window.Chapter4Save.managed?"Brightspace course state restored · not submitted":"Saved in this browser · not submitted",false);
  window.Chapter4MasteryReview={getState:function(){return JSON.parse(JSON.stringify(state));},recordSupport:recordSupport,storageKey:STORAGE_KEY};
}());
