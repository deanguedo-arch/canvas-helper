(function (root, factory) {
  var api=factory();
  if(typeof module==="object"&&module.exports)module.exports=api;
  root.Chapter4Policy=api;
}(typeof globalThis!=="undefined"?globalThis:this,function(){
  "use strict";
  var RETENTION_DELAY_MS=48*60*60*1000;
  var MAX_APPLICATION_CHARS=52000;
  function retentionAdmission(record,now,sessionId){
    if(!record||!record.retentionAvailableAt||!record.transferSessionId)return {allowed:false,reason:"Complete qualifying transfer evidence first."};
    if(String(sessionId||"")===String(record.transferSessionId))return {allowed:false,reason:"Return in a later browser session after the waiting period."};
    if(Number(now)<Number(record.retentionAvailableAt))return {allowed:false,reason:"Retention opens after "+new Date(record.retentionAvailableAt).toLocaleString()+"."};
    return {allowed:true,reason:"Retention task available."};
  }
  function compact(state){
    var copy=JSON.parse(JSON.stringify(state));
    Object.keys(copy.tasks||{}).forEach(function(id){
      var task=copy.tasks[id];
      if(task&&task.closed)delete task.lastResult;
      (task&&task.history||[]).forEach(function(item){
        if(item.answers&&item.finalSubmission&&item.finalSubmission.answers&&JSON.stringify(item.answers)===JSON.stringify(item.finalSubmission.answers))delete item.answers;
      });
    });
    return copy;
  }
  function preflight(state){
    var serialized=JSON.stringify(state);
    var compactedState=compact(state), compacted=JSON.stringify(compactedState);
    if(compacted.length<serialized.length)return {allowed:compacted.length<=MAX_APPLICATION_CHARS,characters:compacted.length,limit:MAX_APPLICATION_CHARS,serialized:compacted,state:compactedState,compacted:true};
    return {allowed:serialized.length<=MAX_APPLICATION_CHARS,characters:serialized.length,limit:MAX_APPLICATION_CHARS,serialized:serialized,state:state,compacted:false};
  }
  return {RETENTION_DELAY_MS:RETENTION_DELAY_MS,MAX_APPLICATION_CHARS:MAX_APPLICATION_CHARS,retentionAdmission:retentionAdmission,compact:compact,preflight:preflight};
}));
