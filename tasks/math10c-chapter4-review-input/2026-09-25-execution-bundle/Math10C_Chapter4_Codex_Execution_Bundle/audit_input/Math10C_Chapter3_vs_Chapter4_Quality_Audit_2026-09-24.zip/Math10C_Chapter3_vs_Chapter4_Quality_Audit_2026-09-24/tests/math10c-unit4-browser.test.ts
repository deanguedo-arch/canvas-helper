import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { chromium, type Browser, type Page } from '@playwright/test';

const root = path.resolve(process.cwd(), 'projects/math10c-unit4-pilot/workspace');
const mime: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.json': 'application/json'
};

let browser: Browser;
let baseUrl = '';
const server = createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url || '/', 'http://localhost').pathname);
    const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\//, '');
    if (relative.split('/').includes('..')) throw new Error('invalid path');
    const file = path.resolve(root, relative);
    if (!file.startsWith(root + path.sep) && file !== path.join(root, 'index.html')) throw new Error('invalid path');
    const bytes = await readFile(file);
    response.setHeader('Content-Type', mime[path.extname(file)] || 'application/octet-stream');
    response.end(bytes);
  } catch {
    response.statusCode = 404;
    response.end('Not found');
  }
});

test.before(async () => {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  assert.ok(address && typeof address === 'object');
  baseUrl = `http://127.0.0.1:${address.port}/index.html`;
  browser = await chromium.launch({ headless: true });
});
test.after(async () => { await browser.close(); server.close(); });

async function cleanPage(): Promise<Page> {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(baseUrl, { waitUntil: 'load' });
  return page;
}

test('all 22 learner routes render one page with working navigation', async () => {
  const page = await cleanPage();
  const routes = [
    'u4-overview','u4-ready','u4-41','u4-42','u4-43','u4-44','u4-45','u4-46','u4-47','u4-48',
    'u4-practice','u4-mixed','u4-errors','u4-review','u4-reference','u4-radical-lab','u4-exponent-lab',
    'u4-vocab','u4-resources','u4-work','u4-support-library'
  ];
  for (const route of routes) {
    assert.ok(await page.locator(`a[href="#${route}"]`).count(), `${route} needs a navigation link`);
    await page.evaluate((id) => { window.location.hash = id; }, route);
    await page.waitForFunction((id) => {
      const node = document.getElementById(id);
      return Boolean(node && !node.hidden);
    }, route);
    assert.equal(await page.locator(`#${route}`).isVisible(), true, `${route} should be visible`);
    assert.equal(await page.locator('main .course-page:visible').count(), 1, `${route} should be the only visible page`);
    assert.ok((await page.locator(`#${route} h1`).first().innerText()).trim().length > 3);
  }
  assert.equal((await page.locator('.guided-practice').count()) >= 8, true);
  assert.equal((await page.locator('.misconception').count()) >= 5, true);
  assert.equal(await page.locator('.support-library details').count(), 8);
  await page.context().close();
});

test('practice diagnoses, retains, recommends, and never raises mastery', async () => {
  const page = await cleanPage();
  await page.goto(baseUrl + '#u4-practice');
  assert.equal(await page.locator('#practice-set .practice-card').count(), 5);
  const first = page.locator('#practice-set .practice-card').first();
  const answer = first.locator('input');
  await first.getByRole('button', { name: 'Check answer' }).click();
  assert.match(await first.locator('[role="status"]').innerText(), /blank does not use a check/i);
  await answer.fill('15');
  await first.getByRole('button', { name: 'Check answer' }).click();
  assert.equal(await answer.getAttribute('aria-invalid'), 'true');
  assert.match(await first.locator('[role="status"]').innerText(), /check 1 of 4/i);
  await answer.fill('14');
  await first.getByRole('button', { name: 'Check answer' }).click();
  assert.match(await first.locator('[role="status"]').innerText(), /correct/i);
  assert.match(await page.locator('#practice-recommendation').innerText(), /Lesson 4\.1/i);
  assert.match(await page.locator('#mastery-score').innerText(), /^0\.0/);
  await page.reload();
  assert.equal(await page.locator('#practice-set .practice-card').first().locator('input').inputValue(), '14');
  assert.match(await page.locator('#practice-set .practice-card').first().locator('[role="status"]').innerText(), /retained/i);
  await page.context().close();
});

test('first-check mastery, supported repair, completed IDs, and retained work are truthful', async () => {
  const page = await cleanPage();
  await page.goto(baseUrl + '#u4-41');
  const task41 = await page.evaluate(() => {
    const task = (window as any).Chapter4Checkers.getTask('41', 'initial');
    return Object.fromEntries(Object.entries(task.fields).map(([name, config]: [string, any]) => [name, config.answers[0]]));
  });
  for (const [name, value] of Object.entries(task41)) {
    const field = page.locator(`#u4-task-41-${name}`);
    if (await field.evaluate((node) => node.tagName === 'SELECT')) await field.selectOption(String(value));
    else await field.fill(String(value));
  }
  await page.locator('[data-chapter4-task="41"] [data-check-task]').click();
  assert.match(await page.locator('[data-chapter4-task="41"] [data-task-feedback]').innerText(), /100% practice credit.*independent stage/i);
  assert.match(await page.locator('#mastery-score').innerText(), /^3\.1/);
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('math10c-unit4-pilot:review:v1') || '{}'));
  assert.deepEqual(stored.completedIds, ['u4-check-41']);

  await page.goto(baseUrl + '#u4-42');
  const section = page.locator('[data-chapter4-task="42"]');
  await section.locator('#u4-task-42-coefficient').fill('99');
  await section.locator('[data-check-task]').click();
  assert.match(await section.locator('[data-task-feedback]').innerText(), /Complete the red fields/i);
  const stateAfterBlank = await page.evaluate(() => (window as any).Chapter4MasteryReview.getState().tasks['42']);
  assert.equal(stateAfterBlank.checks, 0);
  assert.equal(stateAfterBlank.help, true);
  assert.equal(await section.locator('#u4-task-42-coefficient').getAttribute('aria-invalid'), 'true');
  assert.equal(await section.locator('#u4-task-42-index').getAttribute('aria-invalid'), 'true');
  assert.equal(await section.locator('#u4-task-42-coefficient-hint').isVisible(), true);
  assert.equal(await section.locator('#u4-task-42-index-hint').isVisible(), false);

  const task42 = await page.evaluate(() => {
    const task = (window as any).Chapter4Checkers.getTask('42', 'initial');
    return Object.fromEntries(Object.entries(task.fields).map(([name, config]: [string, any]) => [name, config.answers[0]]));
  });
  for (const [name, value] of Object.entries(task42)) await section.locator(`#u4-task-42-${name}`).fill(String(value));
  await section.locator('[data-check-task]').click();
  assert.match(await section.locator('[data-task-feedback]').innerText(), /75% practice credit.*different fresh task/i);
  assert.match(await page.locator('#mastery-score').innerText(), /^3\.1/);
  assert.equal(await section.locator('[data-next-task]').isVisible(), true);
  await section.locator('[data-next-task]').click();
  assert.match(await section.locator('[data-task-meta]').innerText(), /4\.2-fresh/);
  await page.goto(baseUrl + '#u4-work');
  await page.locator('#retained-work-list details').first().locator('summary').click();
  assert.match(await page.locator('#retained-work-list').innerText(), /first checked work:.*latest retained work:/is);
  await page.context().close();
});

test('radical and exponent labs respond and the mobile course does not overflow', async () => {
  const page = await cleanPage();
  await page.goto(baseUrl + '#u4-radical-lab');
  await page.locator('#radical-coefficient').fill('2');
  await page.locator('#radical-index').selectOption('3');
  await page.locator('#radical-radicand').fill('5');
  await page.locator('#radical-build').click();
  assert.match(await page.locator('#radical-output').innerText(), /2∛5.*∛40/s);
  await page.goto(baseUrl + '#u4-exponent-lab');
  await page.locator('#law-first').fill('5');
  await page.locator('#law-operation').selectOption('quotient');
  await page.locator('#law-second').fill('3');
  await page.locator('#law-build').click();
  assert.match(await page.locator('#law-output').innerText(), /subtract.*x5.*x3.*x2.*x ≠ 0/is);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(baseUrl + '#u4-44');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  assert.ok(overflow <= 1, `mobile horizontal overflow was ${overflow}px`);
  assert.equal(await page.locator('#menu-button').isVisible(), true);
  await page.context().close();
});
