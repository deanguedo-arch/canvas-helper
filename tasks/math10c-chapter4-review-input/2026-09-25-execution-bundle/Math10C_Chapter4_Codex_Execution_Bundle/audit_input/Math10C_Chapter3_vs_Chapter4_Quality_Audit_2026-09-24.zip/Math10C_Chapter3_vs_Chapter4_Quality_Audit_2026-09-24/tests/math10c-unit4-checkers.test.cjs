const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const checkerPath = path.resolve(__dirname, '../../projects/math10c-unit4-pilot/workspace/assets/chapter4-checkers.js');
const sandbox = {};
sandbox.globalThis = sandbox;
vm.runInNewContext(fs.readFileSync(checkerPath, 'utf8'), sandbox, { filename: checkerPath });
const { normalize, tasks, checkTask } = sandbox.Chapter4Checkers;
const { variants, getTask } = sandbox.Chapter4Checkers;

const correct = {
  '41': { exact:'12', lower:'8', upper:'9', classify:'irrational', order:'7, √50, 8' },
  '42': { coefficient:'3', index:'3', radicand:'54', mixed:'5√3', entire:'√28' },
  '43': { product:'x^11', quotient:'y⁶', zero:'1', restriction:'a ≠ 0', combined:'4x³y²' },
  '44': { power:'x¹²', product:'8x³y⁶', quotient:'9x²/4', combined:'x⁷y' },
  '45': { reciprocal:'1/x⁴', rewrite:'3y/x²', evaluate:'9/4', restriction:'x != 0' },
  '46': { square:'9', cube:'9', radical:'4rt(x^3)', domain:'no' },
  '47': { law:'powerofapower', simplify:'4x', model:'48', invalid:'addition' },
  '48': { length:'5', exponent:'125^(1/3)', operation:'cuberoot', unit:'cm' }
};

assert.equal(Object.keys(tasks).length, 8);
for (const [id, answers] of Object.entries(correct)) {
  const result = checkTask(id, answers);
  assert.equal(result.correct, true, `task ${id} should accept its reviewed answer set`);
  const first = Object.keys(tasks[id].fields)[0];
  const wrong = { ...answers, [first]: 'definitely wrong' };
  const wrongResult = checkTask(id, wrong);
  assert.equal(wrongResult.correct, false, `task ${id} should reject a wrong component`);
  assert.equal(wrongResult.fields[first].correct, false);
  const incomplete = { ...answers, [first]: '' };
  const incompleteResult = checkTask(id, incomplete);
  assert.equal(incompleteResult.fields[first].blank, true);
  assert.equal(incompleteResult.fields[first].hint, '');
}

for (const id of Object.keys(tasks)) {
  for (const variant of ['fresh', 'fresh2', 'transfer', 'transfer2', 'retention', 'retention2']) {
    const task = getTask(id, variant);
    const answers = Object.fromEntries(Object.entries(task.fields).map(([name, config]) => [name, config.answers[0]]));
    assert.equal(checkTask(id, answers, variant).correct, true, `${id}/${variant} should accept its reviewed answer set`);
    assert.ok(task.prompt.length > 30, `${id}/${variant} needs a substantive prompt`);
  }
}

assert.equal(normalize(' 4 × x³ y² '), '4*x^3y^2');
assert.equal(checkTask('43', correct['43']).fields.restriction.correct, true);
assert.equal(checkTask('42', correct['42']).fields.mixed.correct, true);
console.log('Math 10C Chapter 4 checker tests passed: 8 initial tasks, 48 versioned variants, wrong/incomplete cases, normalization variants.');
