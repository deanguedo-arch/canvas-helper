This archive is for an independent Chapter 3 versus Chapter 4 quality audit.

Open `00_CHATGPT_AUDIT_REQUEST.md` first. The two `workspace/index.html` files are the learner entrypoints. Generated exports and raw/private source archives are intentionally excluded.
