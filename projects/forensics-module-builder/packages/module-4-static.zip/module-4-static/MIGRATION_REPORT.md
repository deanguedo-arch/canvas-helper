# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-4\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 4
- Title: 4 Body Fluid Evidence
- Quiz: quiz-4
- Quiz answer key: B C D D A A C A A D B C D C C A B B B D C C D D B A A
- Assignment: assignment-4

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module4assignment.html`

## Assignment assets copied

- `module4/blood-spill.jpg`
- `module4/stairs.jpg`
- `module4/tammy-parrot-comic.png`

## Image paths rewritten

- Local images copied: 28
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iaa3f78e9-0e4d-4433-9909-e9f94598ef9b\Content\Blood from the Heart.jpg -> assets/images/module-4-image-01.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iaa3f78e9-0e4d-4433-9909-e9f94598ef9b\Content\Frog_Blood_40x_LF_7.jpg -> assets/images/module-4-image-02.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iaa3f78e9-0e4d-4433-9909-e9f94598ef9b\Content\Red Blood Cells Human.jpg -> assets/images/module-4-image-03.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2ce3b936-b6db-4d86-9174-1bfa407805e8\Content\Blood Typing.jpg -> assets/images/module-4-image-04.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i3e9bc723-a8fd-4f14-a0c8-b8ba53d493a5\Content\Blood Evidence.jpg -> assets/images/module-4-image-05.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ic503e56b-480c-4035-8911-fd2e03231c0a\Content\Blood Evidence Scene.jpg -> assets/images/module-4-image-06.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i205ddaa3-0c3e-4015-b814-bcfd45b83422\Content\luminol.jpg -> assets/images/module-4-image-07.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i205ddaa3-0c3e-4015-b814-bcfd45b83422\Content\Phenol.jpg -> assets/images/module-4-image-08.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ic6856f52-3e5a-447d-8054-f101d18b7e83\Content\luminol (1).jpg -> assets/images/module-4-image-09.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7be4c40f-f204-43dd-abe1-ab2d1ce0d168\Content\Blood Drop on Glass.jpg -> assets/images/module-4-image-10.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7be4c40f-f204-43dd-abe1-ab2d1ce0d168\Content\blood stain surface.PNG -> assets/images/module-4-image-11.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7be4c40f-f204-43dd-abe1-ab2d1ce0d168\Content\bloodstain direction.PNG -> assets/images/module-4-image-12.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7be4c40f-f204-43dd-abe1-ab2d1ce0d168\Content\blood angle.PNG -> assets/images/module-4-image-13.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7be4c40f-f204-43dd-abe1-ab2d1ce0d168\Content\blood origin.PNG -> assets/images/module-4-image-14.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7be4c40f-f204-43dd-abe1-ab2d1ce0d168\Content\blood origin2.PNG -> assets/images/module-4-image-15.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\id48e1acc-4b2a-454b-90ea-2b6e674c34b7\Content\Body Fluid Collections.jpg -> assets/images/module-4-image-16.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i3797c9c5-f2ad-4efa-85f5-b8076db01e9f\Content\sperm.PNG -> assets/images/module-4-image-17.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i3797c9c5-f2ad-4efa-85f5-b8076db01e9f\Content\sperm2.PNG -> assets/images/module-4-image-18.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\idb2aad29-9fb4-49f3-b708-a4ab6cc8f3f7\Content\Case Studies.jpg -> assets/images/module-4-image-19.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\if2691d26-8a13-400b-a2a9-5f2ce94b6451\hallway.png -> assets/images/module-4-image-20.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ia99eccc6-303b-41ad-b23c-79a8ac38bb7a\Content\Parrot in Cage.jpg -> assets/images/module-4-image-21.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6225ab1a-cfcc-4c23-9234-75205f061981\phil case.png -> assets/images/module-4-image-22.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i828a8600-f807-4ec3-bb74-0b84f53999f5\Content\Red Blood Cells.PNG -> assets/images/module-4-image-23.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i828a8600-f807-4ec3-bb74-0b84f53999f5\Content\White Blood Cells.PNG -> assets/images/module-4-image-24.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i828a8600-f807-4ec3-bb74-0b84f53999f5\Content\platelets.PNG -> assets/images/module-4-image-25.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i828a8600-f807-4ec3-bb74-0b84f53999f5\Content\Bone Marrow.PNG -> assets/images/module-4-image-26.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i828a8600-f807-4ec3-bb74-0b84f53999f5\Content\blood plasma.PNG -> assets/images/module-4-image-27.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\karl-landsteiner.jpg -> assets/images/module-4-image-28.jpg

## External URLs found

- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r22
- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r23
- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r27
- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r3
- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r36
- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r6
- http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842/c-g/c-g01-eng.gif
- https://i.ytimg.com/vi/2aPz_AV0t3U/hqdefault.jpg
- https://www.youtube.com/embed/8OtzP9_a_sU?wmode=opaque&amp;rel=0

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
