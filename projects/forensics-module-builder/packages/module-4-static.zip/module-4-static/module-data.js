const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 4
  },
  "chapter": {
    "id": "chapter-4",
    "title": "4 Body Fluid Evidence",
    "code": "Module 4",
    "summary": "Review body-fluid evidence, serology methods, and how investigators interpret blood evidence at crime scenes.",
    "componentCount": 23
  },
  "quiz": {
    "id": "quiz-4",
    "title": "M4 Body Fluid Evidence Assessment",
    "multipleChoice": [
      {
        "number": 1,
        "prompt": "Which choice correctly identifies the four components of blood?",
        "options": [
          {
            "label": "A",
            "text": "red blood cells, thrombocytes, hemoglobin, erythrocytes"
          },
          {
            "label": "B",
            "text": "plasma, red blood cells, white blood cells, platelets"
          },
          {
            "label": "C",
            "text": "water, nutrients, minerals, gases"
          },
          {
            "label": "D",
            "text": "DNA, anti-serum A, anti-serum B, anti-serum Rh+"
          }
        ],
        "answer": "B"
      },
      {
        "number": 2,
        "prompt": "Which of the following areas in Alberta would produce the highest red blood cell count within an individual after several days?",
        "options": [
          {
            "label": "A",
            "text": "Banff (elevation = 1383 m)"
          },
          {
            "label": "B",
            "text": "Camrose (elevation = 740 m)"
          },
          {
            "label": "C",
            "text": "Lake Louise (elevation = 1536 m)"
          },
          {
            "label": "D",
            "text": "Medicine Hat (elevation = 721 m)"
          }
        ],
        "answer": "C"
      },
      {
        "number": 3,
        "prompt": "A brief anonymous phone call stating that the murder of a man has been committed leads police officers to an old, abandoned farmhouse several kilometres west of Cremona, Alberta. When police officers enter the farmhouse, they discover several dead chickens and a large amount of blood smeared on the walls of the kitchen. What scientific technique may be used to determine if the blood in the kitchen is from the chickens or from a human?",
        "options": [
          {
            "label": "A",
            "text": "DNA analysis"
          },
          {
            "label": "B",
            "text": "Anti-serum testing"
          },
          {
            "label": "C",
            "text": "Enzyme testing"
          },
          {
            "label": "D",
            "text": "Microscopic analysis"
          }
        ],
        "answer": "D"
      },
      {
        "number": 4,
        "prompt": "A brief anonymous phone call stating that the murder of a man has been committed leads police officers to an old, abandoned farmhouse several kilometres west of Cremona, Alberta. When police officers enter the farmhouse, they discover several dead chickens and a large amount of blood smeared on the walls of the kitchen. The red blood cells from the blood found in the kitchen prove to be anucleated, meaning the blood likely came from a",
        "options": [
          {
            "label": "A",
            "text": "chicken"
          },
          {
            "label": "B",
            "text": "toad"
          },
          {
            "label": "C",
            "text": "frog"
          },
          {
            "label": "D",
            "text": "human"
          }
        ],
        "answer": "D"
      },
      {
        "number": 5,
        "prompt": "Which choice correctly identifies the three protein markers that exist on human red blood cells?",
        "options": [
          {
            "label": "A",
            "text": "A, B, Rh+"
          },
          {
            "label": "B",
            "text": "ABO, Rh+, Rh-"
          },
          {
            "label": "C",
            "text": "AB, O, Rh+"
          },
          {
            "label": "D",
            "text": "O, A, B"
          }
        ],
        "answer": "A"
      },
      {
        "number": 6,
        "prompt": "What blood type is the most helpful in the identification of a suspect because it is rare?",
        "options": [
          {
            "label": "A",
            "text": "Type AB"
          },
          {
            "label": "B",
            "text": "Type O"
          },
          {
            "label": "C",
            "text": "Type A"
          },
          {
            "label": "D",
            "text": "Type B"
          }
        ],
        "answer": "A"
      },
      {
        "number": 7,
        "prompt": "Identifying one type of blood enzyme or protein within a blood evidence sample assists investigators because it",
        "options": [
          {
            "label": "A",
            "text": "determines the type of crime that occurred"
          },
          {
            "label": "B",
            "text": "establishes the exact time of the crime"
          },
          {
            "label": "C",
            "text": "helps to narrow down the list of suspects"
          },
          {
            "label": "D",
            "text": "singles out one specific suspect"
          }
        ],
        "answer": "C"
      },
      {
        "number": 8,
        "prompt": "Some Steps Involved in the Determination of Blood Type of an Unknown Sample 1. Each sample is gently mixed. 2. One type of anti-serum is added to each sample. 3. An agglutination reaction is observed in two samples. 4. Unknown blood is separated into three separate samples. The sequence of steps that occur in the determination of the blood type of the unknown sample are",
        "options": [
          {
            "label": "A",
            "text": "4,2,1,3"
          },
          {
            "label": "B",
            "text": "4,1,3,2"
          },
          {
            "label": "C",
            "text": "1,4,2,3"
          },
          {
            "label": "D",
            "text": "1,2,4,3"
          }
        ],
        "answer": "A"
      },
      {
        "number": 9,
        "prompt": "When blood evidence is suspected at a crime scene, what should be done initially?",
        "options": [
          {
            "label": "A",
            "text": "Verify that the evidence found is blood."
          },
          {
            "label": "B",
            "text": "Contact the medical examiner's office."
          },
          {
            "label": "C",
            "text": "Complete a microscopic analysis of the evidence."
          },
          {
            "label": "D",
            "text": "Determine the blood type of the victim."
          }
        ],
        "answer": "A"
      },
      {
        "number": 10,
        "prompt": "At a crime scene, the first technique that investigators use to find trace blood evidence is",
        "options": [
          {
            "label": "A",
            "text": "luminol solution"
          },
          {
            "label": "B",
            "text": "phenolphthalein reagent"
          },
          {
            "label": "C",
            "text": "hydrochloric acid"
          },
          {
            "label": "D",
            "text": "powerful lighting"
          }
        ],
        "answer": "D"
      },
      {
        "number": 11,
        "prompt": "What specific part of blood does phenolphthalein react with?",
        "options": [
          {
            "label": "A",
            "text": "Oxygen"
          },
          {
            "label": "B",
            "text": "Hemoglobin"
          },
          {
            "label": "C",
            "text": "Thrombocytes"
          },
          {
            "label": "D",
            "text": "White blood cells"
          }
        ],
        "answer": "B"
      },
      {
        "number": 12,
        "prompt": "When phenolphthalein comes into contact with blood, it",
        "options": [
          {
            "label": "A",
            "text": "begins to fade"
          },
          {
            "label": "B",
            "text": "emits a greenish-blue glow"
          },
          {
            "label": "C",
            "text": "turns a bright pink color"
          },
          {
            "label": "D",
            "text": "releases hydroxide ions"
          }
        ],
        "answer": "C"
      },
      {
        "number": 13,
        "prompt": "Luminol reagent should be used at a crime scene when",
        "options": [
          {
            "label": "A",
            "text": "the victim's and suspect's blood types are identical"
          },
          {
            "label": "B",
            "text": "more than one murder victim is present"
          },
          {
            "label": "C",
            "text": "both animal and human blood are suspected to be involved"
          },
          {
            "label": "D",
            "text": "it is suspected that the blood evidence has been cleaned away"
          }
        ],
        "answer": "D"
      },
      {
        "number": 14,
        "prompt": "When luminol comes into contact with blood, it",
        "options": [
          {
            "label": "A",
            "text": "releases oxygen gas"
          },
          {
            "label": "B",
            "text": "turns a bright pink color"
          },
          {
            "label": "C",
            "text": "emits a greenish-blue glow"
          },
          {
            "label": "D",
            "text": "breaks down hemoglobin"
          }
        ],
        "answer": "C"
      },
      {
        "number": 15,
        "prompt": "What specific part of blood does luminol react with?",
        "options": [
          {
            "label": "A",
            "text": "Protein strands in thrombocytes"
          },
          {
            "label": "B",
            "text": "Dissolved gasses in plasma"
          },
          {
            "label": "C",
            "text": "Iron pigment in red blood cells"
          },
          {
            "label": "D",
            "text": "Nucleus of white blood cells"
          }
        ],
        "answer": "C"
      },
      {
        "number": 16,
        "prompt": "The greater the distance that blood free-falls, the greater the increase in the",
        "options": [
          {
            "label": "A",
            "text": "size of the circular stain pattern and the amount of cast-off residue"
          },
          {
            "label": "B",
            "text": "amount of blood released and the length of the blood stain pattern"
          },
          {
            "label": "C",
            "text": "force of the impact and the surface tension in the blood droplets"
          },
          {
            "label": "D",
            "text": "number of blood droplets and the decomposition of hemoglobin"
          }
        ],
        "answer": "A"
      },
      {
        "number": 17,
        "prompt": "The blood spatter pattern shown likely was the result of a",
        "options": [
          {
            "label": "A",
            "text": "baseball bat"
          },
          {
            "label": "B",
            "text": "bullet"
          },
          {
            "label": "C",
            "text": "knife"
          },
          {
            "label": "D",
            "text": "human fist"
          }
        ],
        "answer": "B"
      },
      {
        "number": 18,
        "prompt": "Which of the following crime scene objects could be tested to see if a person is a secretor?",
        "options": [
          {
            "label": "A",
            "text": "Strand of Hair"
          },
          {
            "label": "B",
            "text": "Saliva on cigarette butt"
          },
          {
            "label": "C",
            "text": "Urine in toilet"
          },
          {
            "label": "D",
            "text": "Handle of a gun"
          }
        ],
        "answer": "B"
      },
      {
        "number": 19,
        "prompt": "The most visible objects in this micrograph of semen is",
        "options": [
          {
            "label": "A",
            "text": "pubic hairs"
          },
          {
            "label": "B",
            "text": "sperm cells"
          },
          {
            "label": "C",
            "text": "acid phosphatase"
          },
          {
            "label": "D",
            "text": "seminal fluid"
          }
        ],
        "answer": "B"
      },
      {
        "number": 20,
        "prompt": "The normal components of semen are",
        "options": [
          {
            "label": "A",
            "text": "mucous and sperm cells"
          },
          {
            "label": "B",
            "text": "seminal fluid and testosterone"
          },
          {
            "label": "C",
            "text": "testosterone and mucous"
          },
          {
            "label": "D",
            "text": "sperm cells and seminal fluid"
          }
        ],
        "answer": "D"
      },
      {
        "number": 21,
        "prompt": "Sperm cells are unique in that they are the only human body cells that",
        "options": [
          {
            "label": "A",
            "text": "are covered with mucous"
          },
          {
            "label": "B",
            "text": "are covered with pubic hairs"
          },
          {
            "label": "C",
            "text": "have a tail"
          },
          {
            "label": "D",
            "text": "have a nucleus"
          }
        ],
        "answer": "C"
      },
      {
        "number": 22,
        "prompt": "The substance in semen that the chemical in the fast blue B test reacts with is",
        "options": [
          {
            "label": "A",
            "text": "testosterone"
          },
          {
            "label": "B",
            "text": "sperm cells"
          },
          {
            "label": "C",
            "text": "acid phosphatase"
          },
          {
            "label": "D",
            "text": "fructose"
          }
        ],
        "answer": "C"
      },
      {
        "number": 23,
        "prompt": "If semen is present in a sample, during the fast blue B test it will",
        "options": [
          {
            "label": "A",
            "text": "change to a blue color"
          },
          {
            "label": "B",
            "text": "release acid phosphatase"
          },
          {
            "label": "C",
            "text": "break down sperm cells"
          },
          {
            "label": "D",
            "text": "turn a deep purple color"
          }
        ],
        "answer": "D"
      },
      {
        "number": 24,
        "prompt": "After biological evidence is collected from a sexual assault victim and a crime scene, it is sent",
        "options": [
          {
            "label": "A",
            "text": "to a local hospital for a medicinal examination"
          },
          {
            "label": "B",
            "text": "to the court house and put into long term storage"
          },
          {
            "label": "C",
            "text": "to the medical examiner's office and destroyed"
          },
          {
            "label": "D",
            "text": "to a forensic laboratory for a DNA analysis"
          }
        ],
        "answer": "D"
      },
      {
        "number": 25,
        "prompt": "What should occur as soon as possible after a sexual assault has been reported by a victim?",
        "options": [
          {
            "label": "A",
            "text": "The suspect should complete a lie detector test."
          },
          {
            "label": "B",
            "text": "The victim should be given a rape kit examination."
          },
          {
            "label": "C",
            "text": "The victim should be permitted to clean herself."
          },
          {
            "label": "D",
            "text": "The suspect should be allowed to make a statement."
          }
        ],
        "answer": "B"
      },
      {
        "number": 26,
        "prompt": "Due to the relative small number of DNA analysts and the increased volume of evidence sent from police agencies, forensic laboratories in Canada have experienced",
        "options": [
          {
            "label": "A",
            "text": "a backlog of evidence sent in for DNA analysis"
          },
          {
            "label": "B",
            "text": "an accumulation in the number of not guilty verdicts given"
          },
          {
            "label": "C",
            "text": "a decrease in the number of sexual assaults reported"
          },
          {
            "label": "D",
            "text": "a decrease in the turnaround time for DNA analysis"
          }
        ],
        "answer": "A"
      },
      {
        "number": 27,
        "prompt": "From the list below, check off which are types of biological evidence from a crime scene that will indicate the blood type of a secretor.",
        "options": [
          {
            "label": "A",
            "text": "Vaginal secretions"
          },
          {
            "label": "B",
            "text": "Urine"
          },
          {
            "label": "C",
            "text": "Feces"
          },
          {
            "label": "D",
            "text": "Saliva"
          },
          {
            "label": "E",
            "text": "Semen"
          },
          {
            "label": "F",
            "text": "Tears"
          },
          {
            "label": "G",
            "text": "Thrombocytes"
          },
          {
            "label": "H",
            "text": "White Blood Cells (WBCs)"
          }
        ],
        "answer": "A"
      }
    ]
  },
  "assignment": {
    "id": "assignment-4",
    "title": "Body Fluid Analysis Lab Assignment",
    "file": "module4assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module4assignment.html"
    ],
    "assetFiles": [
      "module4/blood-spill.jpg",
      "module4/stairs.jpg",
      "module4/tammy-parrot-comic.png"
    ]
  },
  "resources": [
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r22",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r22"
    },
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r23",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r23"
    },
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r27",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r27"
    },
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r3",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r3"
    },
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r36",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r36"
    },
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r6",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842-eng.htm#r6"
    },
    {
      "title": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842/c-g/c-g01-eng.gif",
      "href": "http://www.statcan.gc.ca/pub/85-002-x/2017001/article/14842/c-g/c-g01-eng.gif"
    },
    {
      "title": "https://i.ytimg.com/vi/2aPz_AV0t3U/hqdefault.jpg",
      "href": "https://i.ytimg.com/vi/2aPz_AV0t3U/hqdefault.jpg"
    },
    {
      "title": "https://www.youtube.com/embed/8OtzP9_a_sU?wmode=opaque&amp;rel=0",
      "href": "https://www.youtube.com/embed/8OtzP9_a_sU?wmode=opaque&amp;rel=0"
    },
    {
      "title": "Body Fluid Analysis Lab Assignment",
      "href": "./assignment/module4assignment.html"
    },
    {
      "title": "M4 Body Fluid Evidence Assessment",
      "href": "#quiz"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
