const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 8
  },
  "chapter": {
    "id": "chapter-8",
    "title": "8 Careers in Forensic Science",
    "code": "Module 8",
    "summary": "Compare forensic career paths and reflect on which roles fit your strengths and interests.",
    "componentCount": 0
  },
  "quiz": null,
  "assignment": {
    "id": "assignment-8",
    "title": "Career Path Simulation Lab",
    "file": "module8assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module8assignment-app.jsx",
      "module8assignment-career-matcher.jsx",
      "module8assignment-case-role.jsx",
      "module8assignment-day-in-life.jsx",
      "module8assignment.bundle.js",
      "module8assignment.html"
    ],
    "assetFiles": []
  },
  "resources": [
    {
      "title": "Career Path Simulation Lab",
      "href": "./assignment/module8assignment.html"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
