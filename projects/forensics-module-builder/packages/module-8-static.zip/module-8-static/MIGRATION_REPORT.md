# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-8\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 8
- Title: 8 Careers in Forensic Science
- Quiz: No quiz assigned
- Quiz answer key: No quiz
- Assignment: assignment-8

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module8assignment-app.jsx`
- `module8assignment-career-matcher.jsx`
- `module8assignment-case-role.jsx`
- `module8assignment-day-in-life.jsx`
- `module8assignment.bundle.js`
- `module8assignment.html`

## Assignment assets copied

- None

## Image paths rewritten

- Local images copied: 0
- None

## External URLs found

- None

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
