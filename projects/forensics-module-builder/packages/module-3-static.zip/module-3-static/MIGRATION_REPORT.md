# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-3\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 3
- Title: 3 Trace Evidence
- Quiz: quiz-3
- Quiz answer key: C A A C D A D C B B
- Assignment: assignment-3

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module3assignment-app.jsx`
- `module3assignment-entry.jsx`
- `module3assignment.bundle.js`
- `module3assignment.html`

## Assignment assets copied

- None

## Image paths rewritten

- Local images copied: 20
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i15e6ef30-f8fe-4a0a-856e-16275d9a167b\Content\Trace-Evidence.jpeg -> assets/images/module-3-image-01.jpeg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ica1ea031-d879-4f12-bdbb-f2c344cca0c0\Content\CSI Clean Up.jpg -> assets/images/module-3-image-02.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ica1ea031-d879-4f12-bdbb-f2c344cca0c0\Content\Evidence-Collection_Trace-Evidence.jpg -> assets/images/module-3-image-03.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i01769305-1d04-4b96-ae17-df848a52c31f\Content\hair.jpeg -> assets/images/module-3-image-04.jpeg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i55c747ee-6cb8-43b0-b421-10feff383073\Content\hair2.PNG -> assets/images/module-3-image-05.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i1e97890f-81bf-446d-ab50-004a1547d227\Content\colored hair.PNG -> assets/images/module-3-image-06.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iecafb11f-ca0d-4ad8-a0e7-43d399f4371a\Content\animal hair.PNG -> assets/images/module-3-image-07.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i140bff09-0cf0-4230-8bf1-25cf6daf71f2\Content\club root.PNG -> assets/images/module-3-image-08.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i140bff09-0cf0-4230-8bf1-25cf6daf71f2\Content\follicle attached.PNG -> assets/images/module-3-image-09.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i140bff09-0cf0-4230-8bf1-25cf6daf71f2\Content\cat root.PNG -> assets/images/module-3-image-10.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i140bff09-0cf0-4230-8bf1-25cf6daf71f2\Content\spade root dog.PNG -> assets/images/module-3-image-11.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i140bff09-0cf0-4230-8bf1-25cf6daf71f2\Content\cuticle (1).PNG -> assets/images/module-3-image-12.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i140bff09-0cf0-4230-8bf1-25cf6daf71f2\Content\medulla.PNG -> assets/images/module-3-image-13.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\central-park.jpg -> assets/images/module-3-image-14.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i09fc2f90-b5a6-46d8-a876-6a6e38b8956f\Content\alg-joggers-court-jpg.jpg -> assets/images/module-3-image-15.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\textile-fibres-microscope.jpg -> assets/images/module-3-image-16.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\if1ac80aa-363d-4683-9fbc-9311d6a6ff50\fibers.jpg -> assets/images/module-3-image-17.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iab328ad4-59b6-47fe-95ca-ea0efa2a4f0e\Content\natural fibers.png -> assets/images/module-3-image-18.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iab328ad4-59b6-47fe-95ca-ea0efa2a4f0e\Content\synthetic fibres.png -> assets/images/module-3-image-19.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6ab2040d-c5b1-490e-ba4c-3f876aa81850\Content\Samuel Morgan.jpeg -> assets/images/module-3-image-20.jpeg

## External URLs found

- https://en.wikipedia.org/wiki/False_confession
- https://en.wikipedia.org/wiki/When_They_See_Us
- https://www.youtube.com/embed/BjLHW7qQEl0?rel=0
- https://www.youtube.com/embed/yeAwJwuUQH8?wmode=opaque

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
