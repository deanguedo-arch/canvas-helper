const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 3
  },
  "chapter": {
    "id": "chapter-3",
    "title": "3 Trace Evidence",
    "code": "Module 3",
    "summary": "Examine hair, fibre, glass, and other trace evidence and how investigators compare them in real cases.",
    "componentCount": 14
  },
  "quiz": {
    "id": "quiz-3",
    "title": "M3 Trace Evidence Assessment",
    "multipleChoice": [
      {
        "number": 1,
        "prompt": "All of the trace evidence listed below is considered Organic/Natural evidence EXCEPT:",
        "options": [
          {
            "label": "A",
            "text": "Cotton"
          },
          {
            "label": "B",
            "text": "Hemp"
          },
          {
            "label": "C",
            "text": "Nylon"
          },
          {
            "label": "D",
            "text": "Silk"
          }
        ],
        "answer": "C"
      },
      {
        "number": 2,
        "prompt": "A forensic scientist is trying to identify the source of numerous hair samples found on a homicide victim. The hairs all display frayed root tips, spinous cuticle scales and unisereal medullas. What is the source of this hair?",
        "options": [
          {
            "label": "A",
            "text": "a cat"
          },
          {
            "label": "B",
            "text": "a dog"
          },
          {
            "label": "C",
            "text": "a human"
          },
          {
            "label": "D",
            "text": "a rabbit"
          }
        ],
        "answer": "A"
      },
      {
        "number": 3,
        "prompt": "When forensic experts examine a piece of trace evidence with a microscope, the first thing they try and do is to:",
        "options": [
          {
            "label": "A",
            "text": "Identify the evidence."
          },
          {
            "label": "B",
            "text": "Secure the evidence."
          },
          {
            "label": "C",
            "text": "Process the evidence."
          },
          {
            "label": "D",
            "text": "Individualize the evidence."
          }
        ],
        "answer": "A"
      },
      {
        "number": 4,
        "prompt": "Two methods that help to individualize hair evidence are",
        "options": [
          {
            "label": "A",
            "text": "DNA analysis and cyanoacrylate fumigation"
          },
          {
            "label": "B",
            "text": "iodine fumigation and cyanoacrylate fumigation"
          },
          {
            "label": "C",
            "text": "microscopy and DNA analysis"
          },
          {
            "label": "D",
            "text": "microscopy and iodine fumigation"
          }
        ],
        "answer": "C"
      },
      {
        "number": 5,
        "prompt": "A trait that distinguishes colour-treated hair from untreated hair is that a colour-treated hair exhibits",
        "options": [
          {
            "label": "A",
            "text": "darker coronal scales in the cuticle"
          },
          {
            "label": "B",
            "text": "lighter pigmentation in the root"
          },
          {
            "label": "C",
            "text": "frayed hair tips"
          },
          {
            "label": "D",
            "text": "little colour variation in the medulla"
          }
        ],
        "answer": "D"
      },
      {
        "number": 6,
        "prompt": "If the follicle of a hair root is still attached to the root (the follicle looks like transparent skin around the root), then the hair was:",
        "options": [
          {
            "label": "A",
            "text": "forcibly removed."
          },
          {
            "label": "B",
            "text": "shed after the person died."
          },
          {
            "label": "C",
            "text": "likely from a cat."
          },
          {
            "label": "D",
            "text": "recently cut."
          }
        ],
        "answer": "A"
      },
      {
        "number": 7,
        "prompt": "What shape is the root of a human hair?",
        "options": [
          {
            "label": "A",
            "text": "Frayed"
          },
          {
            "label": "B",
            "text": "Wine-glass"
          },
          {
            "label": "C",
            "text": "Spade"
          },
          {
            "label": "D",
            "text": "Club"
          }
        ],
        "answer": "D"
      },
      {
        "number": 8,
        "prompt": "A general feature that distinguishes human hair from animal hair is that human hairs tend to have a",
        "options": [
          {
            "label": "A",
            "text": "straight and narrow medulla"
          },
          {
            "label": "B",
            "text": "coronal-shaped scales on the cuticle"
          },
          {
            "label": "C",
            "text": "consistent colour throughout the shaft"
          },
          {
            "label": "D",
            "text": "wine-glass shaped root"
          }
        ],
        "answer": "C"
      },
      {
        "number": 9,
        "prompt": "The shaft of the hair is the region found between the root and the tip. The three parts of the hair shaft are the cuticle, cortex, and medulla. The outermost layer of the hair shaft is called the cuticle, a layer of scales covering the outside of the hair shaft. An imbricate culticle is a scale pattern found in all:",
        "options": [
          {
            "label": "A",
            "text": "bats and small rodents."
          },
          {
            "label": "B",
            "text": "human hairs and some animals."
          },
          {
            "label": "C",
            "text": "minks, seals and cats."
          },
          {
            "label": "D",
            "text": "dogs, foxes and cattle."
          }
        ],
        "answer": "B"
      },
      {
        "number": 10,
        "prompt": "The most common animal fibre in fabrics is:",
        "options": [
          {
            "label": "A",
            "text": "cashmere"
          },
          {
            "label": "B",
            "text": "wool"
          },
          {
            "label": "C",
            "text": "cotton"
          },
          {
            "label": "D",
            "text": "camel"
          }
        ],
        "answer": "B"
      }
    ]
  },
  "assignment": {
    "id": "assignment-3",
    "title": "Trace Evidence Lab Assignment",
    "file": "module3assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module3assignment-app.jsx",
      "module3assignment-entry.jsx",
      "module3assignment.bundle.js",
      "module3assignment.html"
    ],
    "assetFiles": []
  },
  "resources": [
    {
      "title": "https://en.wikipedia.org/wiki/False_confession",
      "href": "https://en.wikipedia.org/wiki/False_confession"
    },
    {
      "title": "https://en.wikipedia.org/wiki/When_They_See_Us",
      "href": "https://en.wikipedia.org/wiki/When_They_See_Us"
    },
    {
      "title": "https://www.youtube.com/embed/BjLHW7qQEl0?rel=0",
      "href": "https://www.youtube.com/embed/BjLHW7qQEl0?rel=0"
    },
    {
      "title": "https://www.youtube.com/embed/yeAwJwuUQH8?wmode=opaque",
      "href": "https://www.youtube.com/embed/yeAwJwuUQH8?wmode=opaque"
    },
    {
      "title": "Trace Evidence Lab Assignment",
      "href": "./assignment/module3assignment.html"
    },
    {
      "title": "M3 Trace Evidence Assessment",
      "href": "#quiz"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
