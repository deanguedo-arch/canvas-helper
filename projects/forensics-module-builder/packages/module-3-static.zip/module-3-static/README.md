# Forensics 25 Module 3 Static Tester

Run locally with `python3 -m http.server 8080` and open `http://localhost:8080`.
