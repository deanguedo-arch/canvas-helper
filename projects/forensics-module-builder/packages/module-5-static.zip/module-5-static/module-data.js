const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 5
  },
  "chapter": {
    "id": "chapter-5",
    "title": "5 Forensic Detection of Impaired Driving",
    "code": "Module 5",
    "summary": "Follow the tools, procedures, and evidence used to detect impaired driving.",
    "componentCount": 18
  },
  "quiz": {
    "id": "quiz-5",
    "title": "M5 Impaired Driving and Alcohol Assessment",
    "multipleChoice": [
      {
        "number": 1,
        "prompt": "The accurate chemical name for the alcohol found in alcoholic beverages is",
        "options": [
          {
            "label": "A",
            "text": "methyl alcohol"
          },
          {
            "label": "B",
            "text": "methanol"
          },
          {
            "label": "C",
            "text": "isopropanol"
          },
          {
            "label": "D",
            "text": "ethanol"
          }
        ],
        "answer": "D"
      },
      {
        "number": 2,
        "prompt": "Alcohol is created through a process known as",
        "options": [
          {
            "label": "A",
            "text": "oxidation"
          },
          {
            "label": "B",
            "text": "concentration"
          },
          {
            "label": "C",
            "text": "diffusion"
          },
          {
            "label": "D",
            "text": "fermenation"
          }
        ],
        "answer": "D"
      },
      {
        "number": 3,
        "prompt": "Which type of alcoholic beverage has the highest concentration of alcohol by volume?",
        "options": [
          {
            "label": "A",
            "text": "Distilled spirits"
          },
          {
            "label": "B",
            "text": "Beer"
          },
          {
            "label": "C",
            "text": "Red wine"
          },
          {
            "label": "D",
            "text": "Champagne"
          }
        ],
        "answer": "A"
      },
      {
        "number": 4,
        "prompt": "Which area of the brain is the first to be affected noticeably by alcohol that is absorbed into the body?",
        "options": [
          {
            "label": "A",
            "text": "Cerebrum"
          },
          {
            "label": "B",
            "text": "Cerebellum"
          },
          {
            "label": "C",
            "text": "Pituitary gland"
          },
          {
            "label": "D",
            "text": "Medulla oblongata"
          }
        ],
        "answer": "A"
      },
      {
        "number": 5,
        "prompt": "People are considered to be legally impaired in Canada if they",
        "options": [
          {
            "label": "A",
            "text": "drink one glass of wine in three hours"
          },
          {
            "label": "B",
            "text": "have more than 80 mg of alcohol per 100 ml of blood"
          },
          {
            "label": "C",
            "text": "have more than 50 mg of alcohol in 100 ml of blood"
          },
          {
            "label": "D",
            "text": "drink two cans of beer in two hours"
          }
        ],
        "answer": "B"
      },
      {
        "number": 6,
        "prompt": "The blood alcohol concentration of a person increases",
        "options": [
          {
            "label": "A",
            "text": "more quickly if something haws been eaten"
          },
          {
            "label": "B",
            "text": "more slowly if some vigorous exercise has been completed"
          },
          {
            "label": "C",
            "text": "one hour after drinking alcohol"
          },
          {
            "label": "D",
            "text": "twenty minutes after drinking alcohol"
          }
        ],
        "answer": "D"
      },
      {
        "number": 7,
        "prompt": "Which country has a higher BAC legal limit than Canada?",
        "options": [
          {
            "label": "A",
            "text": "Swaziland"
          },
          {
            "label": "B",
            "text": "Albania"
          },
          {
            "label": "C",
            "text": "China"
          },
          {
            "label": "D",
            "text": "United States"
          }
        ],
        "answer": "A"
      },
      {
        "number": 8,
        "prompt": "How does the concentration of alcohol in blood compare with the concentration of alcohol in the alveoli?",
        "options": [
          {
            "label": "A",
            "text": "Alcohol is broken down into acetic acid in the alveoli."
          },
          {
            "label": "B",
            "text": "The alcohol concentration is 2100 times greater in blood."
          },
          {
            "label": "C",
            "text": "The alcohol concentration is the same in both."
          },
          {
            "label": "D",
            "text": "Alcohol is converted into sulfuric acid by the liver."
          }
        ],
        "answer": "C"
      },
      {
        "number": 9,
        "prompt": "The Breathalyzer became more popular with law enforcement agencies than the Drunkometer because it",
        "options": [
          {
            "label": "A",
            "text": "could determine if a person had consumed any drugs"
          },
          {
            "label": "B",
            "text": "could prove what type of alcoholic beverage was consumed"
          },
          {
            "label": "C",
            "text": "was less expensive and did not need any repairs"
          },
          {
            "label": "D",
            "text": "was more portable and did not need recalibration every time it was moved"
          }
        ],
        "answer": "D"
      },
      {
        "number": 10,
        "prompt": "Which reactant in the test vial of the Breathalyzer is a catalyst?",
        "options": [
          {
            "label": "A",
            "text": "Potassium dichromate"
          },
          {
            "label": "B",
            "text": "Water"
          },
          {
            "label": "C",
            "text": "Silver nitrate"
          },
          {
            "label": "D",
            "text": "Alcohol"
          }
        ],
        "answer": "C"
      },
      {
        "number": 11,
        "prompt": "When alcohol is absorbed into the blood and while it is transported through the blood, it does not",
        "options": [
          {
            "label": "A",
            "text": "become absorbed by the liver"
          },
          {
            "label": "B",
            "text": "change chemically in any way"
          },
          {
            "label": "C",
            "text": "remain in its original state"
          },
          {
            "label": "D",
            "text": "contain any hydroxide ions"
          }
        ],
        "answer": "B"
      },
      {
        "number": 12,
        "prompt": "After the solution in a test vial has been exposed to alcohol, it is",
        "options": [
          {
            "label": "A",
            "text": "compared with a solution in a control vial"
          },
          {
            "label": "B",
            "text": "absorbed by silver nitrate"
          },
          {
            "label": "C",
            "text": "converted into sulfuric acid"
          },
          {
            "label": "D",
            "text": "analyzed under the microscope"
          }
        ],
        "answer": "A"
      },
      {
        "number": 13,
        "prompt": "The primary colour change that occurs in the solution of a test vial that has been exposed to alcohol is",
        "options": [
          {
            "label": "A",
            "text": "dark green => yellowish-green"
          },
          {
            "label": "B",
            "text": "dark orange => light orange"
          },
          {
            "label": "C",
            "text": "light orange => green"
          },
          {
            "label": "D",
            "text": "orange => clear"
          }
        ],
        "answer": "B"
      },
      {
        "number": 14,
        "prompt": "The reactants found in the glass test vial before an individual breathes into the Breathalyzer are",
        "options": [
          {
            "label": "A",
            "text": "acetic acid, sulfuric acid, silver nitrate, and water"
          },
          {
            "label": "B",
            "text": "alcohol, potassium dichromate, sulfuric acid, water, and silver nitrate"
          },
          {
            "label": "C",
            "text": "potassium dichromate, sulfuric acid, water, and silver nitrate"
          },
          {
            "label": "D",
            "text": "chromium sulfate, potassium sulfate, acetic acid, water, and silver nitrate"
          }
        ],
        "answer": "C"
      },
      {
        "number": 15,
        "prompt": "The type of technology the Intoxilyzer uses to analyze an alcohol breath sample is",
        "options": [
          {
            "label": "A",
            "text": "chemical analysis"
          },
          {
            "label": "B",
            "text": "infrared spectroscopy"
          },
          {
            "label": "C",
            "text": "electrical impulses"
          },
          {
            "label": "D",
            "text": "microscopic examination"
          }
        ],
        "answer": "B"
      },
      {
        "number": 16,
        "prompt": "The ideal temperature of a breath sample blown into an Intoxilyzer is",
        "options": [
          {
            "label": "A",
            "text": "30 degrees C"
          },
          {
            "label": "B",
            "text": "7 degrees C"
          },
          {
            "label": "C",
            "text": "22 degrees C"
          },
          {
            "label": "D",
            "text": "34 degrees C"
          }
        ],
        "answer": "D"
      },
      {
        "number": 17,
        "prompt": "In the Intoxilyzer, when infrared light absorbed by alcohol passes through the spinning filter wheel to the photocell system, it is converted into",
        "options": [
          {
            "label": "A",
            "text": "an electrical pulse"
          },
          {
            "label": "B",
            "text": "a solid"
          },
          {
            "label": "C",
            "text": "a digital calculation"
          },
          {
            "label": "D",
            "text": "a liquid"
          }
        ],
        "answer": "A"
      },
      {
        "number": 18,
        "prompt": "Unlike the Breathalyzer, the Intoxilyzer eliminates the need for",
        "options": [
          {
            "label": "A",
            "text": "large breath sample"
          },
          {
            "label": "B",
            "text": "trained breath technician"
          },
          {
            "label": "C",
            "text": "chemical compounds"
          },
          {
            "label": "D",
            "text": "electrical energy"
          }
        ],
        "answer": "C"
      }
    ]
  },
  "assignment": {
    "id": "assignment-5",
    "title": "Impaired Driving Assignment Lab",
    "file": "module5assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module5assignment.app.js",
      "module5assignment.html",
      "module5assignment.jsx",
      "module5assignment.source.txt"
    ],
    "assetFiles": []
  },
  "resources": [
    {
      "title": "http://www.markelliot.com/archive/june9.htm",
      "href": "http://www.markelliot.com/archive/june9.htm"
    },
    {
      "title": "https://www.smartserve.ca/documents/10156/fd0cb346-3553-4c4c-992f-d9e6cd4c37bb",
      "href": "https://www.smartserve.ca/documents/10156/fd0cb346-3553-4c4c-992f-d9e6cd4c37bb"
    },
    {
      "title": "https://www.youtube.com/embed/2gn-QZ_e06k?rel=0",
      "href": "https://www.youtube.com/embed/2gn-QZ_e06k?rel=0"
    },
    {
      "title": "https://www.youtube.com/embed/YmwMRIG4GNY?rel=0",
      "href": "https://www.youtube.com/embed/YmwMRIG4GNY?rel=0"
    },
    {
      "title": "Impaired Driving Assignment Lab",
      "href": "./assignment/module5assignment.html"
    },
    {
      "title": "M5 Impaired Driving and Alcohol Assessment",
      "href": "#quiz"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
