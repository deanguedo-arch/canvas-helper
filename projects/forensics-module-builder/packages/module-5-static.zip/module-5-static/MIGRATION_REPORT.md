# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-5\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 5
- Title: 5 Forensic Detection of Impaired Driving
- Quiz: quiz-5
- Quiz answer key: D D A A B D A C D C B A B C B D A C
- Assignment: assignment-5

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module5assignment.app.js`
- `module5assignment.html`
- `module5assignment.jsx`
- `module5assignment.source.txt`

## Assignment assets copied

- None

## Image paths rewritten

- Local images copied: 23
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i18824365-5daf-43b4-868a-2443fe223d70\Content\Car Crash.jpg -> assets/images/module-5-image-01.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\icf90943a-6519-4195-81c6-97709fc6665f\Content\Drinking.jpg -> assets/images/module-5-image-02.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i94056bde-11ed-48f9-aad5-0e89433d1c42\Content\Ethanol Compound.jpg -> assets/images/module-5-image-03.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ib7ddc073-af51-4d55-af05-3050a838decd\Content\brain_diagram.png -> assets/images/module-5-image-04.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i308b5599-08d0-4eae-851b-a20de4c7a092\Content\Check Stop.jpg -> assets/images/module-5-image-05.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ie400334c-7162-4600-b3f3-f341d5dc39e3\Content\man testing alcohol level.jpg -> assets/images/module-5-image-06.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ie400334c-7162-4600-b3f3-f341d5dc39e3\Content\History of Breathalyzer.jpg -> assets/images/module-5-image-07.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i62193d4d-642f-42e4-9055-a182d989d8be\Content\breathalyzer.jpg -> assets/images/module-5-image-08.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7c28a6cf-9418-4bcb-849b-8ae4d26e1ba3\Content\breathalyzer (1).jpg -> assets/images/module-5-image-09.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ie628f048-15ec-445c-adf8-77ff7c591aae\Content\Handcuffs ands alcohol.jpg -> assets/images/module-5-image-10.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ic28f2325-81d0-4f37-ad27-b7256b039ccb\Content\Keys and a drink.jpg -> assets/images/module-5-image-11.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ib8d3d327-12ff-4bfd-82fd-b80ac6183481\Content\Arrested.jpg -> assets/images/module-5-image-12.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6d24cb51-52f6-4a9b-8065-d30e619f26a6\Content\intoxilyzerdurham.jpg -> assets/images/module-5-image-13.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6d24cb51-52f6-4a9b-8065-d30e619f26a6\Content\IntoxilyzerFront.jpg -> assets/images/module-5-image-14.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6d24cb51-52f6-4a9b-8065-d30e619f26a6\Content\breathalyzer-intoxilyzer.gif -> assets/images/module-5-image-15.gif
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6d24cb51-52f6-4a9b-8065-d30e619f26a6\Content\Officer Breathalyzer.jpg -> assets/images/module-5-image-16.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6cbc2e88-2f07-4d56-93f2-d921a0193630\Content\Jail Dark.jpg -> assets/images/module-5-image-17.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i56adc209-55ac-4897-9106-b794a97c179d\Content\hands on jail bars.jpg -> assets/images/module-5-image-18.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i5e596270-8345-44b2-85ec-7f2112a41913\Content\Drinking and Driving Limit.jpg -> assets/images/module-5-image-19.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i0216cc8c-cf1f-4893-aa90-74eb3b43fcda\Content\Drunken Russian Case 2.jpg -> assets/images/module-5-image-20.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i0216cc8c-cf1f-4893-aa90-74eb3b43fcda\Content\Drunken Russian Case.jpg -> assets/images/module-5-image-21.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2b5fcc4e-bc3b-4fed-ab4c-e39906258b3f\Content\princess-di-420x0.jpg -> assets/images/module-5-image-22.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\alma-tunnel-paris.jpg -> assets/images/module-5-image-23.jpg

## External URLs found

- http://www.markelliot.com/archive/june9.htm
- https://www.smartserve.ca/documents/10156/fd0cb346-3553-4c4c-992f-d9e6cd4c37bb
- https://www.youtube.com/embed/2gn-QZ_e06k?rel=0
- https://www.youtube.com/embed/YmwMRIG4GNY?rel=0

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
