const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 7
  },
  "chapter": {
    "id": "chapter-7",
    "title": "7 Forensic Genetics",
    "code": "Module 7",
    "summary": "Learn how DNA profiling, genetics, and population data support forensic investigations.",
    "componentCount": 21
  },
  "quiz": {
    "id": "quiz-7",
    "title": "M7 Forensic Genetics Assessment",
    "multipleChoice": [
      {
        "number": 1,
        "prompt": "Which of the following features is similar within the cells of all biological organisms?",
        "options": [
          {
            "label": "A",
            "text": "Number of nucleic acids"
          },
          {
            "label": "B",
            "text": "Organelles"
          },
          {
            "label": "C",
            "text": "Number of chromosomes"
          },
          {
            "label": "D",
            "text": "Genes"
          }
        ],
        "answer": "B"
      },
      {
        "number": 2,
        "prompt": "Human body cells have _________ chromosomes. Human sex cells have ________ chromosomes.",
        "options": [
          {
            "label": "A",
            "text": "22, 23"
          },
          {
            "label": "B",
            "text": "46, 23"
          },
          {
            "label": "C",
            "text": "23, 23"
          },
          {
            "label": "D",
            "text": "23, 46"
          }
        ],
        "answer": "B"
      },
      {
        "number": 3,
        "prompt": "The chromosomes in the cells provide directions for the creation of",
        "options": [
          {
            "label": "A",
            "text": "PCR"
          },
          {
            "label": "B",
            "text": "proteins"
          },
          {
            "label": "C",
            "text": "hydrogen bonds"
          },
          {
            "label": "D",
            "text": "RFLP"
          }
        ],
        "answer": "B"
      },
      {
        "number": 4,
        "prompt": "For a DNA match to be declared, how many unique sections of DNA must be found?",
        "options": [
          {
            "label": "A",
            "text": "46"
          },
          {
            "label": "B",
            "text": "23"
          },
          {
            "label": "C",
            "text": "25"
          },
          {
            "label": "D",
            "text": "5"
          }
        ],
        "answer": "D"
      },
      {
        "number": 5,
        "prompt": "What type of body fluid can DNA be extracted from and analyzed?",
        "options": [
          {
            "label": "A",
            "text": "Blood"
          },
          {
            "label": "B",
            "text": "Sweat"
          },
          {
            "label": "C",
            "text": "Tears"
          },
          {
            "label": "D",
            "text": "Urine"
          }
        ],
        "answer": "A"
      },
      {
        "number": 6,
        "prompt": "What percentage of your DNA is considered \"junk\" DNA?",
        "options": [
          {
            "label": "A",
            "text": "95%"
          },
          {
            "label": "B",
            "text": "50%"
          },
          {
            "label": "C",
            "text": "10%"
          },
          {
            "label": "D",
            "text": "0%"
          }
        ],
        "answer": "A"
      },
      {
        "number": 7,
        "prompt": "Which two biological family members have the same mtDNA?",
        "options": [
          {
            "label": "A",
            "text": "father and son"
          },
          {
            "label": "B",
            "text": "brother and sister"
          },
          {
            "label": "C",
            "text": "maternal grandfather and grandson"
          },
          {
            "label": "D",
            "text": "paternal uncle and niece"
          }
        ],
        "answer": "B"
      },
      {
        "number": 8,
        "prompt": "The mitochondria is unique in that it is the only organelle other than the nucleus that contains",
        "options": [
          {
            "label": "A",
            "text": "ATP"
          },
          {
            "label": "B",
            "text": "proteins"
          },
          {
            "label": "C",
            "text": "DNA"
          },
          {
            "label": "D",
            "text": "cytoplasm"
          }
        ],
        "answer": "C"
      },
      {
        "number": 9,
        "prompt": "The main function of the mitochondria in the cell is",
        "options": [
          {
            "label": "A",
            "text": "DNA replication"
          },
          {
            "label": "B",
            "text": "energy production"
          },
          {
            "label": "C",
            "text": "gene replication"
          },
          {
            "label": "D",
            "text": "protein production"
          }
        ],
        "answer": "B"
      },
      {
        "number": 10,
        "prompt": "All the genetic material in the mitochondria is inherited from an individual's",
        "options": [
          {
            "label": "A",
            "text": "mother"
          },
          {
            "label": "B",
            "text": "uncle"
          },
          {
            "label": "C",
            "text": "aunt"
          },
          {
            "label": "D",
            "text": "father"
          }
        ],
        "answer": "A"
      },
      {
        "number": 11,
        "prompt": "How many loci are examined when a forensic DNA match is being attempted?",
        "options": [
          {
            "label": "A",
            "text": "23"
          },
          {
            "label": "B",
            "text": "46"
          },
          {
            "label": "C",
            "text": "1"
          },
          {
            "label": "D",
            "text": "5"
          }
        ],
        "answer": "D"
      },
      {
        "number": 12,
        "prompt": "Probability ratios with each DNA match would be unnecessary if",
        "options": [
          {
            "label": "A",
            "text": "all human DNA was recorded in a data bank"
          },
          {
            "label": "B",
            "text": "contamination of DNA evidence collected did not occur"
          },
          {
            "label": "C",
            "text": "all STR sequences contained more nucleic acids"
          },
          {
            "label": "D",
            "text": "laboratory interpretation errors did not occur"
          }
        ],
        "answer": "A"
      },
      {
        "number": 13,
        "prompt": "The probability ratio that is included with every DNA match indicates the",
        "options": [
          {
            "label": "A",
            "text": "accuracy of the match as compared to other matches"
          },
          {
            "label": "B",
            "text": "occurrence of laboratory interpretation errors"
          },
          {
            "label": "C",
            "text": "number of STR sequences that matched the crime scene sample"
          },
          {
            "label": "D",
            "text": "numerical chance the DNA patterns analyzed could be found in someone else"
          }
        ],
        "answer": "D"
      }
    ]
  },
  "assignment": {
    "id": "assignment-7",
    "title": "Forensic Genetics Lab Assignment",
    "file": "module7assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module7assignment-app.jsx",
      "module7assignment-entry.jsx",
      "module7assignment.bundle.js",
      "module7assignment.html"
    ],
    "assetFiles": []
  },
  "resources": [
    {
      "title": "http://commons.wikimedia.org/",
      "href": "http://commons.wikimedia.org/"
    },
    {
      "title": "http://gimp-savvy.com/PHOTO-ARCHIVE/",
      "href": "http://gimp-savvy.com/PHOTO-ARCHIVE/"
    },
    {
      "title": "http://www.clipart.com/",
      "href": "http://www.clipart.com/"
    },
    {
      "title": "http://www.cnn.com/2003/LAW/11/03/laci.peterson.dna.ap/index.html",
      "href": "http://www.cnn.com/2003/LAW/11/03/laci.peterson.dna.ap/index.html"
    },
    {
      "title": "https://static01.nyt.com/images/2014/09/03/us/JP-CAROLINA1/JP-CAROLINA1-master1050.jpg",
      "href": "https://static01.nyt.com/images/2014/09/03/us/JP-CAROLINA1/JP-CAROLINA1-master1050.jpg"
    },
    {
      "title": "https://www.youtube.com/embed/AkBUriMK9u8?rel=0",
      "href": "https://www.youtube.com/embed/AkBUriMK9u8?rel=0"
    },
    {
      "title": "https://www.youtube.com/embed/DbR9xMXuK7c?rel=0",
      "href": "https://www.youtube.com/embed/DbR9xMXuK7c?rel=0"
    },
    {
      "title": "Forensic Genetics Lab Assignment",
      "href": "./assignment/module7assignment.html"
    },
    {
      "title": "M7 Forensic Genetics Assessment",
      "href": "#quiz"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
