# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-7\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 7
- Title: 7 Forensic Genetics
- Quiz: quiz-7
- Quiz answer key: B B B D A A B C B A D A D
- Assignment: assignment-7

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module7assignment-app.jsx`
- `module7assignment-entry.jsx`
- `module7assignment.bundle.js`
- `module7assignment.html`

## Assignment assets copied

- None

## Image paths rewritten

- Local images copied: 27
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i5ab5b8bc-ea65-480c-9da5-effe6a5367a6\Content\ladder.jpg -> assets/images/module-7-image-01.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i5d4f2f7c-e59a-46c8-9c32-c75ed83f90e6\Content\Red DNA Petri Dish.jpg -> assets/images/module-7-image-02.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\if7f77bcb-3fd8-4082-8c3f-1846bd6ab392\Content\animal-cell-diagram.png -> assets/images/module-7-image-03.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\if7f77bcb-3fd8-4082-8c3f-1846bd6ab392\Content\female_male_chrom_fig2.jpg -> assets/images/module-7-image-04.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i71043ac1-3088-4bee-bbd4-206b7b84385f\Content\dnastructure.jpg -> assets/images/module-7-image-05.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\eukaryote-dna.svg -> assets/images/module-7-image-06.svg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i0f9723f9-0ae9-4109-a1ef-5ff80cae7681\Content\jeffreys-300x184.png -> assets/images/module-7-image-07.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i0f9723f9-0ae9-4109-a1ef-5ff80cae7681\Content\dna_fingerprinting_sm.jpg -> assets/images/module-7-image-08.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i9af372bf-bd8b-4b30-bfb5-f143a26fd95a\Content\RFLP DNA (3).jpg -> assets/images/module-7-image-09.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i17dc985a-a256-48e6-ac53-7d6e6be9945e\Content\mitochondrion.jpg -> assets/images/module-7-image-10.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i148eaf13-e685-4f16-b445-643f7511fbf0\Content\mtDNA.jpg -> assets/images/module-7-image-11.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i148eaf13-e685-4f16-b445-643f7511fbf0\Content\practice98_2-1.gif -> assets/images/module-7-image-12.gif
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ic0d89ebf-700c-4baa-a78d-5f8f50f59d3c\Content\ndna-vs-mtdna.jpg -> assets/images/module-7-image-13.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i864f0f6f-54b2-4d9d-aae2-cc3872177ec8\Content\Unknown-Soldier-Casket.jpg -> assets/images/module-7-image-14.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\tomb-unknown-soldier-guard-2012.jpg -> assets/images/module-7-image-15.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i864f0f6f-54b2-4d9d-aae2-cc3872177ec8\Content\romanovs.jpg -> assets/images/module-7-image-16.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\world-trade-center-9-11.jpg -> assets/images/module-7-image-17.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i16157390-e22b-49f6-b519-ab6887cba9b3\Content\Pentagonheader.jpg -> assets/images/module-7-image-18.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i533446d7-727a-47e8-80c9-77dec9de40e8\Content\dna-profiling-1 (1).jpg -> assets/images/module-7-image-19.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ida124b68-5b7d-43eb-aa93-2ca97b516eb9\Content\dnaprofile-pic.jpg -> assets/images/module-7-image-20.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i73921e7a-03fe-4d7e-991e-0209b5fd9ec8\Content\DNA-and-Handcuffs.jpg -> assets/images/module-7-image-21.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i73921e7a-03fe-4d7e-991e-0209b5fd9ec8\Content\MKN5D6I13KL6K22.png -> assets/images/module-7-image-22.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i42d255ea-4a86-47e1-9752-2824b5a18232\Content\simsponglove__130320200103-275x297.jpg -> assets/images/module-7-image-23.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\id02bf765-6520-4f5c-8952-f223950c5123\Content\dna_sequence-705x400.jpg -> assets/images/module-7-image-24.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2d953e88-05b7-46e8-ab99-8bbdc6aa7e88\Content\Punky.jpg -> assets/images/module-7-image-25.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i8fca4d43-9030-4991-9ce9-e078260f3c51\Content\Sabrina Buie.jpg -> assets/images/module-7-image-26.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i8fca4d43-9030-4991-9ce9-e078260f3c51\Content\HenryLeon.jpeg -> assets/images/module-7-image-27.jpeg

## External URLs found

- http://commons.wikimedia.org/
- http://gimp-savvy.com/PHOTO-ARCHIVE/
- http://www.clipart.com/
- http://www.cnn.com/2003/LAW/11/03/laci.peterson.dna.ap/index.html
- https://static01.nyt.com/images/2014/09/03/us/JP-CAROLINA1/JP-CAROLINA1-master1050.jpg
- https://www.youtube.com/embed/AkBUriMK9u8?rel=0
- https://www.youtube.com/embed/DbR9xMXuK7c?rel=0

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
