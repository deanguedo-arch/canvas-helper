# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-6\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 6
- Title: 6 Polygraphing and Document Analysis
- Quiz: quiz-6
- Quiz answer key: C A B A A C A D B A B A D A C A D C D D A D A B
- Assignment: assignment-6

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module6assignment-app.jsx`
- `module6assignment-entry.jsx`
- `module6assignment.bundle.js`
- `module6assignment.html`

## Assignment assets copied

- None

## Image paths rewritten

- Local images copied: 30
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i21fc9773-877f-49ab-893d-c4f7c2c19448\Content\Poly Room.jpg -> assets/images/module-6-image-01.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i21fc9773-877f-49ab-893d-c4f7c2c19448\Content\Polygraph(1).jpg -> assets/images/module-6-image-02.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ia5c7c2b4-1e9b-4279-9c4e-efd45abb03ae\Content\Close up Poly.jpg -> assets/images/module-6-image-03.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ia2ca2ecb-3750-4094-9486-e6e0e2d522ea\Content\Nervous System.jpg -> assets/images/module-6-image-04.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ia2ca2ecb-3750-4094-9486-e6e0e2d522ea\Content\nerve_system_chart_654px.jpg -> assets/images/module-6-image-05.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ia2ca2ecb-3750-4094-9486-e6e0e2d522ea\Content\Nerves.jpg -> assets/images/module-6-image-06.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\polygraph-test.jpg -> assets/images/module-6-image-07.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i38c48eab-1542-4f6d-8852-1d3643a3d094\Content\lie detector.jpg -> assets/images/module-6-image-08.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ieede7310-7252-4ea7-b239-ae98402ce479\Content\polygraph(2).jpg -> assets/images/module-6-image-09.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\ieb74262a-13e6-4bcb-b504-562d8053d730\Content\ben stiller lie detector.jpg -> assets/images/module-6-image-10.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i3ef76257-9096-4f62-8f92-b296e1386cc9\Content\Polygraph2.jpg -> assets/images/module-6-image-11.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i8edf298b-e9ff-4bb0-89de-dbf1e5e2f7a4\Content\Polygraph3.jpg -> assets/images/module-6-image-12.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i8edf298b-e9ff-4bb0-89de-dbf1e5e2f7a4\Content\Polygraph4.jpg -> assets/images/module-6-image-13.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i389226fa-4098-4e3b-8744-dffc641fac3a\Content\polygraph-chart1.png -> assets/images/module-6-image-14.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i389226fa-4098-4e3b-8744-dffc641fac3a\Content\Chart tracings.JPG -> assets/images/module-6-image-15.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\robert-hanssen.jpg -> assets/images/module-6-image-16.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i3c41cc47-cbc8-40f2-8763-d225cbee3378\Content\jonbenet_ramsey_murder.jpg -> assets/images/module-6-image-17.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i3c41cc47-cbc8-40f2-8763-d225cbee3378\Content\1297483785527_ORIGINAL.jpg -> assets/images/module-6-image-18.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i0f26b308-575d-4298-b45e-2b628913bd42\Content\forensic_document_examination.jpg -> assets/images/module-6-image-19.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i88bfb601-8b90-4e70-beb3-9bbfc67f6212\Content\jack-ripper4.jpg -> assets/images/module-6-image-20.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6a149735-6b5b-48e0-a47a-95549fa6faa9\Content\NewNoteScan-p1-Crop.jpg -> assets/images/module-6-image-21.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iebace7d3-648a-4ec1-a080-ddfcef46a54d\Content\la-102301brokaw_letter -> assets/images/module-6-image-22.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iebace7d3-648a-4ec1-a080-ddfcef46a54d\Content\Leahy-letter-front_a.jpg -> assets/images/module-6-image-23.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2bc0fb46-6a9c-45e6-9505-39ec39daa7cd\Content\8537694_orig.jpeg -> assets/images/module-6-image-24.jpeg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i28f50839-9318-4d75-bd15-457ab3d3cc04\Content\infographic-polygraph.jpg -> assets/images/module-6-image-25.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i9de295d9-d55b-4a60-ac4a-1e9ca89e7f72\Content\Susan Smith.jpeg -> assets/images/module-6-image-26.jpeg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7d5f46b8-ccf0-4b56-a4a6-c2c0fa7a94aa\Content\Lindberg Ransom Note.jpg -> assets/images/module-6-image-27.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7d5f46b8-ccf0-4b56-a4a6-c2c0fa7a94aa\Content\list-10-things-charles-lindbergh-E.jpeg -> assets/images/module-6-image-28.jpeg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7d5f46b8-ccf0-4b56-a4a6-c2c0fa7a94aa\Content\handwriting-analysis-7.jpg -> assets/images/module-6-image-29.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7d5f46b8-ccf0-4b56-a4a6-c2c0fa7a94aa\Content\Bruno H.jpg -> assets/images/module-6-image-30.jpg

## External URLs found

- http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/Images/lusk_bigger.jpg
- http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/L1/MRI.htm
- http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/L1/cognitive.htm
- http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/module5/Images/polyoffice.JPG
- http://www.casebook.org/ripper_letters/
- http://www.cnn.com/
- https://www.youtube.com/embed/6diqpGKOvic?rel=0

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
