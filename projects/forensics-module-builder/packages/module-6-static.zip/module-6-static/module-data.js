const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 6
  },
  "chapter": {
    "id": "chapter-6",
    "title": "6 Polygraphing and Document Analysis",
    "code": "Module 6",
    "summary": "Explore polygraphing, questioned documents, and how investigators use writing analysis in case work.",
    "componentCount": 21
  },
  "quiz": {
    "id": "quiz-6",
    "title": "M6 The Polygraph and Writing Analysis Assessment",
    "multipleChoice": [
      {
        "number": 1,
        "prompt": "During the stress of lying, the body's involuntary actions are controlled by the",
        "options": [
          {
            "label": "A",
            "text": "central nervous system"
          },
          {
            "label": "B",
            "text": "parasympathetic nervous system"
          },
          {
            "label": "C",
            "text": "sympathetic nervous system"
          },
          {
            "label": "D",
            "text": "somatic nervous system"
          }
        ],
        "answer": "C"
      },
      {
        "number": 2,
        "prompt": "A large supply of blood is directed to the limbs during stress to",
        "options": [
          {
            "label": "A",
            "text": "allow quick movements if necessary"
          },
          {
            "label": "B",
            "text": "prevent the feeling of any pain"
          },
          {
            "label": "C",
            "text": "prevent any aggressive reactions"
          },
          {
            "label": "D",
            "text": "save energy that may be needed later"
          }
        ],
        "answer": "A"
      },
      {
        "number": 3,
        "prompt": "The stress responses that are monitored by the polygraph instrument are",
        "options": [
          {
            "label": "A",
            "text": "blood pressure, digestive activities, and blood glucose levels"
          },
          {
            "label": "B",
            "text": "perspiration, heart rate, blood pressure, and breathing rate"
          },
          {
            "label": "C",
            "text": "heart rate, blood pressure, digestive activities, and pupil dilation"
          },
          {
            "label": "D",
            "text": "perspiration, heart rate, pupil dilation, and glycogen conversion"
          }
        ],
        "answer": "B"
      },
      {
        "number": 4,
        "prompt": "Select the four physiological activities below that occur when a person is telling a lie.",
        "options": [
          {
            "label": "A",
            "text": "Increase in digestive activities"
          },
          {
            "label": "B",
            "text": "Decrease in digestive activities"
          },
          {
            "label": "C",
            "text": "Increase in perspiration"
          },
          {
            "label": "D",
            "text": "Increase in heart rate and blood pressure"
          },
          {
            "label": "E",
            "text": "Increase in breathing rate"
          },
          {
            "label": "F",
            "text": "Decrease in perspiration"
          },
          {
            "label": "G",
            "text": "Decrease in breathing rate"
          },
          {
            "label": "H",
            "text": "Decrease in heart rate and blood pressure"
          }
        ],
        "answer": "A"
      },
      {
        "number": 5,
        "prompt": "Another name for the response that occurs during stress is",
        "options": [
          {
            "label": "A",
            "text": "fight or fight"
          },
          {
            "label": "B",
            "text": "rest and digest"
          },
          {
            "label": "C",
            "text": "scrap or scream"
          },
          {
            "label": "D",
            "text": "relax and absorb"
          }
        ],
        "answer": "A"
      },
      {
        "number": 6,
        "prompt": "What did Leonarde Keeler add to the polygraph instrument developed by John Larson?",
        "options": [
          {
            "label": "A",
            "text": "Cardiospymograph"
          },
          {
            "label": "B",
            "text": "Pneumograph"
          },
          {
            "label": "C",
            "text": "Galvanometer"
          },
          {
            "label": "D",
            "text": "Sphygomometer"
          }
        ],
        "answer": "C"
      },
      {
        "number": 7,
        "prompt": "The first polygraph instrument developed by Dr. William Marston measured",
        "options": [
          {
            "label": "A",
            "text": "blood pressure"
          },
          {
            "label": "B",
            "text": "breathing rate"
          },
          {
            "label": "C",
            "text": "pupil dilation"
          },
          {
            "label": "D",
            "text": "heart rate"
          }
        ],
        "answer": "A"
      },
      {
        "number": 8,
        "prompt": "What do the two pneumographs of the polygraph instrument measure?",
        "options": [
          {
            "label": "A",
            "text": "blood pressure"
          },
          {
            "label": "B",
            "text": "heart rate"
          },
          {
            "label": "C",
            "text": "skin conductivity"
          },
          {
            "label": "D",
            "text": "breathing rate"
          }
        ],
        "answer": "D"
      },
      {
        "number": 9,
        "prompt": "Why is the galvanometer in the polygraph instrument able to measure perspiration levels using electricity?",
        "options": [
          {
            "label": "A",
            "text": "Oils in sweat absorb some electric currents."
          },
          {
            "label": "B",
            "text": "Water and salt in sweat conduct electricity."
          },
          {
            "label": "C",
            "text": "Heat generated during perspiration conducts electricity."
          },
          {
            "label": "D",
            "text": "Sodium in sweat creates a small electric current."
          }
        ],
        "answer": "B"
      },
      {
        "number": 10,
        "prompt": "The device that records electrical conductivity by sending an electric current onto the skin is called a:",
        "options": [
          {
            "label": "A",
            "text": "cardiospymograph"
          },
          {
            "label": "B",
            "text": "electrocardiogram"
          },
          {
            "label": "C",
            "text": "pneumograph"
          },
          {
            "label": "D",
            "text": "ultrasound"
          }
        ],
        "answer": "A"
      },
      {
        "number": 11,
        "prompt": "The device that takes a reading of a person's heart rate and blood pressure is called a:",
        "options": [
          {
            "label": "A",
            "text": "cardiograph"
          },
          {
            "label": "B",
            "text": "cardiospymograph"
          },
          {
            "label": "C",
            "text": "pneumograph"
          },
          {
            "label": "D",
            "text": "electrocardiogram"
          }
        ],
        "answer": "B"
      },
      {
        "number": 12,
        "prompt": "The device that allows for the volume of air within its tubes to change during breathing is called a:",
        "options": [
          {
            "label": "A",
            "text": "pneumograph"
          },
          {
            "label": "B",
            "text": "cardiospymograph"
          },
          {
            "label": "C",
            "text": "breathalyzer"
          },
          {
            "label": "D",
            "text": "pneumogram"
          }
        ],
        "answer": "A"
      },
      {
        "number": 13,
        "prompt": "Which choice correctly identifies the three phases of a polygraph examination?",
        "options": [
          {
            "label": "A",
            "text": "Stimulation test, Questioning procedure, Control Question Technique"
          },
          {
            "label": "B",
            "text": "Stimulation test, Post-test interview, Control Question Technique"
          },
          {
            "label": "C",
            "text": "Pre-test interview, Stimulation test, Questioning procedure"
          },
          {
            "label": "D",
            "text": "Pre-test interview, Questioning procedure, Post-test interview/analysis"
          }
        ],
        "answer": "D"
      },
      {
        "number": 14,
        "prompt": "The underlying goal of the pre-test interview is to",
        "options": [
          {
            "label": "A",
            "text": "impress upon the subject that lying will be easily spotted"
          },
          {
            "label": "B",
            "text": "resolve any of the subject's anxieties and uncertainties"
          },
          {
            "label": "C",
            "text": "inform the subject of all of his or her legal rights"
          },
          {
            "label": "D",
            "text": "question the subject about his or her personal opinions and beliefs"
          }
        ],
        "answer": "A"
      },
      {
        "number": 15,
        "prompt": "What type of polygraph questioning technique is used in criminal investigations?",
        "options": [
          {
            "label": "A",
            "text": "Stimulation Test Technique (STT)"
          },
          {
            "label": "B",
            "text": "Concealed Information Technique (CIT)"
          },
          {
            "label": "C",
            "text": "Control Question Technique (CQT)"
          },
          {
            "label": "D",
            "text": "Relevant/Irrelevant Technique (R/I)"
          }
        ],
        "answer": "C"
      },
      {
        "number": 16,
        "prompt": "During a polygraph examination for a criminal investigation, it is important that the subject does not",
        "options": [
          {
            "label": "A",
            "text": "know whether he or she is being asked control or relevant questions"
          },
          {
            "label": "B",
            "text": "identify any of the guilty suspects involved with the crime"
          },
          {
            "label": "C",
            "text": "demonstrate any painful or negative emotions"
          },
          {
            "label": "D",
            "text": "understand the difference between truth and deception"
          }
        ],
        "answer": "A"
      },
      {
        "number": 17,
        "prompt": "During the pre-test interview a suspect becomes involved in the creation of the",
        "options": [
          {
            "label": "A",
            "text": "concealed questions"
          },
          {
            "label": "B",
            "text": "irrelevant questions"
          },
          {
            "label": "C",
            "text": "relevant questions"
          },
          {
            "label": "D",
            "text": "control questions"
          }
        ],
        "answer": "D"
      },
      {
        "number": 18,
        "prompt": "What type of questions focus upon behaviours that are similar in nature to the crime being investigated?",
        "options": [
          {
            "label": "A",
            "text": "Relevant"
          },
          {
            "label": "B",
            "text": "Concealed"
          },
          {
            "label": "C",
            "text": "Control"
          },
          {
            "label": "D",
            "text": "Irrelevant"
          }
        ],
        "answer": "C"
      },
      {
        "number": 19,
        "prompt": "A polygraph examination is an effective criminal investigative tool used to",
        "options": [
          {
            "label": "A",
            "text": "argue whether a suspect's alibi is accurate"
          },
          {
            "label": "B",
            "text": "understand a suspect's motive for committing the crime"
          },
          {
            "label": "C",
            "text": "question a suspect's knowledge of crime scene details"
          },
          {
            "label": "D",
            "text": "interrogate a suspect in the hope of getting a confession"
          }
        ],
        "answer": "D"
      },
      {
        "number": 20,
        "prompt": "Those trained to administer polygraph tests to criminal suspects are usually",
        "options": [
          {
            "label": "A",
            "text": "psychologists"
          },
          {
            "label": "B",
            "text": "lawyers"
          },
          {
            "label": "C",
            "text": "social workers"
          },
          {
            "label": "D",
            "text": "police officers"
          }
        ],
        "answer": "D"
      },
      {
        "number": 21,
        "prompt": "The forensic analysis of handwriting is based upon the premise that",
        "options": [
          {
            "label": "A",
            "text": "each person has a unique handwriting style"
          },
          {
            "label": "B",
            "text": "each person writes certain words the same way"
          },
          {
            "label": "C",
            "text": "each person's writing tends to change according to his or her mood"
          },
          {
            "label": "D",
            "text": "each person's writing tends to remain the same since childhood"
          }
        ],
        "answer": "A"
      },
      {
        "number": 22,
        "prompt": "The slope of handwritten text is the most noticeable when",
        "options": [
          {
            "label": "A",
            "text": "the writer uses a pencil"
          },
          {
            "label": "B",
            "text": "the writer uses a black pen"
          },
          {
            "label": "C",
            "text": "it is written upon yellow paper"
          },
          {
            "label": "D",
            "text": "it is written upon unlined paper"
          }
        ],
        "answer": "D"
      },
      {
        "number": 23,
        "prompt": "Often, the letters written in a deliberately disguised way are",
        "options": [
          {
            "label": "A",
            "text": "larger than normal"
          },
          {
            "label": "B",
            "text": "smaller than normal"
          },
          {
            "label": "C",
            "text": "more simple than normal"
          },
          {
            "label": "D",
            "text": "more complex than normal"
          }
        ],
        "answer": "A"
      },
      {
        "number": 24,
        "prompt": "What technique can be used to help individualize the type of ink used in a questionable document?",
        "options": [
          {
            "label": "A",
            "text": "Graphology"
          },
          {
            "label": "B",
            "text": "Chromatography"
          },
          {
            "label": "C",
            "text": "Intoxilyzer testing"
          },
          {
            "label": "D",
            "text": "Criminal profiling"
          }
        ],
        "answer": "B"
      }
    ]
  },
  "assignment": {
    "id": "assignment-6",
    "title": "Polygraph and Document Analysis Lab",
    "file": "module6assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module6assignment-app.jsx",
      "module6assignment-entry.jsx",
      "module6assignment.bundle.js",
      "module6assignment.html"
    ],
    "assetFiles": []
  },
  "resources": [
    {
      "title": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/Images/lusk_bigger.jpg",
      "href": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/Images/lusk_bigger.jpg"
    },
    {
      "title": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/L1/MRI.htm",
      "href": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/L1/MRI.htm"
    },
    {
      "title": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/L1/cognitive.htm",
      "href": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/Module5/L1/cognitive.htm"
    },
    {
      "title": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/module5/Images/polyoffice.JPG",
      "href": "http://d2l.adlc.ca/content/ADLC-Depts/Forensics/LDC2754-3c-08Jun06/module5/Images/polyoffice.JPG"
    },
    {
      "title": "http://www.casebook.org/ripper_letters/",
      "href": "http://www.casebook.org/ripper_letters/"
    },
    {
      "title": "http://www.cnn.com/",
      "href": "http://www.cnn.com/"
    },
    {
      "title": "https://www.youtube.com/embed/6diqpGKOvic?rel=0",
      "href": "https://www.youtube.com/embed/6diqpGKOvic?rel=0"
    },
    {
      "title": "Polygraph and Document Analysis Lab",
      "href": "./assignment/module6assignment.html"
    },
    {
      "title": "M6 The Polygraph and Writing Analysis Assessment",
      "href": "#quiz"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
