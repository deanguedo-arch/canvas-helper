# Acceptance Checklist

[ ] Module opens locally through http://localhost:8080
[ ] Sidebar navigation works
[ ] Overview tab displays correct module only
[ ] Lesson tab displays correct module lesson content
[ ] No lesson cards are locked or blurred
[ ] No Mark Complete buttons remain
[ ] No Course progress UI remains
[ ] Local lesson images load
[ ] External videos/iframes still load
[ ] Quiz tab displays correct module quiz only, or no-quiz message for Module 8
[ ] Quiz scores correctly, if quiz exists
[ ] Quiz has Try Again, if quiz exists
[ ] Assignment tab displays correct module assignment
[ ] Assignment has full-screen open button
[ ] No Firebase references remain
[ ] No hosted-runtime-content references remain
[ ] No old D2L export paths are fetched at runtime
[ ] No wrong-module code remains
[ ] No localStorage/sessionStorage progress logic remains
[ ] No console errors during normal use
