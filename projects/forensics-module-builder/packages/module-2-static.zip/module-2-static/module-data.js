const MODULE_DATA = {
  "course": {
    "title": "Forensic Studies 25"
  },
  "module": {
    "number": 2
  },
  "chapter": {
    "id": "chapter-2",
    "title": "2 Types of Evidence and Fingerprint Analysis",
    "code": "Module 2",
    "summary": "Learn how evidence is classified, analyzed, and connected through fingerprint work and case studies.",
    "componentCount": 17
  },
  "quiz": {
    "id": "quiz-2",
    "title": "M2 Types of Evidence and Fingerprint Analysis Assessment",
    "multipleChoice": [
      {
        "number": 1,
        "prompt": "Which of the following is an identified piece of physical evidence?",
        "options": [
          {
            "label": "A",
            "text": "Blood type"
          },
          {
            "label": "B",
            "text": "Bullet casings"
          },
          {
            "label": "C",
            "text": "Nuclear DNA"
          },
          {
            "label": "D",
            "text": "Fingerprint impression"
          }
        ],
        "answer": "A"
      },
      {
        "number": 2,
        "prompt": "In a court case, a piece of individualized physical evidence is more valuable than a piece of identified physical evidence because it can be",
        "options": [
          {
            "label": "A",
            "text": "linked directly to a specific individual"
          },
          {
            "label": "B",
            "text": "grouped into a class of items having similar properties"
          },
          {
            "label": "C",
            "text": "classified into various categories having different traits"
          },
          {
            "label": "D",
            "text": "considered to be circumstantial depending on the case"
          }
        ],
        "answer": "A"
      },
      {
        "number": 3,
        "prompt": "Which of the following pieces of physical evidence would most likely help convince a jury that a suspect is guilty?",
        "options": [
          {
            "label": "A",
            "text": "Shoe print"
          },
          {
            "label": "B",
            "text": "Blood type"
          },
          {
            "label": "C",
            "text": "A bullet"
          },
          {
            "label": "D",
            "text": "Clothing fibre"
          }
        ],
        "answer": "C"
      },
      {
        "number": 4,
        "prompt": "A defense lawyer would likely try to argue that any piece of physical evidence presented by the prosecution is",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "both identified and individualized"
          },
          {
            "label": "D",
            "text": "neither identified nor individualized"
          }
        ],
        "answer": "A"
      },
      {
        "number": 5,
        "prompt": "Scenario #1: When the shoes seized from a break-and-enter suspect were examined, a small piece of glass was found embedded in one sole. Analysis determined that the unique piece of glass came directly from the crime scene. Type of physical evidence =",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "could be considered identified or individualized"
          }
        ],
        "answer": "A"
      },
      {
        "number": 6,
        "prompt": "Scenario #2:A victim's body surfaced nine months after being dumped into a lake. The body had been tied to cement blocks with a torn bed sheet. Forensic scientists were asked to determine if a certain hammer caused the unique markings on the skull. The autopsy determined that the victim had been struck with a ball peen hammer. Type of physical evidence =",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "could be considered either type"
          }
        ],
        "answer": "A"
      },
      {
        "number": 7,
        "prompt": "Scenario #3: A plaster cast of a faint shoe print was taken from the scene of a burglary. It was compared to the tread of a suspect's shoe. The shoe print found at the scene appeared to match the tread of the suspect's right shoe. Type of physical evidence =",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "could be both identified and individualized"
          }
        ],
        "answer": "A"
      },
      {
        "number": 8,
        "prompt": "Scenario #4: Plaster casts were taken of a faint shoe print at a burglary scene and of a suspect's shoe. The tread of the shoe print found at the scene appeared to match the suspect's right shoe. Even the location of a staple stuck in the tread of the suspect's shoe matched the impression in the shoe print cast. Type of physical evidence =",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "could be considered identified and individualized"
          }
        ],
        "answer": "C"
      },
      {
        "number": 9,
        "prompt": "Scenario #5: The body of a hit-and-run victim was found next to a major highway. A suspect vehicle was located and examined. An impression of a watch wristband found on the car's bumper matched the hit-and-run victim's watch wristband. Type of physical evidence =",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "could be considered both identified and individualized"
          }
        ],
        "answer": "C"
      },
      {
        "number": 10,
        "prompt": "Scenario #6: A young boy was kidnapped and his parents were sent a stenciled ransom note. A stencil was later found at a suspect's home; it matched the stenciled letters on the ransom note. Type of physical evidence =",
        "options": [
          {
            "label": "A",
            "text": "identified"
          },
          {
            "label": "B",
            "text": "individualized"
          },
          {
            "label": "C",
            "text": "identified or individualized"
          }
        ],
        "answer": "A"
      },
      {
        "number": 11,
        "prompt": "The most common type of fingerprint ridge pattern is the",
        "options": [
          {
            "label": "A",
            "text": "Loop"
          },
          {
            "label": "B",
            "text": "Arch"
          },
          {
            "label": "C",
            "text": "Whorl"
          },
          {
            "label": "D",
            "text": "Latent"
          }
        ],
        "answer": "A"
      },
      {
        "number": 12,
        "prompt": "Which of the following is an example of physical fingerprint evidence?",
        "options": [
          {
            "label": "A",
            "text": "A fingerprint on a knife"
          },
          {
            "label": "B",
            "text": "A fingerprint left in blood"
          },
          {
            "label": "C",
            "text": "A fingerprint on a wine glass"
          },
          {
            "label": "D",
            "text": "A fingerprint embedded in candle wax"
          }
        ],
        "answer": "D"
      },
      {
        "number": 13,
        "prompt": "Where are fingerprint ridges located on the skin of the hand?",
        "options": [
          {
            "label": "A",
            "text": "Dermis"
          },
          {
            "label": "B",
            "text": "Minutiae"
          },
          {
            "label": "C",
            "text": "Epidermis"
          },
          {
            "label": "D",
            "text": "Sweat Glands"
          }
        ],
        "answer": "C"
      },
      {
        "number": 14,
        "prompt": "The reason latent fingerprints must be enhanced is they",
        "options": [
          {
            "label": "A",
            "text": "take a long time to identify"
          },
          {
            "label": "B",
            "text": "always prove a suspect is guilty"
          },
          {
            "label": "C",
            "text": "are not visible to the human eye"
          },
          {
            "label": "D",
            "text": "begin to decompose immediately"
          }
        ],
        "answer": "C"
      },
      {
        "number": 15,
        "prompt": "The type of lifting powder used by a forensic expert is often dependent upon",
        "options": [
          {
            "label": "A",
            "text": "personal preference"
          },
          {
            "label": "B",
            "text": "years of experience"
          },
          {
            "label": "C",
            "text": "type of crime committed"
          },
          {
            "label": "D",
            "text": "number of prints available"
          }
        ],
        "answer": "A"
      },
      {
        "number": 16,
        "prompt": "What is used to lift a fingerprint after lifting powder has been applied?",
        "options": [
          {
            "label": "A",
            "text": "Tape"
          },
          {
            "label": "B",
            "text": "Vacuum"
          },
          {
            "label": "C",
            "text": "Camera"
          },
          {
            "label": "D",
            "text": "Tweezers"
          }
        ],
        "answer": "A"
      },
      {
        "number": 17,
        "prompt": "The iodine used in the iodine fumigation process is a",
        "options": [
          {
            "label": "A",
            "text": "metallic liquid"
          },
          {
            "label": "B",
            "text": "semi-solid and has no charge"
          },
          {
            "label": "C",
            "text": "metal and produces positively-charged ions"
          },
          {
            "label": "D",
            "text": "non-metal and produces negatively-charged ions"
          }
        ],
        "answer": "D"
      },
      {
        "number": 18,
        "prompt": "The ion in sweat in a fingerprint to which iodide is attracted is",
        "options": [
          {
            "label": "A",
            "text": "sodium"
          },
          {
            "label": "B",
            "text": "chloride"
          },
          {
            "label": "C",
            "text": "sodium iodide"
          },
          {
            "label": "D",
            "text": "sodium chloride"
          }
        ],
        "answer": "A"
      },
      {
        "number": 19,
        "prompt": "What color is the sodium iodide that forms during iodine fumigation?",
        "options": [
          {
            "label": "A",
            "text": "Dark red"
          },
          {
            "label": "B",
            "text": "Light blue"
          },
          {
            "label": "C",
            "text": "Whitish grey"
          },
          {
            "label": "D",
            "text": "Dark brown/black"
          }
        ],
        "answer": "D"
      },
      {
        "number": 20,
        "prompt": "Cyanoacrylate is found in a commercial product known as",
        "options": [
          {
            "label": "A",
            "text": "Krazy Glue"
          },
          {
            "label": "B",
            "text": "Sodium Iodide"
          },
          {
            "label": "C",
            "text": "Fingerprint Glue"
          },
          {
            "label": "D",
            "text": "Sodium Chloride"
          }
        ],
        "answer": "A"
      },
      {
        "number": 21,
        "prompt": "To what substance found in a fingerprint will cyanoacrylate readily adhere?",
        "options": [
          {
            "label": "A",
            "text": "Tears"
          },
          {
            "label": "B",
            "text": "Cytoplasm"
          },
          {
            "label": "C",
            "text": "Body oil"
          },
          {
            "label": "D",
            "text": "None of the above"
          }
        ],
        "answer": "C"
      },
      {
        "number": 22,
        "prompt": "During the fumigation process, what must be present in the fumigation chamber in addition to cyanoacrylate?",
        "options": [
          {
            "label": "A",
            "text": "Iodine and water"
          },
          {
            "label": "B",
            "text": "Heat and moisture"
          },
          {
            "label": "C",
            "text": "Cold and air circulation"
          },
          {
            "label": "D",
            "text": "Fingerprinting powder and heat"
          }
        ],
        "answer": "B"
      },
      {
        "number": 23,
        "prompt": "What color does cyanoacrylate leave upon a fingerprint impression during fumigation?",
        "options": [
          {
            "label": "A",
            "text": "Dark red"
          },
          {
            "label": "B",
            "text": "Light blue"
          },
          {
            "label": "C",
            "text": "Whitish grey"
          },
          {
            "label": "D",
            "text": "Dark brown/black"
          }
        ],
        "answer": "C"
      },
      {
        "number": 24,
        "prompt": "An advantage of cyanoacrylate fumigation is that fingerprints exposed are",
        "options": [
          {
            "label": "A",
            "text": "larger"
          },
          {
            "label": "B",
            "text": "permanent"
          },
          {
            "label": "C",
            "text": "dark in color"
          },
          {
            "label": "D",
            "text": "complete within a few minutes"
          }
        ],
        "answer": "B"
      },
      {
        "number": 25,
        "prompt": "Identify the type of fingerprint enhancement technique that should be used to expose fingerprints found on a drinking glass or a window?",
        "options": [
          {
            "label": "A",
            "text": "Cyanoacrylate Fumigation"
          },
          {
            "label": "B",
            "text": "Lifting Powder"
          },
          {
            "label": "C",
            "text": "Iodine Fumigation"
          },
          {
            "label": "D",
            "text": "All of the above."
          }
        ],
        "answer": "B"
      },
      {
        "number": 26,
        "prompt": "What type of fingerprint enhancement technique should be used to expose fingerprints found on a knife handle?",
        "options": [
          {
            "label": "A",
            "text": "Cyanoacrylate Fumigation"
          },
          {
            "label": "B",
            "text": "Lifting Powder"
          },
          {
            "label": "C",
            "text": "Iodine Fumigation"
          },
          {
            "label": "D",
            "text": "None of the above"
          }
        ],
        "answer": "A"
      },
      {
        "number": 27,
        "prompt": "What type of fingerprint enhancement technique should be used to expose fingerprints found on a Five-dollar bill?",
        "options": [
          {
            "label": "A",
            "text": "Cyanoacrylate Fumigation"
          },
          {
            "label": "B",
            "text": "Lifting Powder"
          },
          {
            "label": "C",
            "text": "Iodine Fumigation"
          },
          {
            "label": "D",
            "text": "Cyanoacrylate Fumigation and Iodine Fumigation"
          }
        ],
        "answer": "C"
      }
    ]
  },
  "assignment": {
    "id": "assignment-2",
    "title": "Fingerprint Analysis Interactive Assignment",
    "file": "module2assignment.html",
    "files": [
      "forensic-assignment-print.js",
      "forensic-assignment-theme.css",
      "module2assignment-app.jsx",
      "module2assignment-entry.jsx",
      "module2assignment.bundle.js",
      "module2assignment.html"
    ],
    "assetFiles": [
      "module2/Loop.png",
      "module2/PlainArch.png",
      "module2/Whorl.png",
      "module2/suspect-atkins.svg",
      "module2/suspect-banes.svg",
      "module2/suspect-chapman.svg",
      "module2/suspect-lyons.svg"
    ]
  },
  "resources": [
    {
      "title": "http://moodle.aspenview.org:18321/mod/resource/view.php?id=5489",
      "href": "http://moodle.aspenview.org:18321/mod/resource/view.php?id=5489"
    },
    {
      "title": "http://moodle.aspenview.org:18321/mod/resource/view.php?id=5490",
      "href": "http://moodle.aspenview.org:18321/mod/resource/view.php?id=5490"
    },
    {
      "title": "http://www.forensicsciencesimplified.org/prints/principles.html",
      "href": "http://www.forensicsciencesimplified.org/prints/principles.html"
    },
    {
      "title": "https://upload.wikimedia.org/wikipedia/commons/a/ab/John_Dillinger_mug_shot.jpg",
      "href": "https://upload.wikimedia.org/wikipedia/commons/a/ab/John_Dillinger_mug_shot.jpg"
    },
    {
      "title": "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Francis_Galton_1850s.jpg/220px-Francis_Galton_1850s.jpg",
      "href": "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Francis_Galton_1850s.jpg/220px-Francis_Galton_1850s.jpg"
    },
    {
      "title": "https://www.youtube.com/embed/SQ9dYQ_OSPg?rel=0&amp;wmode=opaque",
      "href": "https://www.youtube.com/embed/SQ9dYQ_OSPg?rel=0&amp;wmode=opaque"
    },
    {
      "title": "https://www.youtube.com/embed/WZL7OpFq0fw?rel=0&amp;wmode=opaque",
      "href": "https://www.youtube.com/embed/WZL7OpFq0fw?rel=0&amp;wmode=opaque"
    },
    {
      "title": "Fingerprint Analysis Interactive Assignment",
      "href": "./assignment/module2assignment.html"
    },
    {
      "title": "M2 Types of Evidence and Fingerprint Analysis Assessment",
      "href": "#quiz"
    }
  ],
  "noQuizMessage": "No quiz is assigned for this module. Complete the lesson and assignment, then follow your teacher's Classroom instructions."
};
window.MODULE_DATA = MODULE_DATA;
