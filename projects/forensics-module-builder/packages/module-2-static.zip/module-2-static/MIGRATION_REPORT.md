# Migration Report

## Source files used

- `workspace\source-package\workspace-source\content\chapter-2\index.html`
- `workspace/source-package/workspace-source/course-data.js`

## Module data extracted

- Course: Forensic Studies 25
- Module: Module 2
- Title: 2 Types of Evidence and Fingerprint Analysis
- Quiz: quiz-2
- Quiz answer key: A A C A A A A C C A A D C C A A D A D A C B C B B A C
- Assignment: assignment-2

## Assignment files copied

- `forensic-assignment-print.js`
- `forensic-assignment-theme.css`
- `module2assignment-app.jsx`
- `module2assignment-entry.jsx`
- `module2assignment.bundle.js`
- `module2assignment.html`

## Assignment assets copied

- `module2/Loop.png`
- `module2/PlainArch.png`
- `module2/Whorl.png`
- `module2/suspect-atkins.svg`
- `module2/suspect-banes.svg`
- `module2/suspect-chapman.svg`
- `module2/suspect-lyons.svg`

## Image paths rewritten

- Local images copied: 25
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2fbe29e6-e968-4c68-8cd5-dde0abd398b1\Content\fingerprints.jpg -> assets/images/module-2-image-01.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i7024e9f0-219f-4bb5-9972-3b3b58365841\Content\smoking gun.jpeg -> assets/images/module-2-image-02.jpeg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i57b023f1-0b7e-4404-9d89-c9ef9914a6ac\Content\Laci Peterson.jpg -> assets/images/module-2-image-03.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\localized-images\juan-vucetich.jpg -> assets/images/module-2-image-04.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\assignments\module2\Loop.png -> assets/images/module-2-image-05.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2e500d83-0ea4-4c77-b639-f6acc6f291bd\radial and ulnar loops.png -> assets/images/module-2-image-06.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\assignments\module2\Whorl.png -> assets/images/module-2-image-07.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\assignments\module2\PlainArch.png -> assets/images/module-2-image-08.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i2e500d83-0ea4-4c77-b639-f6acc6f291bd\minutiae.png -> assets/images/module-2-image-09.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6090376e-1b88-4285-b676-c3fa0cee7a43\Content\scaring1.jpg -> assets/images/module-2-image-10.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i61d13a78-3d18-40e9-a7f7-3a44fbf59e80\Content\fingerprint-minutiae.jpg -> assets/images/module-2-image-11.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i6fc5f283-0bc6-4999-9efe-01ac5381f0b7\Content\dillingerprints.jpg -> assets/images/module-2-image-12.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iab21127f-086e-4953-8181-f8bb4215377c\lifting pwd brushes.png -> assets/images/module-2-image-13.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\iadb4c43b-aea4-42c7-b8a1-b9af3831ec0a\cyanoacrylate fugmigator.png -> assets/images/module-2-image-14.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i13e076dd-cf2b-46f6-86bc-7534a3937931\rsz_the-zodiac-killer-3.jpg -> assets/images/module-2-image-15.jpg
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\banknote.PNG -> assets/images/module-2-image-16.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\banknote2.PNG -> assets/images/module-2-image-17.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\glass1.PNG -> assets/images/module-2-image-18.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\print1.PNG -> assets/images/module-2-image-19.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\glass2.PNG -> assets/images/module-2-image-20.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\print2.PNG -> assets/images/module-2-image-21.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\Suspect 1.PNG -> assets/images/module-2-image-22.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\Suspect 2.PNG -> assets/images/module-2-image-23.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\Suspect 3.PNG -> assets/images/module-2-image-24.png
- C:\Users\dean.guedo\Documents\GitHub\canvas-helper\projects\forensics-module-builder\workspace\source-package\workspace-source\references\forensics\_ontent\i865e453c-30d0-4618-b4a7-cccf59e06d95\Content\Suspect4.png -> assets/images/module-2-image-25.png

## External URLs found

- http://moodle.aspenview.org:18321/mod/resource/view.php?id=5489
- http://moodle.aspenview.org:18321/mod/resource/view.php?id=5490
- http://www.forensicsciencesimplified.org/prints/principles.html
- https://upload.wikimedia.org/wikipedia/commons/a/ab/John_Dillinger_mug_shot.jpg
- https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Francis_Galton_1850s.jpg/220px-Francis_Galton_1850s.jpg
- https://www.youtube.com/embed/SQ9dYQ_OSPg?rel=0&amp;wmode=opaque
- https://www.youtube.com/embed/WZL7OpFq0fw?rel=0&amp;wmode=opaque

## Unresolved references

- None

## Compromises

- Lesson content is normalized into a static iframe page.
- Assignment runtime is copied except JavaScript browser-storage calls are replaced with no-op storage handlers.
