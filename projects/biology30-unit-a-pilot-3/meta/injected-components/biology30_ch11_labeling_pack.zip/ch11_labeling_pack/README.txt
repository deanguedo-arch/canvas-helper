Biology 30 Chapter 11 Labeling Pack

Contents:
- 8 final PNG images in /images
- answer_key.json (best for Codex / programmatic use)
- answer_key.md (human-readable answer list)

Notes:
- Answers are intended to be matched case-insensitively.
- Alias answers are included where appropriate.
- The keys reflect the current final image label placement.
