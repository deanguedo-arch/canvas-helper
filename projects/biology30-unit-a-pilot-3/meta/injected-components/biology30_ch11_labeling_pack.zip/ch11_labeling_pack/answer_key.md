# Biology 30 Chapter 11 Labeling Images — Answer Key

This package includes the final image files plus a Codex-friendly JSON answer key.
Use `answer_key.json` in code. This markdown file is the quick human-readable version.

## 01. Neuron Anatomy
- A — dendrite
- B — cell body / soma
- C — nucleus
- D — axon
- E — myelin sheath / myelin
- F — Schwann cell nucleus / Schwann cell
- G — node of Ranvier
- H — axon terminal / terminal branches

## 02. Withdrawal Reflex Pathway
- A — stimulus
- B — sensory receptor / pain receptor
- C — sensory neuron
- D — sensory neuron terminal in spinal cord
- E — interneuron
- F — spinal cord
- G — motor neuron cell body
- H — motor neuron / motor axon
- I — effector / muscle
- J — response / withdrawal response

## 03. Resting Membrane Potential
- A — outside of neuron / extracellular fluid
- B — inside of neuron / intracellular fluid
- C — sodium-potassium pump
- D — sodium ion (Na+)
- E — potassium ion (K+)
- F — potassium leak channel
- G — large negatively charged proteins / anions
- H — resting membrane potential / -70 mV

## 04. Action Potential
- A — resting potential
- B — threshold
- C — depolarization
- D — repolarization
- E — hyperpolarization
- F — action potential / nerve impulse
- G — absolute refractory period
- H — relative refractory period

## 05. Chemical Synapse
- A — presynaptic terminal / axon terminal
- B — synaptic vesicle
- C — neurotransmitter
- D — synaptic cleft
- F — postsynaptic membrane
- G — ion channel / ligand-gated ion channel
- H — postsynaptic neuron / postsynaptic cell

## 06. Major Brain Structures
- A — cerebellum
- B — medulla oblongata
- C — pons
- D — midbrain
- E — thalamus
- F — hypothalamus
- G — cerebrum

## 07. Cerebral Lobes and Functional Areas
- A — frontal lobe
- B — parietal lobe
- C — occipital lobe
- D — temporal lobe
- E — Broca's area / motor speech area
- F — Wernicke's area / sensory speech area
- G — primary motor area / motor cortex
- H — primary somatosensory area / somatosensory cortex
- I — primary visual area / visual cortex
- J — primary auditory area / auditory cortex

## 08. Autonomic Nervous System Divisions
- A — sympathetic division
- B — parasympathetic division
- C — dilates pupil
- D — constricts pupil
- E — speeds heart / increases heart rate
- F — slows heart / decreases heart rate
- G — decreases intestinal activity
- H — increases intestinal activity
- I — inhibits urination
- J — stimulates urination
