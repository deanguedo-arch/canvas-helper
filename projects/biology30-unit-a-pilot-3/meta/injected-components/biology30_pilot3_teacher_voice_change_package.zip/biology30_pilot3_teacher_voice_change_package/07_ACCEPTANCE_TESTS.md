# Acceptance tests and release gates

## Gate 1 — copy preflight (available helper)
Run the standard-library helper against the uploaded export or a comparable candidate:

```sh
python tools/apply_copy.py --input /path/to/biology30-unit-a-pilot-3.html --dry-run
python tools/apply_copy.py --input /path/to/biology30-unit-a-pilot-3.html --output /tmp/pilot3-copy-candidate.html
python tools/audit_copy.py --before /path/to/biology30-unit-a-pilot-3.html --after /tmp/pilot3-copy-candidate.html --report /tmp/copy-audit.json
```

This is a content-candidate check, not a repository build or production patch. The helper uses all targets transactionally, rejects missing or stale text, refuses source overwrite, and applies only exact copy plus approved vocabulary data. If canonical sources differ, resolve the differences in the repository rather than bypassing the guard.

Compare: all existing IDs; activity/question/writing bindings; entire question subtrees; input/option values; Frayer shells; all images and links; required-check markers; word ordering, save identity and unchanged fields; catalogue/practice/runtime scripts. The initial copy phase must not change the behavior scripts. Layout work may later require an intentional, reviewed runtime diff; the copy-only script-hash gate should then be applied to the earlier commit, not disabled and claimed as passed.

## Gate 2 — content coverage
Check every S01–S12 action. Read Lessons 2, 4, 5, 6, 8 and 10 aloud. The explanation must name the structure, describe the event and connect it to its consequence. Four stages must be numbered consistently across Lessons 4–5. Verify before/after science distinctions against the decision register.

Confirm the full synapse sequence remains and that resting potential and action potential do not collapse into lists of unexplained terms. New readers should not need the glossary to understand every word in the glossary definition. Do not use an AI-detector score or an arbitrary sentence-length threshold as proof of quality.

## Gate 3 — static versus live vocabulary parity
Open neuron, dendrite, axon, cell body, myelin, threshold, refractory period, neurotransmitter, cholinesterase, sympathetic division and parasympathetic division from a lesson and from Core Vocabulary. Confirm the visible definitions match the approved payload. Open/close More about this word; test keyboard focus and Return to lesson. Verify selected word Frayers and the gated course-model comparison remain available.

## Gate 4 — learner-state regression (real existing schema)
Seed representative learner work using current source, not an invented state format: one selected uncollected Frayer, one collected Frayer, a partially completed required check, completed history with retries, and a generated practice session partway through. Export a backup. Load with the revised implementation.

Assert: identical owners/IDs, answers, eight-slot selections, four fields, collection status, timestamps, selected options, generated item order, seed, prompt snapshots and question position. Resume then save/reload again. Verify old history is not regraded, translated, emptied or truncated. Do not claim that browser cache alone is cross-device SCORM persistence.

## Gate 5 — assessment and progress
Take the current implementation's required activity set as baseline (12 markers in this uploaded export). Start/finish one required activity and confirm the same progress behavior as before. Complete dedicated Flash cards, Fill in the blanks, Multiple choice, Mixed practice and Labeling, confirming they do not acquire new required-check behavior. A `practice-*` ID in a Learn lesson may already be required; do not infer policy from the name.

Confirm answer checking, accepted aliases, per-label checks, retries, writing limits, Save and Exit, backup/import, timers and Process Collection still work. Text rewrites must not change first-try logic, turn flashcard self-assessment into an objective grade, or alter review question answers.

## Gate 6 — layout and media
Test 320, 375, 768 and at least 1280 px. Keep all figures/video links available. No page-wide overflow in ordinary prose. Vocabulary help and extra detail can be opened by keyboard. Verify focus visibility, touch targets and live feedback. Test with video unavailable; the written teaching remains usable. Relative assets missing from the standalone upload must be checked in the actual repository build. No image-regeneration claim is part of this task.

## Gate 7 — canonical build and unaffected courses
Run the current project's build and tests. If a shared vocabulary renderer is changed, prove unchanged default output for another existing consumer. Rebuild the generated runtime and export through normal commands. Do not replace the project with the standalone HTML. Review the git diff for unrelated changes and confirm no new dependency/network call/storage migration was introduced.

## Required final report
List commands and pass/fail/not-run for each gate. Supply current-source conflicts, completed structural action IDs, actual word-count scope, before/after screenshots, save regression results and remaining teacher content decisions. Static validation is not browser validation, teacher approval or SCORM/LMS certification.
