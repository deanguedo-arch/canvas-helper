# Layout and teaching scope

## The first screen of a lesson
Keep the lesson name, one specific goal, one brief reminder and the textbook link. Keep the established course header/sidebar and font system. A compact term strip may list the concepts supplied in S01. The expanded vocabulary cards and exhaustive inventory belong in **Vocabulary help**, closed by default. The learner should encounter the explanation before a screenful of support labels.

Do not replace the lesson with a sequence of closed accordions. The causal teaching stays visible. A learner should not have to open "More detail" to find the answer to an ordinary required-check question.

Use native `<details><summary>` for extra explanations. Keep the summary wording specific: "More detail: two parts of the refractory period" is better than "Advanced information." The disclosure is not a new completion requirement. Preserve any IDs on moved nodes, keep them in the same logical lesson or next to the relevant review question, and retain keyboard access.

## The vocabulary reader and drawer
The export contains both 141 authored word views and JSON consumed by a live renderer. Changes in `03_VOCABULARY_PAYLOAD_CHANGES.json` must reach both. The 82 edited records include core Chapter 11 terms and six shared Unit A terms used by Chapter 11. They do not authorize rewriting the remaining eye, ear or endocrine teaching.

A word's first view should show its name, definition and role. Show one clear common mistake when helpful. Move etymology, word-part caveats, related terms and additional retrieval prompts under "More about this word." Do not hide the student's Frayer, use the model response to fill a student answer, or reset the selected eight words.

The source package preserves all model Frayer answers and their gating. If a model still uses difficult wording, keep it as extra support in this pass; do not silently rewrite its biological content or apply changes to stored learner responses. Record it for a separate model-answer editorial review.

## Vocabulary emphasis is not assessment scope
"First-pass terms" means words used to introduce the explanation. "More detail" means information shown later or on request. These are NOT claims about diploma coverage. The teacher deck is not a diploma specification.

Do not remove a term from assessed practice because it was moved into support. Conversely, do not quietly introduce more required terminology by promoting every glossary entry into the opening list. Keep the existing requirement model until a teacher approves a separate scope change.

## Keep mechanisms visible
Lessons 4 and 5 share the teacher's four-stage framework: 1 resting state; 2 depolarization; 3 repolarization, including undershoot; 4 refractory period. They remain separate routes. The numbered headings in the exact changes reflect that sequence.

The pump and channels must remain distinct. The copy retains Na⁺ entry, K⁺ exit, ATP, 3 Na⁺ out / 2 K⁺ in, threshold, firing frequency, and recruitment of more neurons. More technical recovery names remain accessible. No replacement should claim all ions swap sides or all recovery waits until precisely −70 mV.

In Lesson 6 keep the six-step table, calcium entry, vesicle fusion/exocytosis, diffusion, receptor binding, removal, and spatial/temporal summation. Do not remove these to make the page shorter.

## Captions, media and accessibility
Do not change the actual diagrams. Preserve every callout, filename, dimension, alternate text and source reference unless a separately documented accessibility edit is needed. Attribution moved out of repeated captions must remain in the source record; it must not disappear.

At 320 px, ordinary lesson text and controls must not cause page-wide horizontal scrolling. Structure/function comparisons should stack or use an accessible table container. Maintain readable body text; do not shrink fonts to make the page look shorter. Keep visible focus and touch targets. Do not make closed details content permanently unreachable to assistive technology. Verify glossary open/close focus, routing and return-to-context behavior.

## No extra infrastructure
Do not add a framework, service, runtime AI, storage adapter, media source or dependency to implement this edit. Use the existing course code. Shared-library behavior must remain unchanged unless a Pilot-3-only opt-in is added and its default behavior is regression-tested.
