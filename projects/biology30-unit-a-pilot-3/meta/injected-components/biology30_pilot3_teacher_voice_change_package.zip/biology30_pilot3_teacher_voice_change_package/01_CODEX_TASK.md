# Codex implementation task — Chapter 11 teacher-voice edit

## Goal
Make the current Biology 30 Unit A Pilot 3 read like a teacher explaining the chapter to an independent Grade 12 learner. Keep the biology, examples, existing lesson sequence and course functionality. Change the delivery, not the course requirements.

This package is based on the uploaded `biology30-unit-a-pilot-3.html` and `Unit A Chapter 11 Notes(2).pptx`, not a fresh inspection of the repository. The teacher's deck guides the voice and emphasis. The uploaded HTML supplies the detailed explanations already in this course. Read `06_SOURCE_AND_SCIENCE_GUARDRAILS.md` before making changes.

## Start with the real current sources
1. Read repository instructions, the current Pilot 3 project metadata and canonical source declarations. Work on a new branch. Preserve unrelated uncommitted work.
2. Locate the current Pilot 3 workspace HTML, stylesheet, vocabulary authoring data, practice bank and runtime entry point. The uploaded export explicitly identifies `styles.css`, `assets/pilot3-catalog.js`, `assets/pilot3-practice-bank.js` and `assets/pilot3-runtime.js` as inlined sources. Bundled comments identify `scripts/lib/biology30-pilot3/` and shared `scripts/lib/biology30-vocabulary/` sources. These are discovery clues, not permission to overwrite a newer file.
3. Do NOT rerun a historical Pilot 3 initializer. Do NOT paste the standalone export over canonical workspace sources. Do NOT hand-edit a generated runtime bundle.
4. Compare the `editKey` and `beforeText` for every replacement with current source. Any mismatch is a conflict to inspect, not an invitation to fuzzy-replace text. Report the current text, requested replacement and decision. Apply nonconflicting edits only after a complete preflight.

## Deliver in three commits
### Commit 1 — exact copy and synchronized vocabulary
Apply `02_EXACT_TEXT_CHANGES.json` and `03_VOCABULARY_PAYLOAD_CHANGES.json` to canonical sources. These are authored replacement copy, not examples asking you to generate another rewrite.

`02` supplies exact old/new text, a selector, the original tag, replacement inner HTML and source context for each change. Replace only that element's inner content. Keep its parent element, ID and editor key. Existing links and surviving inline glossary buttons are included in `afterHtml`. A few redundant inline glossary buttons disappear where their repeated wording was removed; `retiredInlineEditorialKeys` explicitly identifies these editorial keys. They are NOT activity IDs, word IDs, question IDs or save owners.

`03` is essential: the live vocabulary pop-up is built from JSON in `script#pilot3-words`, not only from the visible HTML. Synchronize the specified fields by stable `wordId` in the canonical vocabulary source, exported JSON and static word articles. Do not fix only the visible paragraph and leave the drawer using the old definition.

Preserve all `schema.identity`, `schema.wordIds` order, legacy IDs, slot limits, word IDs, categories, related IDs and stored learner Frayers. If the repository's build recomputes the identity from text, STOP and investigate compatibility; do not deploy a new incompatible identity or discard saves. Use a Pilot-3-local editorial layer when the canonical word data is shared with other courses.

Use the helper scripts only on a copy-phase candidate. They do not integrate canonical sources, regenerate exports or implement the layout tasks. They intentionally reject stale text and refuse to overwrite their input.

### Commit 2 — first-pass teaching versus optional detail
Implement every task in `04_STRUCTURAL_CHANGES.json` and the explicit specifications in `05_LAYOUT_AND_SCOPE.md`.

Keep: a visible goal, a short review cue, a textbook link, the actual lesson explanation, existing diagrams/videos and existing checks. Collapse supplementary vocabulary and extended technical distinctions rather than deleting them. Put definitions where terms first appear. Do not turn all teaching into terse slide bullets or bury required mechanisms behind a disclosure.

Keep the course's current visual style. Use native, keyboard-accessible disclosure controls. Scope any added styles or renderer option to Pilot 3. Changes to shared vocabulary rendering must be opt-in with unchanged defaults for other consumers; prefer local decoration or a local adapter where possible.

Do not silently change assessment scope because a detail is moved. "More detail" is a reading-level decision, not a claim that a term is absent from the curriculum or cannot be assessed.

### Commit 3 — verification and export
Rebuild with the repository's existing build command. Regenerate the same export/deployment artefacts that the project currently uses. Run the checks in `07_ACCEPTANCE_TESTS.md`, including saved-work and vocabulary-drawer tests. Include actual commands and results. Do not say "all tests passed" when a test was not run.

## Non-negotiable preservation rules
- Keep every existing route, activity owner, question ID, writing ID, radio value, accepted-answer key, labeling mapping, timer rule and save namespace.
- Keep all diagrams, filenames, dimensions, relative asset references, video IDs, textbook links and source attribution. No new image generation or scientific redrawing in this task.
- Do not change graded stems, distractors, written prompts, correct answers, grading, required-check markers or completion logic. The exact copy changes intentionally exclude question containers.
- Do not modify generated practice selection, RNG, seeds, variant identities, answer normalization, retry policies, historical prompt snapshots or adaptive evidence.
- Do not recalculate historical answers against the new prose. Do not silently truncate or migrate work.
- Keep the 8-word Frayer selection rule, four stored fields and 240-character source schema limit unless the current repository already differs; preserve its current rules in that case.
- The uploaded HTML has **12 `data-required-check` sections**. Some required sections have `practice-*` activity names. Earlier chat mentioned 10. Use the actual current implementation; NEVER reset the count to 10 or make everything named `practice-*` ungraded.
- This is not a new SCORM adapter, new question-bank project or redesign.

## Editorial standard
Teach what happens, why it happens, and one relevant consequence. Use subject–verb wording: "K⁺ leaves the neuron" rather than "outward movement supports restoration." Keep technical vocabulary when it names the biology; simplify the words surrounding it. Keep a necessary exception in one clear sentence. Avoid stock motivational filler or sprinkling "Remember!" into every paragraph. Do not set a mechanical reading-grade or word-count target.

A paragraph can remain long when its explanation needs the space. Never remove Ca²⁺ entry, vesicle fusion, ATP use, Na⁺/K⁺ direction, threshold, or a causal step just to hit a compression percentage. Do not adopt the earlier suggestion of a universal 1.5–2× slide-text ratio. Slide text does not include the teacher's spoken explanation.

## Completion report
Report: files changed; exact edits applied; conflicts/deviations; all structural task IDs completed; old/new word counts with scope stated; unchanged assessment/asset/save invariants; tests actually run; remaining source-content decisions; screenshots of Lessons 2, 4, 5, 6 and 10 at desktop and mobile width. If a structural task was not implemented, name it explicitly. Do not present the copy-only helper's output as the completed course.
