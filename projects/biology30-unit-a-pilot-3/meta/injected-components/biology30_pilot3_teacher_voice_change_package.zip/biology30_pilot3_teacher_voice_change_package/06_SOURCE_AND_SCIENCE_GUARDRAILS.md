# Source fidelity and science decision register

## What these edits are based on
The teacher's `Unit A Chapter 11 Notes(2).pptx` contains 66 slides. It provides the instructional progression, terminology and emphasis. The uploaded Pilot 3 HTML contains fuller explanations needed for online learning. The package paraphrases those supplied sources; it does not add researched scientific content or certify every existing statement as correct. The prior chat's numerical quality ratings are not evidence and are not acceptance criteria.

Slide text is not the teacher's full spoken lesson. Do not impose an arbitrary ratio between slide word count and online word count. Likewise, the previous suggestion to cut 25–35% is not a quota. Preserve enough explanation to support the learner and the existing questions.

### Source-to-lesson map (slide numbers are one-based)
| Pilot 3 lesson | Teacher slides | Treatment |
|---|---|---|
| 1 Nervous communication | 6–8 | Preserve systems, homeostasis, neurons and glial cells. |
| 2 Neurons & myelin | 9–14 | Preserve structure/function and myelin explanation. Keep existing HTML distinctions described below. |
| 3 Pathways & reflexes | 15–20 | Preserve neuron roles, shape classification, pathway and brain-awareness distinction. |
| 4 Resting neuron | 21–23 | Retain four-stage framework, voltage, ion distribution, leak and pump. |
| 5 Action potentials | 24–30 | Retain threshold, phases, recovery and intensity. Reduce duplicated explanations. |
| 6 Synapses & summation | 31–39 | Retain sequence, transmitter emphasis and summation. |
| 7 Drugs | 40–42 | Explain changes to normal synaptic steps; keep teacher's emphasis on understanding rather than reciting lists. |
| 8 Peripheral control | 43–47 | Preserve somatic/autonomic and paired sympathetic/parasympathetic effects. |
| 9 Central control | 50–52, 54 | Retain CNS tissue, spinal cord and protection. |
| 10 Brain | 54–61 | Preserve main structures/functions and the HTML's existing extension treatment. |
| 11 Studying the brain | No separate full text block in this deck | Preserve the existing HTML section and its current textbook references; do not call its removal teacher-alignment. |
| 12 Review | 4, 43, 66 | Preserve existing review and assessment items. |
| 13 Further exploration | 49, 62–65 | Keep optional and preserve privacy/safety boundaries. |
| 14 Biology in practice | No direct slide-text equivalent | Retain existing HTML and its p. 400 reading; do not invent answers to research/current-price questions. |

Image-only material in the slides, including the partly image-based slide 60 structure/function list, is not a basis for new automated deletions. The package does not reinterpret its asterisks or declare new exclusions from assessment.

## Source disagreements: preserve, disclose, do not silently reconcile
These entries describe differences in the supplied files. They are not a new external fact-check. The copy pass retains the relevant distinction already in the HTML, or leaves the question for teacher review.

**D01 — Voltage versus concentration (slides 26–27).** The deck says the Na⁺ and K⁺ concentrations are briefly reversed. The HTML explicitly says a reversal of membrane voltage is not a reversal of the overall ion gradients. Preserve the HTML distinction. Do not rewrite it to match the slide sentence. Main targets: `p3-chapter-198`, `p3-chapter-203` and the aside containing `p3-chapter-204`.

**D02 — Recovery (slide 29).** The slide presents one refractory period and a broad cannot-fire-until-restored explanation. The HTML distinguishes an initially impossible second event from later, harder firing. Preserve that distinction in simple words, keeping the absolute/relative terminology under More detail. Do not infer a universal timing cutoff or change any graph. Targets: `p3-chapter-209`, `p3-chapter-211`, and the aside containing `p3-chapter-215`.

**D03 — Excitation and threshold (slides 33–37).** Some slide wording says threshold is lowered/raised, while slide 36 and the HTML describe membrane potential moving toward/away from threshold. Retain the HTML's framing and its statement that a small excitatory input does not automatically produce a full action potential. Targets: `p3-chapter-351` to `p3-chapter-363`.

**D04 — Neurotransmitter table (slide 38).** The table categorizes transmitters broadly; the HTML adds receptor/tissue context. The package shortens that caveat but does not change table cells or declare every transmitter universally excitatory/inhibitory. Teacher review of the underlying table remains a separate content decision.

**D05 — MS and regeneration (slides 12–14).** The deck includes a regeneration comparison and calls MS genetic. The existing HTML does not reproduce those broad claims. Keep the HTML's myelin-damage example; do not insert these claims to imitate the deck. This package is not an external review of MS.

**D06 — Forebrain and hemispheres (slides 56, 58).** The deck equates forebrain/cerebrum in wording and contrasts analytical/creative hemispheres. The HTML distinguishes the regions and explains cooperation. Keep those distinctions; shorten the surrounding prose rather than reverting them.

**D07 — Insecticide/sarin example (slide 34).** The slide refers to blocked cholinesterase release; the HTML discusses disrupted acetylcholine breakdown. Keep the existing HTML mechanism. Do not add treatment guidance, experimental instructions or an unsupported mechanism.

**D08 — Protected assessment and diagrams.** Some original assessment stems, diagram placements, figures and tables may warrant a separate science review. No assessment correction is authorized here. Flag a conflict with exact IDs and source text; do not silently change a correct option or existing student record.

**D09 — Existing progress differs from earlier chat.** This export contains 12 `data-required-check` sections. Some are named `practice-overview`, `practice-neuron-structure` and `practice-reflexes`. Preserve what the current code actually calculates. A stale displayed count or changed marking policy requires a separately documented fix, not a language-edit side effect.

**D10 — Other material is already in this HTML.** Studying the brain, source investigations, image labeling, detailed vocabulary and optional extensions are not all fully transcribed in the teacher deck. Do not treat missing slide text as proof that they should be removed.

## Review decisions, not blockers for ordinary copy edits
Unresolved scientific issues are listed for teacher review. They do not prevent safely shortening the identified sentences. Any proposed factual change beyond the exact replacements must include the source conflict, proposed wording and rationale for approval. Do not silently supplement these files with general knowledge.
