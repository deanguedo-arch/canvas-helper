# Change summary

**601 exact HTML text edits; 82 existing vocabulary records; 208 matching live-data field edits; 12 structural implementation tasks.** These totals include repeated lesson setup and interface text; they do not mean 601 biology concepts or questions changed.

## Tested locally

All exact targets matched the uploaded HTML. The copy-only candidate preserved every DOM ID, activity/question/writing binding, all 168 question containers, 141 Frayer shells, 38 image nodes, link destinations, answer fields, the three behavior/data scripts, vocabulary identity and ordering. Eight package tests passed, including stale-content rejection and detection of an altered answer value.

## Not yet performed

This package does not modify GitHub. Structural tasks, repository build, visual review, live browser regression, student comprehension checks and SCORM/LMS tests remain for Codex and teacher review. Relative images/media are not bundled into a new course here. No claim is made that every pre-existing scientific statement or assessment has been fact-checked.

## Text volume

Regex words in paragraph elements inside data-teaching sections, 14 lesson routes; excludes headings, tables, assessment and global glossary. Counts copy-only candidate before structural moves. Not a reading-level score.

Teaching-paragraph words: **5,412 → 3,547**, a **34.5%** reduction in that defined slice. This was measured after editing, not imposed as a target.

| Lesson | Before | After | Reduction |
|---|---:|---:|---:|
| lesson-01 — Nervous communication | 456 | 316 | 30.7% |
| lesson-02 — Neurons & myelin | 454 | 323 | 28.9% |
| lesson-03 — Pathways & reflexes | 428 | 289 | 32.5% |
| lesson-04 — The resting neuron | 376 | 216 | 42.6% |
| lesson-05 — Action potentials | 572 | 395 | 30.9% |
| lesson-06 — Synapses & summation | 545 | 404 | 25.9% |
| lesson-07 — Drugs at the synapse | 200 | 128 | 36.0% |
| lesson-08 — Peripheral control | 481 | 314 | 34.7% |
| lesson-09 — Central control | 431 | 270 | 37.4% |
| lesson-10 — The brain | 681 | 400 | 41.3% |
| lesson-11 — Studying the brain | 247 | 152 | 38.5% |
| lesson-12 — Chapter review | 200 | 128 | 36.0% |
| lesson-13 — Further exploration | 271 | 161 | 40.6% |
| lesson-14 — Biology in practice | 70 | 51 | 27.1% |