# Before / after — targeted examples

These are excerpts from the exact-change manifest, not a second set of instructions.

## lesson-01 · `p3-integrated-19`

**Current text**

Do not use neuron and nerve as interchangeable terms. A neuron is one cell. A nerve is a larger structure containing many nerve fibres organized into bundles and surrounded by protective connective tissue. Think of a cable containing many individual fibres. That comparison helps you see why a nerve can carry information along many pathways.

**Replacement**

A neuron is one cell. A nerve contains many nerve fibres bundled together inside protective tissue. Think of a cable containing many individual fibres.

## lesson-02 · `p3-integrated-32`

**Current text**

Dendrites are short, branching extensions. Their branching provides a large surface area for receiving information. In a typical pathway, signals are received by the dendrites and carried toward the cell body. The cell body processes incoming information. The axon carries the nerve impulse away from the cell body toward its terminals.

**Replacement**

Dendrites are short, branching extensions that receive information and carry it toward the cell body. Their branches provide a large receiving surface. The cell body processes incoming information. The axon carries nerve impulses away from the cell body.

## lesson-02 · `p3-integrated-81`

**Current text**

The mechanism you should be able to explain is straightforward: damage to a structure involved in rapid conduction can disrupt the signals travelling between the CNS and the body. The effect depends on the pathways involved, rather than simply on the presence of a symptom from a memorized list.

**Replacement**

Key connection: damaged myelin → disrupted nerve signals → changes in sensation or movement. The effects depend on which pathways are affected.

## lesson-03 · `p3-integrated-124`

**Current text**

The important distinction is the timing of the response. The spinal circuit can begin the movement without waiting for conscious processing. Information still travels to the brain. The brain has not been permanently “left out”; it is simply not required to consciously authorize the initial withdrawal.

**Replacement**

Remember: withdrawal can begin before you consciously feel the stimulus. Information still reaches the brain, but the spinal circuit does not wait for a conscious decision.

## lesson-04 · `p3-chapter-127`

**Current text**

A membrane potential is a voltage difference across the cell membrane. In a resting neuron , the inside is slightly negative relative to the outside. A common example is approximately −70 mV , called the resting membrane potential . The negative sign describes the inside relative to the outside; it does not mean the cell contains no positive ions.

**Replacement**

Membrane potential is the voltage difference across a cell membrane. A resting neuron is slightly negative inside compared with outside. A typical resting membrane potential is −70 mV . The minus sign tells you how the inside compares with the outside.

## lesson-04 · `p3-chapter-135`

**Current text**

The sodium-potassium exchange pump uses energy from ATP. For every three Na⁺ moved out , it moves two K⁺ in . This transport helps maintain the concentration differences across the membrane. Remember both the direction and the unequal numbers; reversing them reverses the explanation.

**Replacement**

The sodium-potassium pump uses ATP to move 3 Na⁺ out for every 2 K⁺ moved in . This maintains the concentration differences across the membrane.

## lesson-05 · `p3-chapter-198`

**Current text**

After the action potential reaches its peak, sodium entry is curtailed and voltage-gated potassium channels allow K⁺ to move out. Positive charge leaves the cell, so the membrane potential becomes negative again. This return toward the resting voltage is repolarization .

**Replacement**

After the action potential peaks, sodium channels become inactivated and K⁺ moves out through potassium channels. Positive charge leaves, making the inside negative again. This is repolarization .

## lesson-05 · `p3-chapter-209`

**Current text**

Immediately after firing, the recently active membrane cannot simply produce another identical impulse at once. This recovery interval is the refractory period . Sodium permeability cannot immediately repeat the same change.

**Replacement**

The refractory period is a brief recovery time. At first, that part of the membrane cannot fire again. Later, it can fire only if the stimulus is stronger than usual.

## lesson-05 · `p3-chapter-225`

**Current text**

Frequency of nerve impulses is an important way of representing stimulus intensity: more impulses can occur in the same period of time. More neurons may also become active. These are distinct ideas: a higher firing frequency means more impulses from a neuron per unit time; recruitment means more neurons participating. Neither requires each individual action potential to become larger.

**Replacement**

A stronger stimulus can produce more impulses per second and activate more neurons . These are different changes: faster firing versus more neurons firing. Neither makes each action potential larger.

## lesson-06 · `p3-chapter-320`

**Current text**

First, an action potential reaches the axon terminal . Calcium channels open and Ca²⁺ enters the terminal. Calcium triggers neurotransmitter -containing vesicles to move toward and fuse with the presynaptic membrane. Fusion releases the neurotransmitter by exocytosis .

**Replacement**

An action potential reaches the axon terminal . Calcium channels open, and Ca²⁺ enters . Calcium causes vesicles containing neurotransmitter to fuse with the presynaptic membrane. This releases the neurotransmitter by exocytosis .

## lesson-06 · `p3-chapter-363`

**Current text**

In spatial summation , inputs from different locations act together. In temporal summation , repeated inputs arrive close together in time. In both cases, the question is whether the net effect is enough to generate an action potential . Do not confuse summation of incoming effects with making the resulting action potential taller.

**Replacement**

Spatial summation: inputs from different locations act together. Temporal summation: repeated inputs arrive close together in time. Both can help determine whether an action potential occurs; they do not make it taller.

## lesson-07 · `p3-chapter-487`

**Current text**

Insecticides and sarin provide examples of disrupted acetylcholine clearance. The key mechanism here is the role of cholinesterase : when normal breakdown is disrupted, the timing of stimulation is disrupted.

**Replacement**

cholinesterase normally breaks down acetylcholine . In the insecticide and sarin examples, this breakdown is disrupted, so stimulation can continue longer than normal.

## lesson-08 · `p3-chapter-613`

**Current text**

Think of these changes as a coordinated pattern rather than an unrelated list. In the stressful situation used in the chapter, the body is being prepared for rapid action. Some processes increase while others decrease. A sympathetic response does not mean every organ is simply “excited” in the same way.

**Replacement**

These changes prepare the body for action. Notice that heart activity increases while digestion decreases: not every organ speeds up.

## lesson-10 · `p3-chapter-845`

**Current text**

The cerebellum helps coordinate movement, balance and fine motor control. It uses information from receptors in muscles and joints. Being able to activate a muscle is not the same as being able to coordinate a smooth, precise movement; this is why cerebellar function is important.

**Replacement**

The cerebellum coordinates movement, balance and fine motor control. It uses information from muscles and joints to help make movements smooth and precise.

## core-vocabulary · `p3-content-547`

**Current text**

The neuron region containing its nucleus and much of its biosynthetic machinery.

**Replacement**

The part of a neuron containing the nucleus and most organelles; also called the soma.

## core-vocabulary · `p3-content-732`

**Current text**

The membrane or stimulus condition at which an action potential is initiated.

**Replacement**

The membrane voltage at which an action potential starts.

## core-vocabulary · `p3-content-1172`

**Current text**

An autonomic division that coordinates context-dependent adjustments often associated with activity and challenge.

**Replacement**

The autonomic division involved in the fight-or-flight response.

## core-vocabulary · `p3-content-1186`

**Current text**

An autonomic division supporting context-dependent maintenance, conservation and digestive functions.

**Replacement**

The autonomic division involved in rest-and-digest activity.
