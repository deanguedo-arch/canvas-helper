# Revised lesson copy — review edition

This is the copy-only candidate in existing teaching order. Codex must still implement the layout/disclosure tasks. Unchanged tables, videos, diagrams and assessment questions are not reproduced here; they remain in the course. The source trace for each change is in the exact-change manifest.

## 1. Nervous communication

How does your body detect a change and respond?
`p3-chapter-25`

I can explain how the nervous system detects changes and directs responses.
`p3-l01-setup-02`

Start here: a stimulus is a change; a response is what the body does after that change.
`p3-l01-setup-04`

Your nervous system detects changes and directs a response . Some responses are voluntary, such as reaching for a glass. Others, such as a change in heart rate, happen without a conscious decision.
`p3-integrated-2`

Conditions inside and outside your body keep changing. Temperature may rise, water levels may fall, or your muscles may need to work harder. Homeostasis means maintaining relatively stable internal conditions despite these changes.
`p3-integrated-5`

The nervous and endocrine systems work together. The nervous system uses electrochemical messages : electrical changes along neurons and chemical signals between cells. The endocrine system uses hormones , which travel in the bloodstream. This chapter focuses on the nervous system.
`p3-integrated-7`

Follow this sequence: sensory input → integration → motor output . Sensory input carries information about a change. Integration means processing that information. Motor output carries instructions for a response to an effector , such as a muscle or gland.
`p3-integrated-8`

The central nervous system ( CNS ) is the brain and spinal cord. The peripheral nervous system ( PNS ) consists of nerves linking the CNS with the rest of the body. You will study their subdivisions later.
`p3-integrated-11`

A neuron is a nerve cell that receives and carries information to other cells. Glial cells support and nourish neurons. They also help remove wastes and protect against infection.
`p3-integrated-17`

A neuron is one cell. A nerve contains many nerve fibres bundled together inside protective tissue. Think of a cable containing many individual fibres.
`p3-integrated-19`

## 2. Neurons & myelin

How do the parts of a neuron help it carry information?
`p3-chapter-63`

I can identify neuron parts and explain how myelin speeds nerve impulses.
`p3-l02-setup-02`

Remember: a neuron is one cell, while a nerve contains many nerve fibres.
`p3-l02-setup-04`

A typical neuron has dendrites, a cell body , an axon and axon terminals. The cell body, also called the soma , contains the nucleus and other organelles and carries out the cell’s life processes.
`p3-integrated-28`

Dendrites are short, branching extensions that receive information and carry it toward the cell body. Their branches provide a large receiving surface. The cell body processes incoming information. The axon carries nerve impulses away from the cell body.
`p3-integrated-32`

An axon may be much longer than a dendrite . Some extend over a metre, allowing a neuron to communicate with a distant cell.
`p3-integrated-33`

At the axon terminal , information passes to another neuron or an effector . This junction is a synapse . The small gap between the cells is the synaptic cleft . Lesson 6 explains how a chemical message crosses it.
`p3-integrated-35`

Many axons have a fatty insulating covering called the myelin sheath . Schwann cells form myelin around axons in the PNS. The gaps between myelin segments are nodes of Ranvier .
`p3-integrated-50`

Myelin speeds up nerve impulses. In a myelinated axon, the action potential is regenerated at each node. This is saltatory conduction , often described as “jumping” from node to node. The axon remains continuous underneath the myelin.
`p3-integrated-53`

In an unmyelinated axon, each neighbouring section of membrane produces the next part of the impulse. In a myelinated axon, the impulse is regenerated at the nodes instead.
`p3-integrated-56`

Myelin-producing cells: Schwann cells make myelin in the PNS . Oligodendrocytes make it in the CNS .
`p3-integrated-72`

In multiple sclerosis (MS) , damage to myelin disrupts nerve signals. Symptoms can include numbness, tingling, muscle spasms, and problems with balance or coordination. Other possible symptoms include blurred vision, weakness, fatigue and slurred speech.
`p3-integrated-79`

Key connection: damaged myelin → disrupted nerve signals → changes in sensation or movement. The effects depend on which pathways are affected.
`p3-integrated-81`

## 3. Pathways & reflexes

How does information travel from a receptor to an effector?
`p3-chapter-84`

I can trace a withdrawal reflex from the receptor to the muscle.
`p3-l03-setup-02`

Remember: sensory neurons carry information toward the CNS; motor neurons carry instructions away.
`p3-l03-setup-04`

Three types of neuron work together. A sensory neuron , also called an afferent neuron , carries information from a sensory receptor toward the CNS . The receptor may detect touch, light, sound or another change.
`p3-integrated-85`

An interneuron processes and relays information within the CNS. A motor neuron , also called an efferent neuron , carries instructions from the CNS to an effector , such as a muscle or gland.
`p3-integrated-90`

A cat darts onto the road. The driver’s eyes detect the stimulus . Sensory information reaches the CNS, where it is processed. Motor neurons then carry instructions to the muscles that press the brake.
`p3-integrated-94`

Multipolar, bipolar and unipolar describe a neuron ’s shape and the branches extending from its cell body . Sensory, interneuron and motor describe its job. Check whether a question asks about shape or function.
`p3-integrated-110`

A reflex is a rapid, involuntary response to a stimulus . Follow this withdrawal pathway: receptor → sensory neuron → interneuron → motor neuron → effector . The spinal cord processes the incoming signal and sends instructions to the muscle that pulls the body part away.
`p3-integrated-114`

Remember: withdrawal can begin before you consciously feel the stimulus. Information still reaches the brain, but the spinal circuit does not wait for a conscious decision.
`p3-integrated-124`

Not every reflex needs an interneuron. For each diagram, trace the receptor, sensory route into the CNS , processing site, motor route out and effector.
`p3-integrated-125`

## 4. The resting neuron

What is happening at the membrane before a neuron fires?
`p3-chapter-116`

I can explain the resting potential and the roles of leak channels and the sodium-potassium pump.
`p3-l04-setup-02`

Review the axon and cell membrane. This lesson introduces the ions and their movements.
`p3-l04-setup-04`

A nerve impulse is electrochemical . Charged particles called ions , including sodium (Na⁺) and potassium (K⁺), move across the membrane. Their movement changes the voltage across it.
`p3-chapter-118`

Unlike current in a metal wire, a nerve impulse depends on ions moving across the axon membrane.
`p3-chapter-119`

Study four stages: resting state, depolarization , repolarization and refractory period . Start with the resting neuron before following the changes during an impulse.
`p3-chapter-121`

### 1. Resting state
`p3-chapter-126`

Membrane potential is the voltage difference across a cell membrane. A resting neuron is slightly negative inside compared with outside. A typical resting membrane potential is −70 mV . The minus sign tells you how the inside compares with the outside.
`p3-chapter-127`

“Resting” means the neuron is not producing an action potential . Ions still move, and the cell still uses energy to maintain its conditions.
`p3-chapter-130`

There is more K⁺ inside the neuron and more Na⁺ outside. At rest, K⁺ moves out through leak channels more easily than Na⁺ moves in. Large negatively charged molecules remain inside the cell.
`p3-chapter-133`

The sodium-potassium pump uses ATP to move 3 Na⁺ out for every 2 K⁺ moved in . This maintains the concentration differences across the membrane.
`p3-chapter-135`

Channels and pumps do different jobs. Leakage through channels is passive. The pump uses ATP for active transport. Together, ion concentrations and the membrane’s selective permeability help maintain the resting potential.
`p3-chapter-136`

## 5. Action potentials

How does a neuron fire and carry an impulse?
`p3-chapter-187`

I can explain the stages of an action potential and how stimulus strength is signalled.
`p3-l05-setup-02`

Review the resting neuron in Lesson 4: the inside is negative compared with the outside.
`p3-l05-setup-04`

### 2. Depolarization and threshold
`p3-chapter-188`

Depolarization means the inside becomes less negative. In our example, the voltage rises from −70 mV toward the threshold of about −55 mV .
`p3-chapter-189`

Below threshold, a stimulus does not trigger an action potential . At threshold, voltage-gated sodium channels open. Na⁺ enters the neuron , making the inside more positive. In this example, the peak is about +40 mV .
`p3-chapter-192`

Graphs may use a peak near +35 mV or +40 mV. These are example values, so read the values on the graph you are given.
`p3-chapter-196`

### 3. Repolarization and hyperpolarization
`p3-chapter-197`

After the action potential peaks, sodium channels become inactivated and K⁺ moves out through potassium channels. Positive charge leaves, making the inside negative again. This is repolarization .
`p3-chapter-198`

Potassium channels close slowly, so K⁺ may keep leaving briefly. The voltage drops below the resting level. This is hyperpolarization , or the undershoot. The example here reaches about −90 mV before recovering.
`p3-chapter-201`

The sodium-potassium pump maintains the ion concentration differences over time. Ion movement through channels causes the rapid rise and fall of an action potential.
`p3-chapter-203`

### 4. The refractory period
`p3-chapter-208`

The refractory period is a brief recovery time. At first, that part of the membrane cannot fire again. Later, it can fire only if the stimulus is stronger than usual.
`p3-chapter-209`

This helps the impulse travel forward, called propagation . The next section of the axon reaches threshold while the section behind is recovering. The signal continues toward the axon terminals.
`p3-chapter-211`

### All-or-none and stimulus strength
`p3-chapter-219`

An action potential is all-or-none : a neuron fires when it reaches threshold , or it does not. A stronger stimulus does not make that neuron’s individual action potential taller.
`p3-chapter-220`

A stronger stimulus can produce more impulses per second and activate more neurons . These are different changes: faster firing versus more neurons firing. Neither makes each action potential larger.
`p3-chapter-225`

Check whether the question describes one neuron or many. Chapter Review question 17 uses one motor neuron and one muscle fibre; answer for that setup.
`p3-chapter-226`

### How the impulse travels along the axon
`p3-chapter-231`

An action potential starts a new action potential in the next section of axon membrane. This produces a wave along the axon. In myelinated axons, the signal is regenerated at each node of Ranvier .
`p3-chapter-232`

myelin allows the signal to spread quickly between nodes. The “jump” in saltatory conduction describes where action potentials are regenerated. Sodium ions do not travel the full length of the neuron .
`p3-chapter-236`

Use the three recap videos to review the steps. Pause and explain which ion moves, which way it moves, and how the voltage changes.
`p3-chapter-240`

## 6. Synapses & summation

How does a message cross from one cell to another?
`p3-chapter-308`

I can explain synaptic transmission and how excitatory and inhibitory inputs combine.
`p3-l06-setup-02`

Review how an action potential reaches an axon terminal.
`p3-l06-setup-04`

### Crossing a synapse
`p3-chapter-309`

An action potential travels along the axon to the axon terminal . At a chemical synapse , it cannot jump across the gap to the next neuron . Instead, the sending neuron releases a chemical messenger called a neurotransmitter .
`p3-chapter-310`

Presynaptic means the sending side; postsynaptic means the receiving side. A synapse between a motor neuron and a muscle cell is a neuromuscular junction .
`p3-chapter-317`

An action potential reaches the axon terminal . Calcium channels open, and Ca²⁺ enters . Calcium causes vesicles containing neurotransmitter to fuse with the presynaptic membrane. This releases the neurotransmitter by exocytosis .
`p3-chapter-320`

Neurotransmitter diffuses across the synaptic cleft and binds to receptors on the postsynaptic membrane. This changes ion movement and makes the receiving cell more or less likely to fire.
`p3-chapter-324`

The chemical message must then be removed. Some neurotransmitters return to the presynaptic neuron by Reuptake ; others are broken down by enzymes. cholinesterase breaks down acetylcholine .
`p3-chapter-325`

On the sending side, vesicles release the message. On the receiving side, receptors bind the message and affect ion movement.
`p3-chapter-346`

An excitatory signal makes an action potential more likely. For example, Na⁺ entering the cell makes the inside less negative and moves it toward threshold . The neuron fires only if threshold is reached.
`p3-chapter-351`

An inhibitory signal makes an action potential less likely. In the examples here, K⁺ leaves or Cl⁻ enters. The inside becomes more negative and moves away from threshold.
`p3-chapter-354`

Remember: excitatory input helps the neuron reach threshold; inhibitory input makes firing less likely.
`p3-chapter-355`

### Adding inputs: summation
`p3-chapter-359`

A neuron receives excitatory and inhibitory inputs. Summation is their combined effect. The receiving neuron fires if the combined change brings it to threshold .
`p3-chapter-360`

Spatial summation: inputs from different locations act together. Temporal summation: repeated inputs arrive close together in time. Both can help determine whether an action potential occurs; they do not make it taller.
`p3-chapter-363`

Know acetylcholine , norepinephrine and GABA and the examples in this table. A neurotransmitter’s effect depends on the receptor and target tissue, so these descriptions are not universal rules.
`p3-chapter-369`

## 7. Drugs at the synapse

How can a drug change communication at a synapse?
`p3-chapter-476`

I can predict how changing one step at a synapse affects the signal.
`p3-l07-setup-02`

Review neurotransmitter release, receptor binding and removal in Lesson 6.
`p3-l07-setup-04`

Start with the normal sequence: neurotransmitter is made and stored, released, bound to a receptor , then removed. A drug can change one of these steps. You need to explain the effects, not recite the two mechanism lists.
`p3-chapter-478`

A drug may act like a neurotransmitter , increase its release, or slow its breakdown or reuptake . These changes can make stimulation stronger or longer-lasting.
`p3-chapter-481`

A drug may block a receptor, reduce neurotransmitter production or storage, or speed its breakdown at the synapse . These changes can reduce signalling through the affected pathway.
`p3-chapter-484`

Check the kind of synapse. Blocking an excitatory receptor and blocking an inhibitory receptor can have different effects.
`p3-chapter-486`

cholinesterase normally breaks down acetylcholine . In the insecticide and sarin examples, this breakdown is disrupted, so stimulation can continue longer than normal.
`p3-chapter-487`

## 8. Peripheral control

How are voluntary and involuntary activities controlled?
`p3-chapter-591`

I can compare somatic and autonomic control and describe fight-or-flight and rest-and-digest responses.
`p3-l08-setup-02`

Review the CNS, PNS and the receptor-to-effector pathway.
`p3-l08-setup-04`

The PNS connects the brain and spinal cord with sensory organs, muscles, glands and internal organs. Sensory pathways carry information toward the CNS ; motor pathways carry instructions away.
`p3-chapter-593`

There are 12 pairs of cranial nerves associated with the brain and 31 pairs of spinal nerves associated with the spinal cord. You do not need to memorize the individual spinal regions here.
`p3-chapter-596`

The PNS includes somatic and autonomic systems. The somatic system carries sensory information and controls skeletal muscles. It includes voluntary control , such as moving your hand, and skeletal-muscle reflexes.
`p3-chapter-598`

The autonomic system controls involuntary activity in smooth muscle, heart muscle and glands. Changes in heart rate and digestion help maintain homeostasis without a conscious decision.
`p3-chapter-601`

Motor output is not always voluntary. It can also carry instructions to an effector that produces an involuntary response .
`p3-chapter-603`

The sympathetic division produces the fight-or-flight response . Pupils and air passages dilate; heart rate and blood pressure rise. Digestion and bladder emptying slow. The liver releases glucose, and adrenal secretion increases.
`p3-chapter-610`

These changes prepare the body for action. Notice that heart activity increases while digestion decreases: not every organ speeds up.
`p3-chapter-613`

Sympathetic nerve pathways use acetylcholine and norepinephrine . The adrenal glands can also release epinephrine and norepinephrine into the blood as a hormone signal. A blood-borne hormone is different from an impulse along an axon .
`p3-chapter-614`

The parasympathetic division supports rest and digest . Pupils constrict, heart rate and blood pressure fall, and digestion and urination increase. Acetylcholine is the key neurotransmitter in these pathways.
`p3-chapter-621`

The sympathetic and parasympathetic divisions often have opposing effects on the same organ. Together, they adjust body functions as conditions change.
`p3-chapter-625`

A polygraph records changes such as heart rate, blood pressure, breathing and sweating. These can reflect sympathetic activity, but they do not directly show whether someone is lying.
`p3-chapter-635`

Evidence check: a racing heart can have several causes. The measurement alone cannot explain why it increased.
`p3-chapter-636`

## 9. Central control

What does the spinal cord do, and how is the CNS protected?
`p3-chapter-756`

I can explain spinal-cord functions and how the brain and spinal cord are protected.
`p3-l09-setup-02`

Review the withdrawal reflex and the role of the spinal cord.
`p3-l09-setup-04`

### What the CNS does
`p3-chapter-757`

The CNS is the brain and spinal cord. It processes information and directs responses. Damage can affect movement, sensation, behaviour or homeostasis , depending on the area involved.
`p3-chapter-758`

Grey matter contains many cell bodies, dendrites and unmyelinated parts of axons. White matter contains many myelinated axons grouped into tracts.
`p3-chapter-761`

In the cerebrum, grey matter forms the outer cortex, with white matter deeper inside. In a spinal cord cross-section, grey matter forms the central butterfly shape and white matter surrounds it.
`p3-chapter-762`

The spinal cord links the brain with the PNS . Sensory information travels toward the brain; motor information travels toward effectors. The spinal cord also processes reflex responses.
`p3-chapter-767`

Vertebrae, meninges and cerebrospinal fluid protect the spinal cord. A vertebra is a bone; the spinal cord is the nervous tissue inside the protected canal.
`p3-chapter-770`

An injury higher in the spinal cord can interrupt communication with more body regions below it. Explain this connection; you do not need to memorize each spinal segment.
`p3-chapter-771`

The skull protects the brain. Three membrane layers, the meninges , surround the CNS . Cerebrospinal fluid (CSF) cushions the brain and spinal cord and acts as a transport medium.
`p3-chapter-773`

The layers are dura mater, arachnoid and pia mater . CSF occupies the space between the arachnoid and pia mater and spaces within the brain. Use the diagram to locate the bone, membranes, fluid and nervous tissue.
`p3-chapter-775`

### The blood-brain barrier
`p3-chapter-779`

The blood-brain barrier is formed by tightly joined cells in brain capillary walls. It limits what passes from the blood into CNS tissue while allowing needed substances to reach the brain.
`p3-chapter-780`

Different jobs: CSF cushions nervous tissue; the blood-brain barrier controls the passage of substances from blood.
`p3-chapter-782`

## 10. The brain

Where are the main brain structures, and what do they do?
`p3-chapter-820`

I can identify the main brain structures and explain their functions.
`p3-l10-setup-02`

Remember: the brain and spinal cord make up the CNS.
`p3-l10-setup-04`

### Three broad regions of the brain
`p3-chapter-821`

The brain controls conscious activities and many involuntary functions. Study its three broad regions: forebrain, midbrain and hindbrain .
`p3-chapter-822`

Brain regions work together. For a coordinated movement, the nervous system receives sensory information, sends a motor command and adjusts the movement.
`p3-chapter-823`

Focus on the main structures below. The amygdala, hippocampus and reticular formation remain optional extension topics.
`p3-chapter-838`

Optional: the amygdala is associated with emotions, the hippocampus with learning and memory, and the reticular formation with information passing through the brainstem.
`p3-chapter-840`

### Main brain structures and their functions
`p3-chapter-844`

The cerebellum coordinates movement, balance and fine motor control. It uses information from muscles and joints to help make movements smooth and precise.
`p3-chapter-845`

The medulla oblongata connects with the spinal cord and helps control heart rate, blood pressure, breathing, swallowing and coughing. The pons relays information between brain regions and is involved in sleep and arousal.
`p3-chapter-846`

The midbrain relays information between the forebrain and hindbrain. It is involved in visual and auditory functions and eye movement.
`p3-chapter-847`

The thalamus relays information, including sensory information. Below it, the hypothalamus regulates body temperature, hunger, thirst, heart rate and blood pressure. Its link with the pituitary connects nervous and endocrine control.
`p3-chapter-848`

The corpus callosum is a bundle of nerve fibres connecting the left and right cerebral hemispheres. It allows them to communicate.
`p3-chapter-851`

The cerebrum is the largest part of the brain. It has left and right cerebral hemispheres . The outer cerebral cortex is grey matter. Its folds increase the surface area that fits inside the skull.
`p3-chapter-853`

The cerebrum is part of the forebrain. The thalamus and hypothalamus are also part of the forebrain.
`p3-chapter-854`

The frontal lobe is involved in thought, decisions, memory, personality and voluntary movement. The parietal lobe processes touch and body-position information. The temporal lobe processes hearing and contributes to language and memory. The occipital lobe processes vision.
`p3-chapter-856`

The primary motor area is in the frontal lobe. The primary somatosensory area is in the parietal lobe. The body maps are uneven: some body parts need more detailed movement control or provide more sensory information.
`p3-chapter-861`

Many motor pathways cross in the brainstem. Damage to the right motor cortex can therefore affect movement on the left side of the body. Apply this to the motor pathway shown, not to every nervous-system structure.
`p3-chapter-862`

### The two hemispheres work together
`p3-chapter-863`

Some functions are more strongly associated with one hemisphere, but both hemispheres work together during complex tasks.
`p3-chapter-864`

The corpus callosum allows this communication. Avoid labelling a person as a “left-brained” or “right-brained” learner.
`p3-chapter-865`

## 11. Studying the brain

How do researchers study brain structure and function?
`p3-chapter-942`

I can compare the information provided by brain injuries, stimulation, dissection, MRI and PET.
`p3-l11-setup-02`

Review the main brain structures and their functions.
`p3-l11-setup-04`

Brain injuries can provide evidence about function. For example, Phineas Gage’s frontal-lobe injury was linked with changes in behaviour and personality. One case cannot explain every function of a brain region.
`p3-chapter-944`

Wilder Penfield stimulated parts of the brain during surgery while patients were conscious. Their movements, sensations and reported experiences helped identify sensory and motor areas.
`p3-chapter-946`

Dissections and photographs show brain structures and their positions. Compare the surface view with a cross-section to see structures that are hidden from the outside.
`p3-chapter-948`

MRI uses magnetic fields and radio signals to create detailed images of brain structure. These images can help identify abnormalities.
`p3-chapter-950`

PET uses a radioactive tracer. In this example, labelled glucose shows differences in energy use that can be linked to brain activity.
`p3-chapter-951`

Compare: MRI provides structural detail; this PET example shows differences in tracer uptake. Read the scan’s key before drawing a conclusion. Neither is a direct picture of someone’s thoughts.
`p3-chapter-952`

## 12. Chapter review

Review the pathways and processes, then apply them to the chapter questions.
`p3-chapter-1055`

I can use Chapter 11 concepts to explain pathways and answer review questions.
`p3-l12-setup-02`

Complete the lessons first. Revisit any process you cannot yet explain.
`p3-l12-setup-04`

Trace a stimulus to a response : receptor → sensory neuron → CNS → motor neuron → effector . In a withdrawal reflex , the spinal circuit can start the movement before conscious processing.
`p3-chapter-1057`

At the cell level, a resting neuron has a membrane potential. Reaching threshold starts an action potential . Na⁺ enters during the rise; K⁺ leaves during the fall. Myelin speeds conduction. At a chemical synapse , neurotransmitters carry information to the next cell.
`p3-chapter-1064`

At the system level, the CNS is the brain and spinal cord. The PNS links them with the body. Somatic pathways control skeletal muscles; autonomic pathways regulate internal organs and glands. Sympathetic and parasympathetic pathways often have opposite effects.
`p3-chapter-1072`

Before the review, explain one complete pathway aloud: name the structures, describe what happens, and connect each step to the next.
`p3-chapter-1075`

## 13. Further exploration

Optional: connect this chapter with stress, experience and addiction. No personal disclosure is required.
`p3-chapter-1304`

I can connect the chapter with examples involving stress, experience and addiction.
`p3-l13-setup-02`

Review autonomic responses and synaptic transmission. Outside research is optional.
`p3-l13-setup-04`

The sympathetic response can occur during physical danger or psychological stress, such as an exam or deadline. The body responds to a perceived threat, even without immediate physical danger.
`p3-chapter-1306`

This optional topic explores frequent or intense stress responses and anxiety. It is not a diagnosis or treatment plan. You do not need to share personal experiences.
`p3-chapter-1308`

Use the chapter to explain which body functions change and how the autonomic system produces the response.
`p3-chapter-1309`

This optional example connects early experiences with brain development. The comparison image does not include enough study information to assess the research by itself.
`p3-chapter-1311`

The image is not enough evidence to diagnose someone or predict their future. No personal disclosure is required.
`p3-chapter-1312`

The video asks whether addiction can be understood as disease, learning, or both. Connect the discussion to synaptic transmission ; the title alone does not settle the question.
`p3-chapter-1315`

Discuss neurotransmitter release, receptor activity and signal removal. Use the biology to explain the process without judging the person.
`p3-chapter-1317`

## 14. Biology in practice

Optional: apply Chapter 11 to assistive technology and neurological disorders. No personal disclosure is required.
`p3-chapter-1345`

I can connect nervous-system function with assistive technology.
`p3-l14-setup-02`

Review the pathways used in the task. Personal disclosure is not required.
`p3-l14-setup-04`

### Nervous-system disorders and assistive technology
`p3-chapter-1346`

Nervous-system and neuromuscular disorders can also affect animals. Wheelchairs, harnesses, slings and ramps may support movement. The reading also discusses movement-related research in horses.
`p3-chapter-1347`

Read textbook page 400 , then connect the examples to nervous-system function. Some questions need outside research or current prices; the chapter does not provide all the answers.
`p3-chapter-1348`
