# Revised vocabulary fields

82 existing records are edited. Match stable word IDs; do not reorder or delete words. Only the fields listed here are changed.

## `a-word-homeostasis`

**definition:** Keeping internal conditions relatively stable as conditions change.

**whatItDoes:** Receptors detect a change, a control centre processes it, and effectors make adjustments.

## `a-word-dynamic-stability`

**definition:** Staying within limits by making ongoing adjustments.

**whatItDoes:** Conditions may fluctuate while the body keeps them within a suitable range.

## `a-word-workable-range`

**definition:** A range of values in which the relevant body process can function.

**whatItDoes:** Body systems help keep internal conditions within these limits.

## `a-word-regulated-variable-and-set-point`

**definition:** A regulated variable is a condition the body monitors. A set point or range is the reference used to judge a change.

**whatItDoes:** A control centre compares the detected condition with the reference and directs a response.

## `a-word-regulated-variable`

**definition:** An internal condition that the body monitors and adjusts.

**whatItDoes:** A change in the condition can trigger a corrective response.

## `a-word-set-point`

**definition:** The reference value or range used by a control system.

**whatItDoes:** The system compares the actual condition with this reference.

## `a-word-control-system-roles`

**definition:** The parts of a pathway: stimulus, receptor, control centre, effector and response.

**whatItDoes:** The receptor detects the stimulus. The control centre processes information, and the effector responds.

## `a-word-stimulus`

**definition:** A change or condition that can trigger a response.

**whatItDoes:** A receptor detects it and starts a signal.

## `a-word-receptor`

**definition:** A structure or molecule that detects a particular stimulus or signal.

**whatItDoes:** A sensory receptor detects a change. At a synapse, a receptor binds a chemical messenger and affects the receiving cell.

## `a-word-control-centre`

**definition:** The part of a system that processes information and directs a response.

**whatItDoes:** It receives information and coordinates what the effectors do.

## `a-word-effector`

**definition:** A cell, tissue or organ that carries out a response.

**whatItDoes:** A muscle can contract, or a gland can release a secretion.

## `a-word-response`

**definition:** What a cell or body does after a stimulus or signal.

**whatItDoes:** It changes an activity, such as muscle contraction or gland secretion.

## `a-word-negative-feedback`

**definition:** A response that opposes a change in a regulated condition.

**whatItDoes:** It moves the condition back toward its reference range.

## `a-word-feedback-loop`

**definition:** A pathway in which a response affects what happens next in the system.

**whatItDoes:** The result of one response changes further activity.

## `a-word-return-effect`

**definition:** The effect a response has on the condition that triggered it.

**whatItDoes:** The response may oppose or increase the original change.

## `a-word-scientific-explanation`

**definition:** An answer that uses evidence and biology to explain how or why something happens.

**whatItDoes:** It connects an observation with a biological process and states what is still uncertain.

## `a-word-claim`

**definition:** A statement or conclusion that can be checked.

**whatItDoes:** Evidence and reasoning can support or challenge it.

## `a-word-evidence`

**definition:** Observations or results used to support or challenge an explanation.

**whatItDoes:** It helps us decide which explanations fit what was observed.

## `a-word-reasoning`

**definition:** An explanation of why the evidence supports a conclusion.

**whatItDoes:** It connects the results to the relevant biology.

## `a-word-mechanism`

**definition:** The steps that explain how a process happens.

**whatItDoes:** It connects events in cells with the result we observe.

## `a-word-limitation`

**definition:** Something a method, model or result cannot tell us.

**whatItDoes:** It helps identify conclusions the evidence does not support.

## `a-word-neuron-structure`

**definition:** The parts of a nerve cell that receive and pass on information.

**whatItDoes:** Dendrites and the cell body receive information. The axon carries impulses toward its terminals.

## `a-word-neuron`

**definition:** A nerve cell that receives, processes and carries information.

**whatItDoes:** It passes information along its axon and communicates with other cells.

**commonConfusion:** A neuron is one cell. A nerve contains many nerve fibres.

**retrievalPrompt:** How does information usually move through a neuron?

## `a-word-dendrite`

**definition:** A branching extension of a neuron that usually receives information.

**whatItDoes:** It carries incoming information toward the cell body.

**commonConfusion:** Dendrites receive information; the axon carries impulses away from the cell body.

**retrievalPrompt:** Which way does information usually travel along a dendrite?

## `a-word-cell-body`

**definition:** The part of a neuron containing the nucleus and most organelles; also called the soma.

**whatItDoes:** It carries out the cell’s life processes and helps process incoming information.

**commonConfusion:** The cell body is not the same structure as the axon.

**retrievalPrompt:** What does the cell body contain, and what does it do?

## `a-word-axon`

**definition:** The extension that carries nerve impulses away from the cell body.

**whatItDoes:** It carries an impulse toward the axon terminals.

**commonConfusion:** An axon is part of a neuron, not a whole nerve.

**retrievalPrompt:** Which way does an impulse travel along the axon?

## `a-word-axon-terminal`

**definition:** The end region of an axon that communicates with another cell.

**whatItDoes:** At a chemical synapse, an arriving action potential triggers neurotransmitter release.

## `a-word-myelin-and-saltatory-conduction`

**definition:** Myelin insulates parts of an axon. Saltatory conduction regenerates the impulse at the gaps, called nodes of Ranvier.

**whatItDoes:** The signal spreads quickly between nodes. Schwann cells make PNS myelin; oligodendrocytes make CNS myelin.

## `a-word-myelin`

**definition:** A fatty insulating covering around some axons, made by glial cells.

**whatItDoes:** It reduces current loss and helps impulses travel faster.

**commonConfusion:** Myelin is the insulating covering, not the electrical signal.

**retrievalPrompt:** How would damaged myelin affect an impulse?

## `a-word-node-of-ranvier`

**definition:** A gap between myelin segments where the axon membrane is exposed.

**whatItDoes:** The action potential is regenerated at each node.

**commonConfusion:** The gap is in the myelin, not a break in the axon.

**retrievalPrompt:** Why are nodes of Ranvier important in a myelinated axon?

## `a-word-saltatory-conduction`

**definition:** Conduction in which an action potential is regenerated at the nodes of a myelinated axon.

**whatItDoes:** The signal spreads beneath the myelin to bring the next node to threshold.

**commonConfusion:** The axon is continuous. The action potential is regenerated at the nodes.

**retrievalPrompt:** How does saltatory conduction differ from conduction in an unmyelinated axon?

## `a-word-schwann-cell`

**definition:** A glial cell in the PNS that supports axons and can form myelin.

**whatItDoes:** A myelinating Schwann cell wraps around one segment of an axon.

## `a-word-oligodendrocyte`

**definition:** A glial cell that forms myelin in the CNS.

**whatItDoes:** One oligodendrocyte can form myelin segments around several axons.

## `a-word-resting-membrane-potential`

**definition:** The voltage difference across a neuron’s membrane when it is not firing; the inside is usually negative compared with the outside.

**whatItDoes:** Ion concentrations and selective permeability, especially K⁺ leakage, help produce the voltage. Pumps maintain the concentration differences.

**commonConfusion:** Resting does not mean that ions stop moving.

**retrievalPrompt:** Why is the inside negative compared with the outside at rest?

## `a-word-ion-gradient`

**definition:** A difference in an ion’s concentration across a membrane.

**whatItDoes:** Concentration differences and electrical forces affect ion movement through channels.

**commonConfusion:** Concentration and electrical charge are different ideas.

**retrievalPrompt:** Where is Na⁺ more concentrated at rest? Where is K⁺ more concentrated?

## `a-word-selective-permeability`

**definition:** Allowing some substances across a membrane more easily than others.

**whatItDoes:** Which channels are present and open affects which ions can cross.

## `a-word-action-potential`

**definition:** A rapid, all-or-none change in membrane voltage that carries a nerve impulse.

**whatItDoes:** At threshold, Na⁺ enters through voltage-gated channels. Later, K⁺ leaves, bringing the voltage back down.

**commonConfusion:** A stronger stimulus does not make one action potential taller.

**retrievalPrompt:** Which ions move during the rising and falling phases?

## `a-word-threshold`

**definition:** The membrane voltage at which an action potential starts.

**whatItDoes:** Enough depolarization opens voltage-gated channels and triggers the action potential.

**commonConfusion:** A small depolarization does not always reach threshold.

**retrievalPrompt:** What happens if the membrane does not reach threshold?

## `a-word-all-or-none-response`

**definition:** A neuron generates an action potential when threshold is reached, or it does not.

**whatItDoes:** A stronger stimulus does not make that neuron’s individual action potential taller.

**commonConfusion:** More impulses per second is not the same as a larger impulse.

**retrievalPrompt:** How can a stronger stimulus be signalled without a taller action potential?

## `a-word-propagation`

**definition:** The spread of a nerve impulse along an axon.

**whatItDoes:** One active section brings the next section to threshold, producing the next action potential.

**commonConfusion:** Sodium ions do not travel from one end of the axon to the other.

**retrievalPrompt:** How does one active section of membrane start activity in the next section?

## `a-word-membrane-potential-phases`

**definition:** Depolarization: less negative. Repolarization: back toward rest. Hyperpolarization: more negative than rest.

**whatItDoes:** Na⁺ entry causes the rise. Sodium-channel inactivation and K⁺ exit end it; continued K⁺ exit can produce an undershoot.

## `a-word-depolarization`

**definition:** The inside of a membrane becomes less negative compared with the outside.

**whatItDoes:** During the rising phase of an action potential, Na⁺ enters through sodium channels.

## `a-word-repolarization`

**definition:** The membrane voltage returns toward its resting level after depolarization.

**whatItDoes:** In the action-potential model, K⁺ leaves the cell, making the inside negative again.

## `a-word-hyperpolarization`

**definition:** The membrane becomes more negative than its resting level.

**whatItDoes:** K⁺ can keep leaving while potassium channels are slow to close.

## `a-word-refractory-period`

**definition:** A brief recovery time when another action potential is impossible or needs a stronger stimulus than usual.

**whatItDoes:** Sodium channels must recover before they can open again; later recovery can still make firing more difficult.

**commonConfusion:** Recovery does not happen in one instant.

**retrievalPrompt:** How does recovery behind an impulse help it travel forward?

## `a-word-absolute-refractory-period`

**definition:** The part of recovery when that membrane region cannot produce another action potential.

**whatItDoes:** Sodium channels are inactivated and must recover before firing again.

## `a-word-relative-refractory-period`

**definition:** The part of recovery when another action potential needs a stronger stimulus than usual.

**whatItDoes:** The membrane is still recovering, so it is harder to bring it to threshold.

## `a-word-channel-inactivation`

**definition:** A temporary state in which a channel cannot conduct ions or immediately reopen.

**whatItDoes:** An inactivated sodium channel must recover before opening again.

## `a-word-synaptic-transmission`

**definition:** Communication from one cell to another across a synapse.

**whatItDoes:** At a chemical synapse: an impulse arrives, Ca²⁺ enters, vesicles release neurotransmitter, receptors bind it, and the chemical message is removed.

**commonConfusion:** At a chemical synapse, neurotransmitter crosses the gap; the action potential does not jump across it.

**retrievalPrompt:** Trace the steps from arrival of an action potential to removal of the neurotransmitter.

## `a-word-synapse`

**definition:** A junction where a neuron communicates with another cell.

**whatItDoes:** At a chemical synapse, neurotransmitter carries the message between cells. Electrical synapses use a direct connection.

## `a-word-neurotransmitter`

**definition:** A chemical messenger released by a neuron at a synapse.

**whatItDoes:** It binds to receptors and changes the activity of the receiving cell.

**commonConfusion:** A neurotransmitter’s effect depends on the receptor and receiving cell.

**retrievalPrompt:** What happens after neurotransmitter binds to a receptor?

## `a-word-acetylcholine`

**definition:** A neurotransmitter used at neuromuscular junctions and many synapses in the CNS and autonomic system.

**whatItDoes:** It stimulates skeletal muscle. Its effects at other synapses depend on the receptors involved.

## `a-word-cholinesterase`

**definition:** An enzyme involved in breaking down acetylcholine; acetylcholinesterase is the specific enzyme at these synapses.

**whatItDoes:** Its action helps end the acetylcholine signal.

**commonConfusion:** Cholinesterase is an enzyme; acetylcholine is a neurotransmitter.

**retrievalPrompt:** How does cholinesterase help end the acetylcholine signal?

## `a-word-norepinephrine`

**definition:** A neurotransmitter and hormone, also called noradrenaline.

**whatItDoes:** Its action on receptors contributes to autonomic responses, including the sympathetic examples in this chapter.

## `a-word-agonist`

**definition:** A substance that activates a receptor.

**whatItDoes:** It can mimic a neurotransmitter’s action at that receptor.

## `a-word-antagonist`

**definition:** A substance that blocks or reduces receptor activation.

**whatItDoes:** It reduces the signal’s effect at that receptor.

## `a-word-reuptake`

**definition:** Taking released neurotransmitter back into cells from the synaptic space.

**whatItDoes:** This removes it from the space and allows it to be recycled or broken down.

**commonConfusion:** Reuptake returns transmitter to a cell; enzymatic breakdown breaks it into other molecules.

**retrievalPrompt:** What could happen if reuptake slows?

## `a-word-central-and-peripheral-nervous-systems`

**definition:** The CNS is the brain and spinal cord. The PNS links the CNS with the rest of the body.

**whatItDoes:** Sensory pathways carry information toward the CNS; motor pathways carry instructions to effectors.

## `a-word-central-nervous-system`

**whatItDoes:** It processes information and directs responses.

## `a-word-peripheral-nervous-system`

**whatItDoes:** It carries sensory information toward the CNS and motor information away.

## `a-word-cns`

**definition:** The central nervous system: the brain and spinal cord.

**whatItDoes:** It processes information and coordinates responses.

## `a-word-pns`

**definition:** The peripheral nervous system: nervous tissue outside the brain and spinal cord.

**whatItDoes:** It connects the CNS with receptors and effectors.

## `a-word-somatic-and-autonomic-systems`

**definition:** Somatic motor pathways control skeletal muscles. Autonomic pathways regulate smooth muscle, heart muscle and glands.

**whatItDoes:** Compare the target: skeletal muscle versus internal organs and glands.

## `a-word-somatic-nervous-system`

**definition:** The system carrying somatic sensory information and controlling skeletal muscles.

**whatItDoes:** Its motor pathways control voluntary movements and skeletal-muscle reflexes.

**commonConfusion:** Skeletal-muscle reflexes are not consciously chosen, even though they use somatic motor pathways.

**retrievalPrompt:** How are voluntary movement and a skeletal-muscle reflex alike?

## `a-word-autonomic-nervous-system`

**definition:** The motor system that controls involuntary activity in smooth muscle, heart muscle and glands.

**whatItDoes:** Its sympathetic and parasympathetic pathways adjust organ activity.

**commonConfusion:** Autonomic does not mean that every organ speeds up.

**retrievalPrompt:** Name two activities controlled by the autonomic system.

## `a-word-voluntary-control`

**definition:** Control of an action you can consciously start or change.

**whatItDoes:** It allows planned movements using skeletal muscles.

## `a-word-visceral-control`

**definition:** Control of internal-organ activity.

**whatItDoes:** Autonomic pathways affect glands, smooth muscle and heart muscle.

## `a-word-sympathetic-and-parasympathetic-divisions`

**definition:** The autonomic divisions associated with fight-or-flight and rest-and-digest responses.

**whatItDoes:** They often have opposite effects on the same organ and adjust activity to the situation.

## `a-word-sympathetic-division`

**definition:** The autonomic division involved in the fight-or-flight response.

**whatItDoes:** It can increase heart activity while reducing digestion, preparing the body for action.

**commonConfusion:** Fight-or-flight increases some activities and reduces others.

**retrievalPrompt:** What happens to heart rate and digestion during a sympathetic response?

## `a-word-parasympathetic-division`

**definition:** The autonomic division involved in rest-and-digest activity.

**whatItDoes:** It can slow the heart and increase digestive activity.

**commonConfusion:** Rest-and-digest does not mean that all organs stop working.

**retrievalPrompt:** What happens to heart rate and digestion during a parasympathetic response?

## `a-word-autonomic-balance`

**definition:** The combined effects of autonomic pathways on an organ.

**whatItDoes:** Changing sympathetic and parasympathetic activity adjusts the organ’s function.

## `a-word-reflex-arc`

**definition:** A neural pathway producing a rapid, involuntary response to a stimulus.

**whatItDoes:** In a withdrawal reflex, information passes through the spinal cord to a motor neuron and muscle; information also reaches the brain.

**commonConfusion:** Not every reflex needs an interneuron. Information can still reach the brain.

**retrievalPrompt:** Trace the five components of a withdrawal reflex.

## `a-word-reflex`

**definition:** A rapid, involuntary response to a stimulus.

**whatItDoes:** It follows a neural circuit without waiting for a conscious decision.

## `a-word-sensory-neuron`

**definition:** A neuron carrying information from a sensory receptor toward the CNS.

**whatItDoes:** It brings sensory input to the brain or spinal cord.

**commonConfusion:** Sensory neurons carry information toward the CNS, not instructions to a muscle.

**retrievalPrompt:** Which neuron carries information from a skin receptor to the spinal cord?

## `a-word-interneuron`

**definition:** A neuron within the CNS that connects and processes signals between neurons.

**whatItDoes:** It can link sensory input with motor output in a withdrawal reflex.

**commonConfusion:** An interneuron operates within the CNS, not directly between the CNS and a muscle.

**retrievalPrompt:** What does the interneuron do in a withdrawal reflex?

## `a-word-motor-neuron`

**definition:** A neuron carrying instructions from the CNS toward an effector.

**whatItDoes:** It sends output toward a muscle or gland.

**commonConfusion:** Motor output can be voluntary or involuntary.

**retrievalPrompt:** Which neuron carries instructions from the spinal cord toward a muscle?

## `a-word-hormone`

**definition:** A chemical messenger released by endocrine cells that acts on target cells with the right receptors.

## `a-word-hypothalamus`

**definition:** A brain region that regulates internal conditions and links the nervous and endocrine systems.

## `a-word-pituitary`

**definition:** An endocrine gland connected to the hypothalamus, with anterior and posterior parts.

## `a-word-opposing-effects`

**definition:** Effects that move the same condition in opposite directions.

## `a-word-stress-response`

**definition:** Nervous and hormonal responses that prepare the body for a challenge and help it recover afterward.

## `a-word-epinephrine`

**definition:** A hormone from the adrenal medulla, also called adrenaline.
