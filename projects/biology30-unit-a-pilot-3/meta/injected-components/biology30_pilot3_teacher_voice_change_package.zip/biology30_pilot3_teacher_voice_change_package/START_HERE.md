# Biology 30 — Pilot 3 teacher-voice change package

## Give this package to Codex
Open `01_CODEX_TASK.md` first. It is the implementation brief. The task is to apply the exact editorial changes and complete the structural tasks, not generate another generic rewrite.

### Paste into Codex
```text
Implement the attached Biology 30 Pilot 3 teacher-voice change package.

Read START_HERE.md and 01_CODEX_TASK.md first. Inspect the current repository's Pilot 3 canonical sources and report conflicts with the uploaded snapshot before editing.

Apply 02_EXACT_TEXT_CHANGES.json and synchronize the matching live vocabulary fields in 03_VOCABULARY_PAYLOAD_CHANGES.json. Complete every task in 04_STRUCTURAL_CHANGES.json using 05_LAYOUT_AND_SCOPE.md. Follow the source-conflict safeguards in 06_SOURCE_AND_SCIENCE_GUARDRAILS.md and run 07_ACCEPTANCE_TESTS.md.

Preserve the current activities, questions, answer keys, images, video/textbook links, routes, timers, generated sessions, progress rules and saved learner work. Do not copy the standalone HTML over the repository or regenerate the old pilot. Do not edit other courses or silently change scientific content or assessment scope.

The helper scripts apply and verify only the copy phase. The task is not complete until the structural changes, canonical rebuild and browser/save regressions are done. Report exact edits applied, conflicts, completed task IDs, test results and remaining limitations.
```

## Files
| File | Purpose |
|---|---|
| `01_CODEX_TASK.md` | Scope, implementation order, repository safety and reporting |
| `02_EXACT_TEXT_CHANGES.json` | 601 exact before/after HTML edits with selectors, guards and source context |
| `03_VOCABULARY_PAYLOAD_CHANGES.json` | 208 live-data field edits across 82 existing word IDs |
| `04_STRUCTURAL_CHANGES.json` | 12 task records for the remaining layout, scope and presentation work |
| `05_LAYOUT_AND_SCOPE.md` | What stays visible, what becomes extra help, and what must remain accessible |
| `06_SOURCE_AND_SCIENCE_GUARDRAILS.md` | Slide-to-lesson map and source disagreements that must not be silently rewritten |
| `07_ACCEPTANCE_TESTS.md` | Copy, content, UI, saved-state, assessment, build and export gates |
| `tools/apply_copy.py` | Standard-library dry-run / candidate patcher; refuses source overwrite |
| `tools/audit_copy.py` | Static copy-phase invariant check |
| `tools/test_package.py` | Eight tests using the uploaded HTML as a fixture |
| `review/` | Readable revised copy, vocabulary, examples, source fingerprints and validation results |

## What this is not
It is not a new course ZIP, a SCORM package or a deployed repository change. No assets, fonts, teacher slide deck or original course are redistributed. The helpers create a local candidate only when given the actual input file. The existing course's assets must remain available in the repository's normal preview/build environment.

The package was tested against the uploaded HTML. Current repository differences must be reconciled explicitly. No extra software package is needed for the three Python helpers.
