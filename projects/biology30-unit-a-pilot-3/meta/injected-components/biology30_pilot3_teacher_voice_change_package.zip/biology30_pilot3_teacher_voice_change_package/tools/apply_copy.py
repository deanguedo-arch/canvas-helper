#!/usr/bin/env python3
"""Apply the package's exact copy edits to an HTML candidate, not directly to a repository.

Standard library only. Preflight checks every target before writing anything.
Usage:
  python tools/apply_copy.py --input /path/to/pilot3.html --dry-run
  python tools/apply_copy.py --input /path/to/pilot3.html --output /tmp/pilot3-copy-candidate.html

This applies TEXT + VOCABULARY PAYLOAD only. Structural tasks are specified separately.
"""
from __future__ import annotations
import argparse
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
from typing import Any

VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
class Nodes(HTMLParser):
    def __init__(self, source: str):
        super().__init__(convert_charrefs=True)
        self.source = source
        self.lines = [0]
        for m in re.finditer('\n',source): self.lines.append(m.end())
        self.stack: list[dict[str,Any]] = []
        self.nodes: list[dict[str,Any]] = []
        self.feed(source); self.close()
    def absolute_pos(self) -> int:
        line, col = self.getpos(); return self.lines[line-1] + col
    def handle_starttag(self, tag, attrs):
        p=self.absolute_pos(); raw=self.get_starttag_text()
        n={'tag':tag,'attrs':dict(attrs),'start':p,'inner_start':p+len(raw),'inner_end':p+len(raw),'end':p+len(raw)}
        self.nodes.append(n)
        if tag not in VOID: self.stack.append(n)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag,attrs)
        if tag not in VOID: self.stack.pop()
    def handle_endtag(self, tag):
        p=self.absolute_pos(); end=self.source.find('>',p)+1
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i]['tag']==tag:
                node=self.stack[i]; node['inner_end']=p; node['end']=end
                del self.stack[i:]; return

class Plain(HTMLParser):
    def __init__(self, fragment):
        super().__init__(convert_charrefs=True); self.parts=[]; self.feed(fragment)
    def handle_data(self, data):
        if data.strip(): self.parts.append(data.strip())

def plain(fragment: str) -> str:
    return re.sub(r'\s+',' ',' '.join(Plain(fragment).parts)).strip()
def sha(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()
def index(source: str):
    p=Nodes(source); by={}
    for n in p.nodes:
        k=n['attrs'].get('data-canvas-helper-edit-key')
        if k:
            if k in by: raise ValueError(f'Duplicate edit key: {k}')
            by[k]=n
    return p,by

def build_candidate(source: str, root: Path) -> tuple[str, dict[str,Any]]:
    manifest=json.loads((root/'02_EXACT_TEXT_CHANGES.json').read_text(encoding='utf-8'))
    wm=json.loads((root/'03_VOCABULARY_PAYLOAD_CHANGES.json').read_text(encoding='utf-8'))
    parser,by=index(source)
    patches=[]; errors=[]
    for c in manifest['replacements']:
        n=by.get(c['editKey'])
        if n is None: errors.append(f"Missing {c['editKey']}"); continue
        before=source[n['inner_start']:n['inner_end']]
        if (n['tag']!=c['tag'] or plain(before)!=c['beforeText']
                or sha(before)!=c.get('beforeInnerSha256',sha(before))):
            errors.append(f"Stale content at {c['editKey']}; do not fuzzy-replace it."); continue
        if plain(c['afterHtml'])!=c['afterText']:
            errors.append(f"Manifest text/HTML mismatch at {c['editKey']}"); continue
        patches.append((n['inner_start'],n['inner_end'],c['afterHtml']))
    candidates=[n for n in parser.nodes if n['tag']=='script' and n['attrs'].get('id')==wm['scriptId']]
    field_count=0
    if len(candidates)!=1: errors.append('Expected one #pilot3-words JSON script')
    else:
        n=candidates[0]
        try:
            payload=json.loads(source[n['inner_start']:n['inner_end']])
            schema_before=json.dumps(payload['schema'],sort_keys=True)
            words={w['id']:w for w in payload['data']['words']}
            for change in wm['changes']:
                if change['wordId'] not in words:
                    errors.append(f"Missing word {change['wordId']}"); continue
                word=words[change['wordId']]
                for field,values in change['fields'].items():
                    if word.get(field)!=values['before']:
                        errors.append(f"Stale vocabulary {change['wordId']}.{field}"); continue
                    word[field]=values['after']; field_count+=1
            assert json.dumps(payload['schema'],sort_keys=True)==schema_before
            # Escape '<' to prevent any data value from terminating a script element.
            encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
            patches.append((n['inner_start'],n['inner_end'],encoded))
        except (KeyError,ValueError,TypeError) as e: errors.append(f'Vocabulary payload invalid: {e}')
    patches.sort()
    for a,b in zip(patches,patches[1:]):
        if a[1]>b[0]: errors.append('Overlapping edit ranges; stop and inspect.')
    if errors: raise ValueError('\n'.join(errors))
    result=source
    for start,end,new in reversed(patches): result=result[:start]+new+result[end:]
    return result, {'source_sha256':sha(source),'manifest_source_sha256':manifest['sourceSha256'],
                    'exact_snapshot_match':sha(source)==manifest['sourceSha256'],
                    'text_targets_checked':len(manifest['replacements']),
                    'vocabulary_records_checked':len(wm['changes']),
                    'vocabulary_fields_changed':field_count,'result_sha256':sha(result),
                    'structural_tasks_applied':False}

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input',required=True,type=Path)
    ap.add_argument('--output',type=Path)
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--package',type=Path,default=Path(__file__).resolve().parents[1])
    args=ap.parse_args()
    try:
        if not args.dry_run and not args.output: raise ValueError('Use --dry-run or specify --output.')
        if args.output and args.output.resolve()==args.input.resolve():raise ValueError('Refusing to overwrite the source.')
        if not args.dry_run and args.output.exists():raise ValueError('Output already exists. Choose a new path.')
        source=args.input.read_text(encoding='utf-8')
        candidate,report=build_candidate(source,args.package)
        if not args.dry_run:
            args.output.parent.mkdir(parents=True,exist_ok=True)
            with args.output.open('x',encoding='utf-8') as f:f.write(candidate)
            report['candidate_written']=str(args.output)
        print(json.dumps(report,indent=2))
        return 0
    except (OSError,ValueError,AssertionError) as e:
        print(f'STOP: {e}',file=sys.stderr); return 2
if __name__=='__main__':raise SystemExit(main())
