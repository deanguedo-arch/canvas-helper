#!/usr/bin/env python3
"""Run package-only tests using the actual uploaded HTML as the fixture."""
from pathlib import Path
import argparse,json,unittest
from apply_copy import build_candidate, index
from audit_copy import audit

ROOT=Path(__file__).resolve().parents[1]
class PackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=INPUT.read_text(encoding='utf-8')
        cls.candidate,cls.report=build_candidate(cls.source,ROOT)
        cls.manifest=json.loads((ROOT/'02_EXACT_TEXT_CHANGES.json').read_text())
    def test_all_text_targets_apply(self):
        self.assertEqual(self.report['text_targets_checked'],len(self.manifest['replacements']))
    def test_protected_content_and_state_metadata_unchanged(self):
        result=audit(self.source,self.candidate,ROOT)
        self.assertTrue(result['pass'],json.dumps(result))
    def test_deterministic_output(self):
        second,_=build_candidate(self.source,ROOT)
        self.assertEqual(second,self.candidate)
    def test_missing_target_fails_closed(self):
        changed=self.source.replace('data-canvas-helper-edit-key="p3-integrated-2"','data-canvas-helper-edit-key="fixture-missing-key"',1)
        with self.assertRaisesRegex(ValueError,'Missing p3-integrated-2'):build_candidate(changed,ROOT)
    def test_stale_paragraph_fails_closed(self):
        _,nodes=index(self.source);n=nodes['p3-integrated-2'];i=n['inner_start']
        changed=self.source[:i]+'NEW EDIT '+self.source[i:]
        with self.assertRaisesRegex(ValueError,'Stale content'):build_candidate(changed,ROOT)
    def test_same_words_changed_inline_binding_fails_closed(self):
        _,nodes=index(self.source);n=nodes['p3-integrated-11']
        inside=self.source[n['inner_start']:n['inner_end']]
        self.assertIn('data-bio-term',inside)
        changed_inside=inside.replace('data-bio-term=', 'data-fixture-different-binding=',1)
        changed=self.source[:n['inner_start']]+changed_inside+self.source[n['inner_end']:]
        with self.assertRaisesRegex(ValueError,'Stale content'):build_candidate(changed,ROOT)
    def test_second_application_does_not_overwrite_new_text(self):
        with self.assertRaises(ValueError):build_candidate(self.candidate,ROOT)
    def test_changed_answer_value_detected(self):
        self.assertIn('QUES_51676_82712_A275484',self.candidate)
        altered=self.candidate.replace('value="QUES_51676_82712_A275484"','value="fixture-bad-key"',1)
        result=audit(self.source,altered,ROOT)
        self.assertFalse(result['pass'])
        self.assertFalse(result['checks']['answer_fields_unchanged'])

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,type=Path)
    args=parser.parse_args();INPUT=args.input
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(PackageTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
