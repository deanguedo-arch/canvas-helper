#!/usr/bin/env python3
"""Validate a COPY-PHASE candidate against its source. Does not test the LMS/runtime."""
from __future__ import annotations
import argparse, json, re, hashlib
from collections import Counter
from pathlib import Path
from apply_copy import Nodes, index, plain, sha

def subset(source,parser,pred):
    return [source[n['start']:n['end']] for n in parser.nodes if pred(n)]
def inspect(source):
    parser,by=index(source)
    scripts={n['attrs'].get('data-inline-source'):source[n['inner_start']:n['inner_end']]
             for n in parser.nodes if n['tag']=='script' and n['attrs'].get('data-inline-source')}
    wp=next(n for n in parser.nodes if n['tag']=='script' and n['attrs'].get('id')=='pilot3-words')
    payload=json.loads(source[wp['inner_start']:wp['inner_end']])
    stable_attrs=['data-activity','data-required-check','data-question','data-writing','data-answer-limit',
                  'data-word-frayer','data-biology-word-view','data-biology-select-word','data-unlock']
    bindings=Counter((n['tag'],tuple((k,n['attrs'][k]) for k in stable_attrs if k in n['attrs']))
                     for n in parser.nodes if any(k in n['attrs'] for k in stable_attrs))
    return {
      'ids':Counter(n['attrs']['id'] for n in parser.nodes if n['attrs'].get('id')),
      'bindings':bindings,
      'questions':subset(source,parser,lambda n:'data-question' in n['attrs']),
      'frayer_shells':subset(source,parser,lambda n:'data-word-frayer' in n['attrs']),
      'images':[n['attrs'] for n in parser.nodes if n['tag']=='img'],
      'hrefs':Counter(n['attrs']['href'] for n in parser.nodes if n['attrs'].get('href')),
      'answer_fields':[n['attrs'] for n in parser.nodes if n['tag'] in ['input','textarea','option','select']],
      'required':sum('data-required-check' in n['attrs'] for n in parser.nodes),
      'scripts':scripts,'payload':payload,'by':by,'parser':parser}

def audit(before,after,root):
    a,b=inspect(before),inspect(after)
    results={}
    for k in ['ids','bindings','questions','frayer_shells','images','hrefs','answer_fields','required','scripts']:
        results[k+'_unchanged']=a[k]==b[k]
    results['word_schema_unchanged']=a['payload']['schema']==b['payload']['schema']
    wm=json.loads((root/'03_VOCABULARY_PAYLOAD_CHANGES.json').read_text())
    allowed={x['wordId']:x['fields'] for x in wm['changes']}
    aa={w['id']:w for w in a['payload']['data']['words']};bb={w['id']:w for w in b['payload']['data']['words']}
    results['word_order_unchanged']=list(aa)==list(bb)
    unexpected=[]
    for wid,w in aa.items():
        v=bb.get(wid,{})
        for field in set(w)|set(v):
            if w.get(field)!=v.get(field) and field not in allowed.get(wid,{}):unexpected.append(wid+'.'+field)
    results['only_allowlisted_word_fields_changed']=not unexpected
    m=json.loads((root/'02_EXACT_TEXT_CHANGES.json').read_text())
    incorrect=[]
    for c in m['replacements']:
        n=b['by'].get(c['editKey'])
        if not n or plain(after[n['inner_start']:n['inner_end']])!=c['afterText']: incorrect.append(c['editKey'])
    results['all_after_text_matches']=not incorrect
    live_errors=[]
    for c in wm['changes']:
        for field,value in c['fields'].items():
            if bb[c['wordId']].get(field)!=value['after']:live_errors.append(c['wordId']+'.'+field)
    results['live_vocabulary_payload_matches']=not live_errors
    return {'pass':all(results.values()),'checks':results,'required_checks':a['required'],
            'protected_question_nodes':len(a['questions']),'protected_frayer_shells':len(a['frayer_shells']),
            'protected_image_nodes':len(a['images']),'unexpected_word_changes':unexpected,
            'incorrect_after_text':incorrect,'incorrect_live_fields':live_errors,
            'limitations':['Static copy-phase comparison only. Layout tasks not applied by this validator.',
                          'No browser interaction, saved-state round-trip, shared-course or SCORM/LMS test.']}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--before',required=True,type=Path);p.add_argument('--after',required=True,type=Path)
    p.add_argument('--report',type=Path)
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    r=audit(a.before.read_text(),a.after.read_text(),root)
    t=json.dumps(r,indent=2)
    if a.report:a.report.write_text(t+'\n')
    print(t)
    raise SystemExit(0 if r['pass'] else 2)
if __name__=='__main__':main()
