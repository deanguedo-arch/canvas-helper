# Neural-pathway labelling activity — implementation notes

## Handoff status and exceptions

The four-file prototype is built. The exact five assessed mappings and all existing
answer-control IDs are preserved. There are **two exceptions to the supplied brief**:

1. **Illustration method:** ChatGPT image creation was attempted twice but returned
   unrelated images. Neither is included. The delivered PNG is an original,
   programmatically drawn vector scientific schematic, rasterized to PNG. It is
   **not** a successful generative-image output and does not satisfy that specific
   production-method requirement. It was composed independently, not traced from
   the supplied reference. Its visible callouts are exactly A, B, C, D and J.
2. **Direct local-file launch:** The sandbox's managed Chromium blocks both `file://`
   and localhost navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. Therefore an actual
   double-click/local-relative-image launch could not be verified here. Functional
   and responsive testing used an isolated browser render, as detailed below.
   **Run the local launch check below before treating the return checklist as fully
   signed off.** The delivered HTML uses a relative PNG reference and contains no
   network-dependent code.

## Files and local launch

Keep these four files together in the same extracted folder:

- `neural-pathway-labeling.png`
- `interactive-labeling.html`
- `hotspots.json`
- `implementation-notes.md`

Open `interactive-labeling.html` in a browser. No installation, build step, server,
remote library or Internet connection is required by the implementation. Opening
HTML from inside a compressed ZIP may prevent the companion PNG from loading;
extract the whole ZIP first. The HTML alone is not the full activity: it intentionally
loads its local PNG as required by the brief.

**Remaining local launch check:** With the computer disconnected from the Internet,
open the extracted HTML, confirm the image appears, select/check a wrong answer,
then a correct answer, and use **Check all labels**. Narrow the browser window and
confirm the controls appear immediately below the image. Reload to confirm answers
clear. Browser-managed restrictions on local files may require an unmanaged browser
or the institution's normal permitted content-delivery method; do not change managed
security settings to run this prototype.

The PNG has a friendly error message and an expanded text description if loading
fails. There is no remote image fallback.

## Illustration and scientific assumptions

- Raster dimensions: **1600 × 1000 pixels**, white background, 8:5 aspect ratio.
- The small layered oval is a schematic sensory ending in the skin. A long afferent
  fibre, with its cell body on a side branch outside the central region, carries the
  signal toward that region. An interneuron communicates with a motor neuron there.
  The motor axon exits and branches onto striated skeletal-muscle fibres.
- The pale dashed region represents part of the central nervous system, not a
  labelled or anatomically exact spinal-cord cross-section.
- Direction arrows are separate from the thin letter leader lines. Distinct synaptic
  gaps separate the three neurons. The receptor is shown as a specialized sensory
  ending, not as an additional assessed neuron.
- This is a simplified sensory-to-motor circuit, not every possible neural pathway.
  Shape, size, colour, axon length and myelin are schematic. The relative soma sizes
  are not universal biological rules. No additional letters or structures are assessed.
- The PNG contains no written answer names, title, buttons, dropdowns or watermark.

## Exact integration contract

Existing course activity identifier: `labeling`.

| Letter | Existing control ID | Stored answer value | Visible choice |
|---|---|---|---|
| A | `label-A` | `sensory neuron` | Sensory neuron |
| B | `label-B` | `interneuron` | Interneuron |
| C | `label-C` | `motor neuron` | Motor neuron |
| D | `label-D` | `sensory receptor` | Sensory receptor |
| J | `label-J` | `effector` | Effector (muscle) |

Every select has the same five options in the supplied order, plus a blank
`value=""` placeholder. Options are not removed when selected elsewhere; answers
are independent. Native `change` events remain available for future integration.
The answer key is defined once inside the script. It is visible to someone inspecting
client-side source, as is normal for an offline practice prototype. This is not a
secure examination mechanism.

The DOM, keyboard and narrow-screen list order is **D, A, B, C, J**, matching the
upper row left-to-right, then the lower row, and the pathway's visual reading order.
This changes no answer IDs, mappings or option values.

Canvas Helper should adapt this markup and its checking logic to the existing
`labeling` activity, rather than create a second competing activity or rename IDs.
Do not replace existing saved answers or install a second state manager. The
prototype adds no save-state, timer, attempt history, Process Collection, LMS API,
SCORM wrapper or persistent storage. Remove/adapt the standalone reload warning
when the course runtime supplies persistence. The document-level CSP belongs to the
standalone file; use the host course's approved policy when integrating its markup.

## Hotspot coordinates and responsive layout

`hotspots.json` is descriptive integration data; the HTML does **not** fetch it.
The matching positions are embedded in the HTML as CSS custom properties so local
file use needs no JSON request.

All `x` and `y` values are percentages of the **displayed, uncropped image content
box**, with origin at its top-left. They are not viewport or page percentages.

- `x` is the horizontal **centre** of a control group.
- `y` is that group's **top edge**.
- CSS applies `left: x%`, `top: y%`, and `transform: translateX(-50%)`.
- `calloutX` and `calloutY` locate the centre of the printed image letter, separately
  from the control anchor. They are informational and must not be substituted for
  the control's `x`/`y`.
- The image uses `width:100%; height:auto` without cropping. If it is letterboxed
  or cropped during integration, calculate positions against its actual content
  box instead of the outer container.

| Letter | Control x (%) | Control y (%) | Printed-letter x (%) | Printed-letter y (%) |
|---|---:|---:|---:|---:|
| A | 49.0625 | 6.5 | 49.0625 | 30.0 |
| B | 80.5 | 6.5 | 80.5 | 30.0 |
| C | 51.25 | 81.5 | 51.25 | 77.7 |
| D | 17.5 | 6.5 | 17.5 | 30.0 |
| J | 85.625 | 81.5 | 85.625 | 77.7 |

At an **activity-container width of at least 880 px**, a CSS container query
positions each control close to its letter, in the image's reserved white space.
Control groups are 27% of the image width. The figure is capped at 1000 CSS px.
This threshold uses the activity's available width, including when embedded in a
narrow course column; it does not assume the browser window is the content width.

Below 880 px, the same controls move into normal document flow immediately below
the full-width image. They are compact rows, not five tall cards. They keep their
values, feedback, IDs and listeners during resize. Browsers without container-query
support retain the default readable list layout.

## Interaction and accessibility

- Each select has a visible letter and a descriptive, explicitly associated label.
- The image has concise alt text and `aria-details` connecting it to an expandable
  long description. The description explains the schematic and gives letter-to-
  visual-feature locations without directly supplying the letter-to-answer key.
- Native selects, buttons and a native details/summary work with the keyboard.
  A skip link is included. Focus has a visible 3 px outline with a 3 px offset.
- Selects and buttons use at least 16 px text and 44 px-high touch targets.
- Correct/incorrect feedback is written as **Correct** or **Not correct yet**, so
  meaning is not conveyed by colour alone. Unanswered checks say **Choose a label
  first.** Wrong answers never reveal the correct option through feedback.
- Per-select feedback is associated through `aria-describedby`. Individual checks
  use one polite live announcement; **Check all labels** uses one aggregate status
  announcement rather than speaking five competing live regions.
- Editing a checked answer clears its old feedback. Editing after an aggregate check
  marks the total out of date until it is checked again.
- No navigation opens the image in a new tab/window. There are no trackers, remote
  assets, dependencies, fonts, fetch calls, storage APIs or pop-up functions.
- No animation is required; reduced-motion and forced-colour styles are present.
- Semantics and keyboard behaviour were tested. No live screen-reader test or formal
  accessibility-conformance certification was performed.

## Validation actually performed

System Chromium was automated using Playwright with browser networking set offline.
Because managed navigation was blocked, a test-only copy of the HTML was inserted
into an isolated `about:blank` page. The **same packaged PNG** was supplied as an
in-memory data URI; the test-only image CSP was widened to allow that URI. All other
HTML, CSS and JavaScript remained the same. These changes are **not** in the
delivered HTML, which still references `neural-pathway-labeling.png` locally.

Passed checks:

- Packaged PNG renders at its intended 1600 × 1000 dimensions.
- All five required IDs, all five option values and all display strings match the
  supplied `answer-key.json`.
- **30 individual checks:** all five choices plus the unanswered state for each of
  the five letters; feedback is correct and wrong attempts disclose no answer.
- **32 complete answer sets:** every correct/incorrect combination produces the
  expected count out of five.
- Empty and partial sets, stale-total clearing, and per-answer feedback reset work.
- A fresh document render starts with all choices empty. Actual browser reload via
  `file://` is part of the remaining local launch check, not a claimed test result.
- Keyboard-only native-option selection, individual checking, visible focus and
  opening the long description work.
- Layout checks at **320, 390, 600, 768, 900, 944, 1024 and 1400 px** viewport widths:
  no horizontal page overflow, no overlapping control groups, all controls at least
  44 px high, and all control text at least 16 px. Desktop controls stay within the
  image; narrow-screen controls are below it.
- Desktop and narrow-screen screenshots were visually reviewed.
- Zero HTTP/HTTPS/WebSocket requests, JavaScript errors, console errors or pop-ups
  occurred in the isolated render.
- Static inspection found no storage, fetch/XHR, tracking, pop-up or LMS APIs.

**Not claimed:** direct local-file/relative-PNG loading, actual local-file reload,
Brightspace/Canvas Helper integration, live screen-reader testing, or a successful
ChatGPT generative-image result. Those boundaries should travel with this handoff.
