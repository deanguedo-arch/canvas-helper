# Codex Implementation Brief — AFTER Review Approval

Do not implement this package as a blind bulk insertion. Treat the `L01-L50_VIDEO_INTEGRATION_MAP.csv` as a proposal that requires teacher sign-off and final external-source URLs.

## Phase 1 — inventory

1. Inspect the canonical course source and identify the exact content files/pages for L01–L50.
2. Verify lesson titles against the canonical course. Do not rename canonical lessons from this package if the live course differs.
3. Identify the existing component system for callouts, embeds, quick checks, transcripts, asset manifests, and external links.
4. Report any lesson where the current structure makes the proposed placement ambiguous.

## Phase 2 — component pattern

Implement one reusable video component pattern matching `BRIGHTSPACE_IMPLEMENTATION_PATTERN.md`:

- watch-for prompt;
- accessible player/embed;
- source metadata;
- external fallback link;
- transcript/summary control;
- immediate post-watch interaction;
- continuation block.

Do not autoplay. Do not use video-view completion as mastery.

## Phase 3 — approved external videos

Only add an external video when the review record includes the approved URL/source metadata. Do not invent or substitute a different YouTube video because a row says “external.”

For every external source store:

- title;
- creator;
- URL;
- year/date;
- runtime/excerpt;
- captions status;
- last checked date;
- lesson and instructional job;
- fallback summary/transcript reference.

If a URL is not approved, leave a structured `VIDEO_SOURCE_PENDING` placeholder in the developer data/manifest, not in learner-facing content.

## Phase 4 — custom videos

Do not fabricate finished MP4 files. Add learner-facing custom-video components only after the actual reviewed MP4/VTT/transcript/poster assets exist.

Until then, keep implementation hooks/manifest entries developer-side only.

## Phase 5 — tests

Add regression coverage for:

- no autoplay;
- required accessible label/title;
- captions/transcript route recorded;
- direct-link fallback for external embeds;
- watch-for prompt precedes video;
- post-watch interaction follows video;
- no `VIDEO_SOURCE_PENDING` appears in learner-facing output;
- video completion does not set mastery;
- lessons without approved video remain unchanged;
- external-source metadata is complete.

## Phase 6 — review report

Return:

1. changed lessons;
2. unchanged lessons;
3. external videos integrated with exact URL/source metadata;
4. custom-video slots still waiting on assets;
5. accessibility checks;
6. regression results;
7. screenshots or preview references for at least one external-video lesson and one custom-video lesson;
8. any unresolved course-structure conflicts.

## Hard boundary

The course must remain instructionally self-contained. Third-party video can enrich the lesson but cannot become the sole carrier of required content or assessment instructions.
