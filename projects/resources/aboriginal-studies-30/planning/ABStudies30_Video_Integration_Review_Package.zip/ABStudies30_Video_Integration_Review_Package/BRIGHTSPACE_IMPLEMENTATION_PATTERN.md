# Brightspace Implementation Pattern

## Standard video component

Video is a **lesson component**, not a standalone detour. Use this sequence.

### 1. Teaching before the player

Students should already know enough to understand what they are about to watch. Keep the setup short and use the existing lesson content wherever possible.

### 2. Watch-for card

Use one question only.

Example:

> **Watch for:** What changes when a community has control over the decision rather than only being consulted?

Do not use vague prompts such as “Watch the following video and take notes.”

### 3. Player card

Recommended visible fields:

- video title;
- creator/organization;
- date/year if relevant;
- runtime or assigned excerpt;
- caption status;
- embedded player;
- **Open video in a new tab** fallback link;
- transcript/accessible summary control.

No autoplay.

### 4. Quick check

Use one small interaction immediately after the video. Good formats:

- 1 multiple-choice question requiring interpretation;
- 1 sorting/classification interaction;
- 1 compare/contrast row;
- 1 claim-evidence connection;
- 1 short constructed response of 1–3 sentences;
- 1 prediction before the next section.

Avoid a completion checkbox as the only follow-up.

### 5. Continue the lesson

The next block should explicitly connect the video back to course learning: “Now apply that idea to…” or “Keep that distinction in mind as you examine…”

## Resilience requirement

The page must remain instructionally coherent if the player fails to load. Therefore:

- never place unique assessment instructions inside video only;
- provide a short course-side summary of the key concept;
- keep the transcript or equivalent accessible text route available;
- include the direct external link;
- do not make video-view analytics equal course completion/mastery.

## Custom-video asset package

Each custom video should ship with:

- `.mp4` 16:9 1080p;
- `.vtt` captions (and optionally `.srt` for editing);
- transcript `.html`, `.md`, or `.txt`;
- poster/thumbnail image;
- source/production note identifying which visuals came from approved course illustrations;
- alt/accessibility text for any meaningful still graphic reproduced outside the video.

## Suggested file naming

`L14-indian-act-system-explainer.mp4`  
`L14-indian-act-system-explainer.vtt`  
`L14-indian-act-system-transcript.html`  
`L14-indian-act-system-poster.png`

For external videos, store metadata in the lesson source manifest rather than downloading/rehosting unless rights explicitly allow that.
