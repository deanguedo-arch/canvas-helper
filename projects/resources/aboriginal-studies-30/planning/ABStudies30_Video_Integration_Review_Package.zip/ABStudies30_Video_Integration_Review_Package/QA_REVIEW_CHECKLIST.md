# QA Review Checklist

Use this before approving each video component.

## Instructional fit

- [ ] Video has one clearly stated instructional job: VOICE, EVIDENCE, or TEACH.
- [ ] It adds value beyond the existing reading/interactivity.
- [ ] Runtime/excerpt is proportionate to the learning value.
- [ ] Placement occurs where students have enough context to understand it.
- [ ] A focused watch-for prompt appears before playback.
- [ ] A meaningful retrieval/interpretation task appears immediately after playback.

## Accuracy and source quality

- [ ] Creator/organization and date are identified.
- [ ] Claims needed for the lesson have been checked against course-approved sources/current authoritative sources as appropriate.
- [ ] Lived-experience material centers Indigenous voice rather than synthetic substitution.
- [ ] The clip does not flatten different Nations/peoples/contexts into one generic account.
- [ ] Historical/archival footage has visible context.

## Accessibility and resilience

- [ ] Captions are present and usable.
- [ ] Transcript or accessible equivalent is available.
- [ ] Direct-link fallback is present.
- [ ] Lesson still teaches the core concept if the external player is unavailable.
- [ ] No autoplay.
- [ ] Keyboard/focus behavior for the player/component has been tested.

## Learner experience

- [ ] Video does not duplicate the surrounding paragraph line-for-line.
- [ ] No unnecessary intro/outro consumes learner time.
- [ ] The page does not contain too many media interruptions.
- [ ] Video is visually integrated with the existing course style.
- [ ] The next block explicitly reconnects the clip to the lesson.

## Assessment boundary

- [ ] Viewing/completion is not treated as mastery by itself.
- [ ] Any scored question measures understanding, not whether the student clicked play.
- [ ] Required assessment information exists in accessible course content, not only inside a third-party video.

## External-link maintenance

- [ ] URL works.
- [ ] Embed works in Brightspace/student view.
- [ ] Source is not age-restricted or blocked in the school environment.
- [ ] Last-checked date is recorded.
- [ ] A maintenance owner/process is defined for future link checks.
