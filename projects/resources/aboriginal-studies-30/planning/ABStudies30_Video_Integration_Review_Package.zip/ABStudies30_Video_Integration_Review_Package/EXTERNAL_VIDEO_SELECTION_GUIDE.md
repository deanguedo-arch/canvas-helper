# External Video Selection Guide

## Source hierarchy

For course-critical external clips, prefer sources in this order when the fit is good:

1. **First-party Indigenous sources** — Nation, Indigenous government, Inuit/Métis/First Nations organization, Friendship Centre, Indigenous school/language program, Indigenous broadcaster or creator.
2. **Primary/official institutional sources** — United Nations, government/archive, court/museum/archive material where the institution itself is the subject or the footage is primary evidence.
3. **High-quality educational/documentary sources** — reputable broadcaster, university, museum, recognized educational organization.
4. **General creator/explainer** — use only if it clearly adds value and is factually reviewable; this should rarely be the first choice for sensitive lived-experience topics.

## Required screening before approval

For every external video record:

- exact title;
- creator/channel/organization;
- direct URL;
- publication/upload date;
- runtime and exact excerpt range if not using the whole video;
- caption availability and quality;
- transcript availability;
- learner suitability;
- the specific lesson outcome/concept it supports;
- whether the source is VOICE, EVIDENCE, or TEACH;
- date last link-checked;
- fallback text summary/transcript location;
- licensing/embedding notes if relevant.

## Reject the source if

- it relies on graphic suffering to create impact when the same learning can be achieved without it;
- it presents Indigenous peoples as one undifferentiated group;
- it speaks over communities on a lived-experience issue when a first-party source is readily available;
- the clip is mostly opinion but the lesson needs factual/primary evidence;
- captions are unusable and no accessible equivalent can be provided;
- the core learning would disappear if the video were removed;
- the creator/date/context cannot be identified;
- it is so long that students are being asked to watch material unrelated to the lesson target;
- an embed has advertising, age restrictions, or other access barriers that make it unreliable for students.

## Excerpts are preferred

A 4-minute relevant excerpt from a 30-minute documentary is usually better than assigning the full documentary inside a lesson. If excerpt embedding is not technically stable, provide the timestamp range directly above the player/link.

## Source labels in the course

Use a consistent small metadata line beneath the player:

**Source:** Creator/organization · Year · Runtime/excerpt · Captions available · Open externally

For archival material, add one sentence explaining when/where the clip was recorded and why students are seeing it.
