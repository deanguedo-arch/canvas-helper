# Review Brief — Video Layer for AB Studies 30

## 1. Purpose

The goal is not to make the course “more multimedia.” The goal is to use video where it improves learning in a way the existing text, images, and interactions cannot do as efficiently.

A strong video addition must do at least one of the following:

- give students an **authentic Indigenous voice**;
- provide **evidence or context** through archival, documentary, organizational, or official material;
- teach a **complex structure or process** more clearly through a short custom visual explanation.

If a video simply repeats the paragraph immediately above it, it should not be added.

## 2. Course-level recommendation

### Theme 1 — Aboriginal Rights & Self-Government
Recommended emphasis: conceptual explainers plus selected authentic/archival voices.

High-value video moments: oral tradition; Dene Declaration/nationhood; rights distinctions; treaty relationship; Alberta treaty perspectives; Indian Act system; constitutional negotiations; rebuilding/comparing self-government.

### Theme 2 — Aboriginal Land Claims
Recommended emphasis: process animation plus first-party case-study voices.

High-value video moments: Nisga'a; claims process; paths to resolution; Métis/non-status perspectives; Nunavut.

### Theme 3 — Aboriginal Peoples in Canadian Society
Recommended emphasis: authentic Indigenous voices and Indigenous-controlled media. Use custom video sparingly.

High-value video moments: representation lens; media stereotypes; community life; Indigenous media; Friendship Centres; community-controlled services.

### Theme 4 — Aboriginal World Issues
Recommended emphasis: short conceptual bridges plus authentic international/official sources.

High-value video moments: global diversity; colonialism across contexts; resources/conflict; UNDRIP; education/language; youth response.

## 3. Non-negotiables

1. **The lesson remains complete without the external video.** Key facts, instructions, assessment information, and required learning cannot exist only inside a YouTube/Vimeo embed.
2. **External video is never filler.** Every embed has a named instructional job.
3. **Lived experience gets authentic voice.** Do not use synthetic presenters to tell students what Indigenous people experience when a credible Indigenous source can speak directly.
4. **Custom video teaches structure.** Use custom animation for processes, comparisons, timelines, distinctions, and conceptual models.
5. **No video without a watch-for prompt and a post-watch action.** Students need a reason to watch.
6. **Captions/transcript required.** If a usable transcript/caption route is unavailable, reject the video or provide an equivalent course-side transcript/summary where legally appropriate.
7. **Do not turn video completion into mastery evidence.** Watching is exposure. Mastery comes from independent student performance in the course assessments/practice.
8. **No autoplay.** Student controls playback.
9. **Avoid long lecture video.** Default target is 2–4 minutes for custom explainers and a 3–7 minute excerpt for external sources.
10. **Context matters.** Every archival or older clip gets a visible date/source label and 1–2 sentence context note.

## 4. Recommended learner pattern

Every core video should appear in this order:

**A. Concept setup** — 1–3 short paragraphs or the existing lesson explanation.

**B. Watch for** — one focused question students should be able to answer after watching.

**C. Video** — embedded player with title, creator/source, date if relevant, runtime, captions status, and direct-link fallback.

**D. Quick check** — one meaningful retrieval/interpretation task, not “Did you watch it?”

**E. Continue learning** — return to the lesson rather than ending the page at the video.

## 5. Approval test for every proposed video

A reviewer should be able to answer YES to all of these:

- Does this add something the current lesson does not already communicate efficiently?
- Is the creator/source appropriate for the kind of claim being made?
- If the content concerns lived experience or cultural perspective, is Indigenous voice centered?
- Is the clip short enough to justify its place?
- Can a student with captions/transcript access the same learning?
- Is the external link non-essential to course survival?
- Does the pre-watch prompt direct attention to the intended outcome?
- Does the post-watch task require thinking about the content?
- Is the material suitable for Alberta high-school learners?
- Does it avoid flattening different Nations, peoples, and contexts into one generic Indigenous story?

## 6. What not to do

- Do not add one video to every lesson just for consistency.
- Do not use 10–20 minute talking-head videos where a 90-second diagram would teach the structure better.
- Do not use AI-generated people to simulate Elders, survivors, community members, leaders, youth, or historical figures.
- Do not rely on an external creator to teach material that students will be assessed on unless the same concept is also taught in-course.
- Do not treat the number of videos watched as evidence of mastery.
- Do not use a clip because it is emotionally powerful if it does not advance the lesson outcome.
