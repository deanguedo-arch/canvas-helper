# Custom Video Briefs

These are **instructional explainers**, not synthetic substitutes for Indigenous testimony or lived experience. Default production target: 16:9, 1080p, 2–4 minutes, captions + transcript, restrained motion, and course-consistent editorial illustrations.

## L03 — making rights distinctions

**Format:** CUSTOM — TEACH  
**Target runtime:** 2–3 min  
**Instructional job:** Making rights distinctions without collapsing different legal/political categories  
**Placement:** Immediately after the lesson introduces the categories

**Opening watch-for:** Watch for what is shared across the categories and what must remain distinct.

**Required post-watch action:** Sort three short examples into the appropriate category and explain one choice.

**Storyboard spine:** show three overlapping categories; define the comparison dimension; use short examples; end by warning that overlap does not erase legal/political distinctions.

**Review caution:** Use the existing overlapping-circles illustration as a visual anchor.

## L05 — early treaties among nations

**Format:** CUSTOM — TEACH  
**Target runtime:** 2.5–3.5 min  
**Instructional job:** Treaty as relationship, promises, obligations, and ongoing interpretation  
**Placement:** After the first treaty example and before detailed reading

**Opening watch-for:** What changes when a treaty is understood as an ongoing relationship rather than a finished historical document?

**Required post-watch action:** Complete a 3-part relationship map: parties, promises, continuing obligations.

**Storyboard spine:** parties → promises/understandings → ongoing relationship → later interpretation/disagreement → why treaty remains contemporary.

**Review caution:** Avoid presenting one interpretation as uncontested; keep the distinction between documented terms and differing understandings.

## L14 — the Indian Act machinery

**Format:** CUSTOM — TEACH  
**Target runtime:** 3–4 min  
**Instructional job:** How the Indian Act system structured federal control and administration  
**Placement:** After the lesson’s basic definition, before consequences/examples

**Opening watch-for:** Watch for the difference between one law and the larger administrative system built around it.

**Required post-watch action:** Rebuild the system diagram from four shuffled components.

**Storyboard spine:** federal authority → statute → administrative mechanisms → areas of control → amendment/change over time. Use the existing gears visual as a metaphor, not as literal evidence.

**Review caution:** Use the brass gears/mechanisms visual. No simulated historical persons.

## L21 — rebuilding self-government

**Format:** CUSTOM — TEACH  
**Target runtime:** 3–4 min  
**Instructional job:** What self-government can mean in practice  
**Placement:** At the start of the rebuild/self-government section

**Opening watch-for:** Which decisions can move closer to the community under different self-government arrangements?

**Required post-watch action:** Classify examples as governance, service delivery, land/resource decision, or other authority.

**Storyboard spine:** show multiple governance arrangements using the same comparison dimensions. Avoid ranking or presenting one universal pathway.

**Review caution:** Make clear that self-government models vary; do not imply one universal model.

## L22 — comparing models

**Format:** CUSTOM — TEACH  
**Target runtime:** 2.5–3.5 min  
**Instructional job:** Comparing governance models without ranking them  
**Placement:** Before the main comparison activity

**Opening watch-for:** What dimensions can we compare without deciding that one model is automatically “best”?

**Required post-watch action:** Complete a comparison grid using authority, scope, accountability, and relationship to other governments.

**Storyboard spine:** show multiple governance arrangements using the same comparison dimensions. Avoid ranking or presenting one universal pathway.

**Review caution:** Use the three-bridges illustration as the recurring visual metaphor.

## L27 — the claims machine

**Format:** CUSTOM — TEACH  
**Target runtime:** 3–4 min  
**Instructional job:** How a land claim moves through research, review, negotiation, and settlement  
**Placement:** Immediately after the lesson names the claims process

**Opening watch-for:** Which steps establish evidence, and which steps are about negotiating a remedy?

**Required post-watch action:** Put five claim-process stages in order and identify where negotiation begins.

**Storyboard spine:** claim identified → evidence/research → submission/review → negotiation/decision route → settlement/implementation. Clearly distinguish process stages from outcomes.

**Review caution:** Use filing-cabinet/claims-machine visual language, but keep the process accurate and non-cartoonish.

## L29 — paths to resolution

**Format:** CUSTOM — TEACH  
**Target runtime:** 2.5–3.5 min  
**Instructional job:** Different paths to resolution and why claims do not all follow one route  
**Placement:** Before students compare resolution pathways

**Opening watch-for:** What determines why one dispute takes a different route from another?

**Required post-watch action:** Match three hypothetical disputes to plausible resolution pathways and justify.

**Storyboard spine:** one dispute, multiple possible routes; identify what changes the route; show why resolution is not one standardized pipeline.

**Review caution:** Focus on process distinctions, not legal advice.

## L34 — mirrors and walls

**Format:** CUSTOM — TEACH  
**Target runtime:** 2–3 min  
**Instructional job:** Representation: who is shown, who speaks, and what patterns repeat  
**Placement:** Near the start of Theme 3 after the first examples

**Opening watch-for:** Representation is not only “being visible.” What else should we examine?

**Required post-watch action:** Analyze one neutral media example using voice, framing, repetition, and omission.

**Storyboard spine:** visibility → who speaks → framing → repetition → omission → why representation affects understanding. Use neutral/abstract media examples.

**Review caution:** Use abstract/media visuals; do not fabricate stereotypes for shock value.

## L43 — services that fit

**Format:** CUSTOM — TEACH  
**Target runtime:** 2.5–3.5 min  
**Instructional job:** Why who designs and governs a service can change how well it fits  
**Placement:** After L42 devolution concept and early in L43

**Opening watch-for:** What is the difference between a service delivered to a community and one designed/governed by it?

**Required post-watch action:** Compare two service models using control, fit, accountability, and access.

**Storyboard spine:** service designed elsewhere/delivered to community versus service designed/governed with community authority; compare control, cultural fit, access, and accountability without promising outcomes not supported by sources.

**Review caution:** Do not make outcome claims not supported by the course sources.

## L44 — one world, many peoples

**Format:** CUSTOM — TEACH  
**Target runtime:** 2–3 min  
**Instructional job:** One world, many Indigenous peoples: diversity without collapsing distinct peoples into one story  
**Placement:** Theme 4 opening, after the visual hook

**Opening watch-for:** If Indigenous peoples are highly diverse, why might some issues still recur across countries?

**Required post-watch action:** Identify one shared pressure and one reason experiences still differ by place.

**Storyboard spine:** four different environments/peoples → explicit diversity statement → recurring pressures can appear across places → local history and institutions change the experience.

**Review caution:** Use the four-landscapes illustration; explicitly reject a single pan-Indigenous story.

## L46 — colonial wounds

**Format:** CUSTOM — TEACH  
**Target runtime:** 3–4 min  
**Instructional job:** Colonialism across contexts: recurring mechanisms, different histories and consequences  
**Placement:** After the lesson introduces more than one national context

**Opening watch-for:** Watch for what repeats across contexts and what must not be treated as identical.

**Required post-watch action:** Complete a two-column comparison: recurring mechanism / context-specific difference.

**Storyboard spine:** recurring colonial mechanisms → different national/local histories → different present-day effects. Do not present Australia, Canada, or other contexts as interchangeable.

**Review caution:** Use landscape/object imagery only; no simulated suffering or historical reenactment.

## L48 — the UN, pressure not law

**Format:** HYBRID — EXTERNAL + CUSTOM MICRO  
**Target runtime:** 1–1.5 min custom + 3–6 min external  
**Instructional job:** UNDRIP: international standard and influence versus direct domestic lawmaking  
**Placement:** Custom 60–90 sec setup → official/credible explainer → immediate check

**Opening watch-for:** What can an international declaration influence, and what can it not directly do by itself?

**Required post-watch action:** Sort statements into “international standard/influence” versus “domestic implementation/action.”

**Storyboard spine for custom micro-video:** international declaration/standard → influence/interpretation/implementation → domestic governments and legal systems act → UNDRIP itself is not a button that directly rewrites domestic law. Keep jurisdiction-specific claims sourced and modest.

**Review caution:** This lesson title already signals the key distinction; keep the explanation precise.
