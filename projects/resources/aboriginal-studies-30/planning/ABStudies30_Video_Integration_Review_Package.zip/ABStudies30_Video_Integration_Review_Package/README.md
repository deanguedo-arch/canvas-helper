# AB Studies 30 — Video Integration Review Package

This package proposes a **reviewable video layer** for the existing 50-lesson course. It is not a request to add a video to every lesson.

## Core decision

Use video only when it performs one of three jobs:

1. **VOICE** — Indigenous people, communities, organizations, or creators speak for themselves.
2. **EVIDENCE** — archival footage, documentary material, an organization/program, or a primary/official source adds evidence students cannot get from a generic narration.
3. **TEACH** — a short custom explainer makes a difficult system, process, comparison, or legal/political distinction easier to understand.

The current proposal selects **26 video moments across 50 lessons**. The remaining lessons are intentionally video-free so the course does not become a playlist.

## Files

- `REVIEW_BRIEF.md` — rationale, non-negotiables, approval questions, and recommended volume by theme.
- `L01-L50_VIDEO_INTEGRATION_MAP.csv` — complete 50-lesson map, including intentional NO-video decisions.
- `CUSTOM_VIDEO_BRIEFS.md` — briefs for every proposed custom explainer.
- `EXTERNAL_VIDEO_SELECTION_GUIDE.md` — source hierarchy, screening criteria, rights/accessibility requirements, and rejection rules.
- `BRIGHTSPACE_IMPLEMENTATION_PATTERN.md` — exact learner-facing pattern for embedding videos without making the course dependent on them.
- `QA_REVIEW_CHECKLIST.md` — reviewer checklist before a video is approved.
- `CODEX_IMPLEMENTATION_BRIEF.md` — implementation instructions after the review package is approved.

## Important boundary

This package does **not** claim that every suggested external source has already been selected, licensed, caption-checked, or link-verified. External entries describe the required source type and instructional job. Final URLs should be selected and reviewed in a separate sourcing pass.

## Source baseline

Lesson titles/theme sequence are taken from the supplied `image-prompts-all-themes.md`. The image brief also establishes a restrained editorial illustration system; custom videos should reuse that visual language where it helps continuity.
