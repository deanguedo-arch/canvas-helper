# Sports Psychology Phase 1 — release audit and developer handoff

**Audit date:** 17 September 2026  
**Input:** `sportswellness-phase-1(2).html`  
**Audience:** Alberta Grade 10 CTS students, independent/online study  
**Decision:** Do not release this uploaded edition as a finished independent learning package. Preserve the core lesson explanations and visual theme; repair the work flow and simplify the required learning path.

## Scope and limits

The complete HTML was read and its DOM, controls, relative dependencies and JavaScript were inspected. The HTML was rendered and exercised in isolated Chromium at widths of 1366, 1024, 768, 390 and 320 pixels. This environment did not permit direct file/localhost browser navigation, so the tests loaded the original HTML in memory and supplied an isolated test storage object. Saved-state reconstruction tests are not evidence that real localStorage will persist in Brightspace or on school devices. A real learner-account deployment test is still required.

No companion asset folder was supplied. The nine instructional images, school logo, two local PDFs and simulator document could not be inspected. Screenshots intentionally show the uploaded edition without replacement assets. They must not be mistaken for screenshots of the hosted course.

External publisher pages and selected transcripts were checked for the conversational audit. Not all videos were watched end-to-end, and playback, captions and school-network access are not certified. The official REC1050 overview was indexed in search, but direct retrieval of its full detailed outcomes was blocked. This is not a complete course-credit alignment certification.

The original HTML was not changed.

## Observed inventory

- 12 numbered lesson topics, plus guide, checkpoint, simulator, untimed practice, My Work and resources routes.
- 28 capstone fields across five steps; five rubric categories.
- 10 written review questions, each with a first explanation and revision field.
- 15 in-lesson knowledge checks.
- 74 text areas total, including optional reflections and tools. This is NOT a count of 74 required answers.
- 33 supplemental resource placements, representing 24 distinct resource IDs.
- 13 relative companion-file dependencies; none supplied with this upload.
- No dangling internal hash-link targets found in the static HTML.
- No uncaught JavaScript errors during the completed isolated test sequence.
- No document-level horizontal overflow in the 25 tested topic/viewport combinations. This is not a complete accessibility or device certification, and missing images affect final layout.

## Release blockers

### P0-01 — Supply and verify the complete package

All relative asset references are listed in `inventory.json`. Preserve the expected relative folder structure when importing to the actual LMS. A complete hosted edition may already have these assets; this finding describes the upload only.

**Acceptance:** All nine instructional figures and the logo load and enlarge; both PDFs open; the simulator works. Verify in an actual student account, not only a local author preview. Check labels at typical laptop and phone sizes.

### P0-02 — My Work does not refresh on normal navigation

**Reproduction:** Enter an opening response, wait for its save status, open My Tools and click My Work. The active route changes, but `#process-summary` remains empty. Reconstructing the page with the saved state and the My Work hash renders the response.

**Evidence:** `browser-results.json`, `02-my-work-via-nav.png`, `03-my-work-after-reload.png`.

**Code locations:** `navigate()` in the inline main script; `handleRoute()` and `processCollection()` in the inline preview script. Ordinary navigation uses `history.pushState`, while preview-route side effects listen to `hashchange` and `popstate`. The side effects are not invoked by that normal navigation path.

**Recommended fix:** Centralize route activation and invoke side effects after every route transition, including internal links, restored state, browser back/forward and programmatic navigation. Prefer an explicit route-change hook/event over artificially firing unrelated browser events.

**Acceptance:** My Work displays a just-saved response immediately on first visit, and updates immediately after editing and returning. No reload or browser back/forward workaround is needed.

### P0-03 — Saving and recovery promises exceed the visible controls

The page uses browser-only storage and explicitly contains no SCORM/network saving or grade submission. Backup and restore handlers refer to `#backup-save` and `#backup-load`, but neither control exists in the markup. The only visible My Work export opens a print window. A printed PDF is a readable record, not an interactive restore file.

**Recommended fix:** Choose and describe the actual delivery model. Either implement tested LMS-managed persistence, or expose working backup/restore controls alongside PDF export and explain browser/device limitations. Do not describe an inaccessible backup route as available. Preserve current work on failed imports. Consider shared-device isolation and safe reset controls.

**Acceptance:** A learner can recover work after the supported device/browser change, or the course explicitly provides a supported alternative workflow. Test actual school browser settings, denied storage and blocked print popups.

### P0-04 — Checkpoint reset can disagree with the answers visible on screen

**Reproduction:** Select an answer; reconstruct/reload with the saved selection; choose Start a new attempt. The old radio remains visually checked, but `state.checkpoint.selections` is empty. Submitting counts that visible selection as unanswered.

**Code locations:** Preview initialization restores radios with `setAttribute('checked', '')`; the new-attempt handler clears state and calls `form.reset()`. The checked default survives reset.

**Recommended fix:** Explicitly clear checked/defaultChecked state and synchronize DOM and assessment state. Restore using a consistent state-to-view function. Do not let display and scoring maintain competing truths.

**Acceptance:** Starting a new attempt after a reload visibly clears every choice; submitted answers exactly match visible choices. Repeat across multiple attempts and reloads.

## Other required fixes

### P1-01 — Define completion consistently

The top percentage counts only self-marked topic review boxes. The guide asks for one completed checkpoint attempt; the checkpoint uses a 70% practice threshold and currently saves a zero-answer attempt as 0/10.

Separate page review, required work, practice readiness and submission. Retain a transparent formative role for the quiz; do not silently turn a local client-side quiz into a secure LMS assessment. Require a deliberate response to each item before accepting an attempt, or make incomplete submission explicit and exclude it from finished-work status. Add a direct link from the last lesson to the checkpoint and then to the submission checklist.

### P1-02 — My Work omits evidence from supported practice routes

`processCollection()` shows notes, `state.drafts`, aggregate review counts, checkpoint summary and a generic invitation to complete the original game reflection. It does not display the guided-lab attempt history or `untimedPractice.reflection`, even though the export can include those records.

Render all supported evidence types with useful return links. A learner who chooses the guided or untimed option should not be told that the original simulator remains mandatory. Show missing REQUIRED items separately from optional unattempted activities.

### P1-03 — Untimed practice is not yet equivalent

The guided lab has three states: under-activated, over-activated and ready. The untimed route contains only one tense/rushed scenario. Its feedback depends on the selected option, not the quality of the written explanation.

Give every accessible route equivalent concept coverage and evidence expectations. Include up-regulation, down-regulation and maintenance, an explanation linking signs to the choice, and a limitation/transfer reflection. Be explicit that automated feedback checks the selected move, not whether the prose is accurate.

### P1-04 — Review media route lifecycle

The preview video host is cleared in `handleRoute()`, which is affected by the same route-side-effect issue as My Work. The main `stopVideos()` clears `.player-slot`, not the separate resource-library host. Verify that navigating away stops all playback after the route fix. Actual external playback was not tested here.

### P1-05 — Storage failure is announced inconsistently

With the test storage object configured to throw, field status correctly warns that work is session-only. Save and Exit also shows a visible warning, but the live status announcement still says the work was saved in the browser.

Use the same save result for all visible and assistive-technology messages. The fixed footer must not continue to imply durable storage when it is unavailable.

## Instructional corrections

### Keep the effective teaching

Preserve the concrete hockey/volleyball/basketball examples, distinctions among stressor/appraisal/arousal/anxiety, the caution that bodily signs alone do not prove anxiety, individualized/task-specific regulation, control-based reframing, and the first-answer/snapshot/revision sequence. Keep fictional-case options and the distinction between mental-skill learning and disclosing private information. Do not remove the safety boundaries to shorten the page.

### Align assignment language with the lessons

- `p1_breath_detail`: do not require every learner to use breathing or copy a prescribed 4-in/6-out count. Ask for a safe, appropriate routine consistent with the lesson and chosen case.
- `p1_active_plan`: remove the unexplained suggestion of “sharper breathing.”
- Replace “jam scenario,” “manual override,” “over the edge,” and “composed and dangerous” with clear task-based wording.
- Use “your chosen performer” consistently in prompts and rubric. The rubric's “student's actual profile” conflicts with the valid fictional-case route.
- Avoid labelling a single described activation profile as a measured IZOF. Maintain the earlier distinction between state anxiety and activation.
- Remove student-facing editorial references to the original/source key, adaptations, supplied slides and retained prompts. Keep provenance in developer documentation, not within the explanation of a concept.

### Fix checkpoint question 3

The golfer item lists physical signs and keys somatic state anxiety without explicitly establishing that the performer experiences anxiety. Add the performer's report of nervousness; then ask which component is described. Do not teach students to infer anxiety solely from the signs after teaching the opposite in Topic 2.

### Reduce duplicate writing rather than reduce intellectual demand

Keep the five assessment categories but consolidate overlapping situation/trigger/stressor, signal/warning and summary prompts. Build the final plan from work completed during the lessons, allowing revision. Approximately 10–12 carefully chosen responses is a possible design target, not a curriculum mandate.

Use plausible distractors and a new transfer case to check understanding. An option containing “always,” “guarantees winning,” or “practice becomes unnecessary” often gives away the answer. Do not replace all formative practice with a high-stakes gate.

## Media selection decisions

Image pixels were unavailable. Based on intended purpose, retain the pressure comparison, stress process, attention field, goal hierarchy and toolkit. Review the four-model figure for readable labels and distinct axes; consider separate model views with the comparison as a final synthesis. Treat every graph as a schematic rather than a personal measurement. Add a specific interpretive question to core diagrams rather than adding stock athlete photographs.

For videos, favor a small number of directly matched explanations/demonstrations. Retain clear task focus and local written alternatives. Consolidate the legacy four-video picker with the newer topic library after auditing exact video identity, duration, segment, captions and school playback. Publisher-page access is not proof of playable embedded media.

Move adult-facing interviews, the commercial-pilot article and source readings that need extensive caveats out of the default help route. The Kevin Chapman transcript contains a claim implying athletes should be nervous, which needs careful handling alongside this course's more nuanced lesson. A reputable publisher does not guarantee that the whole resource is the right instructional match.

## Usability and release test

Preserve the dark navigation/white lesson layout, readable body type, visible focus styles, next-topic links and optional support disclosure. Reduce repeated procedural text and restore a small within-topic jump to the required activity. Add estimated work sessions only after measuring actual learner completion time.

Before general release, observe a small, varied student pilot. Each learner should be able to start without directions, locate required work, explain a novel case, choose a suitable regulation response, revise an answer, leave and resume, find all saved evidence, and submit through the actual school workflow. Test with keyboard-only input, phone/tablet and a school laptop; confirm image legibility, media alternatives and recovery paths. Ask learners what they think “100%,” “saved” and “submitted” mean. Their answers should match the system's actual behavior.
