/**
 * SWFCache v1.1: Flash Player cache control
 *
 * SWFCache is (c) 2007 Chris Your and is released under the MIT License:
 * http://www.opensource.org/licenses/mit-license.php
 *
 */
if(typeof ign == "undefined") var ign = new Object();
ign.SWFCache = function(swf, mode, c) {
	this.swf = new String();
	this.cache = new String();
	if (mode == 'development'){
		// # Create TimeStamp Cache
		var d = new Date();
		var c = d.getTime();
		this.setSwf(swf + "?swfcache=" + c);
		this.setCache(c);
	} else if (mode == 'production' && c != null){
		// # Production, Defined Cache
		this.setSwf(swf + "?swfcache=" + c);
		this.setCache(c);
	} else {
		// # Production, No Cache
		this.setSwf(swf);
		this.setCache('');
	}
}
ign.SWFCache.prototype = {
	setSwf: function(swf) {
		this.swf = swf;
	},
	setCache: function(cache) {
		this.cache = cache;	
	},
	getCache: function() {
		return this.cache;
	}
}
var SWFCache = ign.SWFCache;