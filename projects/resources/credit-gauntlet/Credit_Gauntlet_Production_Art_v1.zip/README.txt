Credit Gauntlet Production Art v1

Contains the 40 mandatory production assets from the supplied handoff manifest.
- 2 opaque backgrounds
- 3 transparent panels
- 8 transparent button-state assets
- 3 tabs
- 3 slider pieces
- 3 empty badges
- 18 transparent icons

All financial text, values, dates, labels, graph geometry, and button labels are intentionally omitted for deterministic runtime overlay.
Exact requested canvas sizes are used. Transparent production assets are true RGBA files with alpha-0 outer backgrounds.
_CONTACT_SHEET.png and _BACKGROUNDS_PREVIEW.png are review-only previews, not runtime assets.
