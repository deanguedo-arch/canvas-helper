# Specimen review notes

This example is proposed teaching, not a repaired production route. It preserves the original Plan A prices ($20 for three months, $38 for nine months, $15 device for twelve months), Plan B price ($43 for twelve months), and 4 GB use. It adds explicitly invented circumstances: Maya, a working compatible phone, 10/8 GB allowances, coverage suitable for the case and a $50 listed-charge limit. Those additions were not extracted from FINLIT or the old case.

The independent Lina case adds complete fictional prices ($4 then $8 over six months each), a free alternative, a $9 listed-charge budget and offline-access need. The intended arithmetic is $72 versus $0; the reasoning must account for the feature difference and eligibility/terms uncertainty. This note is teacher-only.

The FINLIT original PDF is the uploaded assignment, not a generated replacement. The thirteen-second MP4/VTT are the currently supplied excerpt. The original assignment contains captured website controls; the sample explicitly warns that these do not submit work. The accessible task description is an authored paraphrase.

The native PDF object, separate-tab link and image/text fallbacks are implemented; actual native-PDF/media behavior must be verified in the target browser. The single-file copy embeds the actual bytes for distribution. Its note box intentionally does not save or submit, and it never touches production storage.

Do not substitute this review specimen for a complete course repair or a student-tested lesson. Adopt its instructional moves after teacher review, retaining the existing application and saved-work migration requirements.
