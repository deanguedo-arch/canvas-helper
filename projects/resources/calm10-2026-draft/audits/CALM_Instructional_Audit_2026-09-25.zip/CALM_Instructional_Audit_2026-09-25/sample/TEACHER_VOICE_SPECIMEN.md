# FL1-05 · What will this phone plan actually cost?

## Start with Maya’s decision

Maya needs a phone for messages from work, school communication and getting home. Her current phone works. She does not need to replace it just to use either of the two plans below.

She sees an advertisement that says **“$20 a month.”** Another plan costs **$43 a month**. At first, the $20 plan looks much cheaper.

But before we choose, we need to answer two different questions: **What will Maya pay over the year? And can she manage the payment each month?** A low number in an advertisement might answer neither question.

By the end of this lesson, you will calculate the listed twelve-month cost, explain the difference between a service payment and a device payment, and identify a missing term that could change the decision. Use the classroom records below; you do not need your own phone bill.

## Three ideas we need first

A **service payment** pays for access to calling, messaging or data. A **device payment** pays toward the phone itself. They can appear on the same bill, but they pay for different things. When an offer lists both, we include both in its stated cost.

A **promotion** is a special price that lasts for a stated time. Here, Plan A’s service price lasts three months. It does not last the whole year. Twelve months minus the three promotional months leaves **nine months** at the later price.

A **comparison period** is the same span of time used for both options. We will compare twelve months with twelve months. Comparing three promotional months with a full year of another plan would not tell us which costs less over a year.

Keep this distinction in mind: **“We do not know a fee” is different from “the fee is zero.”** The calculations below cover the listed charges only. They do not establish the complete cost of a real contract.

## Read Maya’s classroom offer cards

These people, prices and service conditions are invented for this lesson. We leave tax and unlisted charges out of the arithmetic so we can focus on the two payment schedules. Before an actual purchase, the missing terms would need to be checked.

Maya uses about **4 GB of mobile data per month**, mostly when she is away from Wi-Fi. For this classroom comparison, both services work in the places she needs them. Her current phone is compatible with Plan B. Maya has **$50 a month available for the listed phone charges**, before the omitted taxes and fees. Those limits matter when we interpret the answer.

| Detail | Plan A: service plus a new device | Plan B: use the existing phone |
|---|---|---|
| Service, months 1–3 | $20 each month | $43 each month |
| Service, months 4–12 | $38 each month | $43 each month |
| Device payment | $15 each month for all 12 months | No new device payment |
| Data included in this classroom case | 10 GB per month | 8 GB per month |
| Commitment shown | The listed payments cover 12 months | Month-to-month service |
| Missing information | Early cancellation terms, unlisted fees and tax | Unlisted fees and tax |

Notice that both data allowances are above Maya’s stated 4 GB use. A larger allowance might be valuable to a different person, but unused extra data does not automatically solve a problem Maya has.

## Watch with one question in mind

The short FINLIT excerpt asks you to think about how you use a phone and what you can spend. As you watch, identify **one need** and **one budget limit** already supplied for Maya. The clip introduces the decision; the full calculation is taught below.

<!-- FINLIT_PLAYER -->

## Work through Plan A with me

I am going to split the year into two parts because the service price changes. I am not splitting the device payment the same way: its $15 charge continues for all twelve months.

**First, the promotional service:** three months at $20 is `3 × $20 = $60`.

**Next, the remaining service:** the other nine months cost $38 each. That gives `9 × $38 = $342`.

Adding those two parts gives the service cost: `$60 + $342 = $402`.

Are we finished? Not yet. The offer also has a separate device payment. Twelve payments of $15 give `12 × $15 = $180`.

So the total of Plan A’s **listed** charges is `$402 + $180 = $582` for the twelve months.

| Part of Plan A | Calculation | Listed cost |
|---|---|---:|
| Promotional service | 3 × $20 | $60 |
| Later service | 9 × $38 | $342 |
| Device payments | 12 × $15 | $180 |
| Total | $60 + $342 + $180 | **$582** |

Here is the mistake the advertisement makes easy: `12 × $20 = $240`. The multiplication is correct, but the **setup is wrong**. It extends a three-month price across twelve months and leaves out the device payments. A correct calculation starts with a correct reading of the offer.

## Finish Plan B

Plan B uses Maya’s existing compatible phone. Its listed service price stays at $43 for all twelve months in our comparison.

Before opening the worked response, calculate `12 × $43`. Then subtract that amount from Plan A’s $582. What does the difference describe?

<!-- GUIDED_ANSWER -->

The difference is a comparison of the listed charges over twelve months. It is not a claim that Plan B will always be better for everyone or that we already know every contract term.

## Now check the monthly budget

A yearly total can hide a difficult month. Let’s look at the actual payments rather than an average.

For Plan A’s first three months, Maya pays **$20 service + $15 device = $35 per month**. After the promotion ends, that becomes **$38 + $15 = $53 per month**.

Maya’s stated $50 limit covers the first payment, but not the later $53 payment. It is $3 over her limit before we even add the omitted tax or fees. Averaging $582 across twelve months would give $48.50, but she is not billed $48.50 each month. That average would hide the nine months at $53.

Plan B’s listed payment is $43 each month. That leaves $7 of the stated $50 limit before the omitted charges. We must not treat that $7 as guaranteed spare money because we have not checked the remaining charges.

This is why we asked two questions at the start. **Total cost** tells us what the listed year costs. **Monthly affordability** tells us whether the scheduled payments fit when they arrive.

## See the finished recommendation

> For Maya’s stated twelve-month use, Plan B has $516 in listed charges, compared with $582 for Plan A. The listed difference is $66. Plan B also uses the compatible phone Maya already owns and includes enough data for her stated use. Plan A’s later listed payment is $53, which exceeds her $50 monthly limit. I would investigate Plan B first, but I would confirm taxes, additional fees and the actual service terms before treating it as affordable. If Maya’s phone stopped working, the comparison would need a new device option and a fresh calculation.

Notice the structure: a decision, figures supporting it, a reason tied to Maya’s circumstances, and information that could change the answer. You do not need to copy these sentences. You need to use this reasoning with the case you are given.

## Use the source to ask a better question

The **CRTC Wireless Code, Section C: Critical Information Summary** describes the summary a provider gives with a postpaid contract. It includes key contract information, monthly charges and one-time/additional fees. It helps a reader locate the kinds of details that our classroom cards leave incomplete. This short description is a paraphrase of the official section, checked 25 September 2026; it is not a statement of every rule on the page.

<!-- OFFICIAL_RESOURCE -->

As you read Section C, choose one field that would help answer Maya’s remaining cost question. Then complete: **“Before deciding, Maya should confirm ___ because ___.”** Do not copy an unrelated rule merely because it appears on the same page. Some amendments on the page have future effective dates; use the named section for this task.

### Connect this to the FINLIT assignment

The supplied FINLIT **Smartphones and Plans Assignment 5.3, physical page 1, Question 1** asks readers to compare phone features and costs. We have used that comparison purpose, but the prices and calculation above are our classroom case—not prices supplied by the PDF.

Open the original assignment at page 1. Find two features mentioned in Question 1. For Maya, which would require more information if her current phone stopped working? Do not complete the whole assignment or attempt to use its captured website “Submit” button; return to this lesson for the task below.

<!-- FINLIT_READER -->

## Try a different case: Lina’s music subscription

Lina wants downloaded music for a bus trip every school day. Her classroom options are:

| Detail | Paid student plan | Free plan |
|---|---|---|
| Months 1–6 | $4 per month | $0 |
| Months 7–12 | $8 per month | $0 |
| Offline downloads | Included | Not included |
| Setup charge | $0 in this classroom case | $0 |
| Other terms | Student eligibility and cancellation terms are not supplied | Requires a connection for playback |

Lina has $9 a month for the **listed** subscription charge. Her goal is offline listening; do not assume that buying more mobile data is free. Use a twelve-month comparison. Ignore tax only for this classroom arithmetic and name that omission.

Write a response that does four things: show the paid plan’s two subtotals and twelve-month total; compare the free plan’s cost and feature limitation; decide what fits Lina’s stated need and monthly limit; and name one missing condition she should check before signing up.

You now have the prices, time periods, budget and need required for that response. You are not being asked to invent a price or investigate your own subscription.

If you get stuck, return to the step you need: use the Plan A table to split the promotion; use the monthly-budget section to test affordability; use the finished recommendation to connect evidence to the decision. For the missing condition, read the final row of Lina’s table—not an unrelated Maya phone term.

<!-- INDEPENDENT_NOTES -->

## What to carry into the next lesson

Keep your cost table and the condition you would check. In the next major-purchase decision, the item may change, but the method will not: identify what is needed, use the same period, include every supplied charge, separate unknown costs, and explain what the total means for the person in the case.
