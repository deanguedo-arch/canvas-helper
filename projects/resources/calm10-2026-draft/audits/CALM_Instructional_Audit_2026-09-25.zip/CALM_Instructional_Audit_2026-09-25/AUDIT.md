# CALM 10 — instructional coherence audit
## Keep the interface. Repair the teaching between the controls.

**Reviewed:** the two 25 September 2026 CALM review archives and the newly supplied FINLIT `Archive(1).zip`. **Date:** 25 September 2026. **Deliverable:** an independent audit, all-40-lesson repair matrix, source-integration specification and one teaching specimen. **Production files changed:** none.

The course is not yet consistently able to act as the student's teacher. Its problem is not simply insufficient word count. The explanations, source records, videos, worked examples and independent tasks do not always describe the same problem. Some tasks cannot be completed from the information supplied. Other pages tell students to check, compare or explain without first performing the task in front of them.

My earlier description of a “full course” overstated the instructional conclusion that component counts could support. This audit evaluates the newer candidate itself. It does not reuse the previous test total as proof of learning quality.

## 1. What I examined

I inspected all 40 lesson articles in the canonical `workspace/index.html`, including their explanation, case, worked sequence, final task, field label and lesson source link. I read the 240 practice stems and keyed choices, inspected the shared orientation, assessment and portfolio pages, and reviewed relevant supporting JavaScript and teacher metadata. This is not a complete independent legal review of all keyed answers or a full numerical audit of every engine.

The common workspace files in the large and compact archives are byte-identical: **94 matching files, zero differing matches**. I used the large review archive for actual video files. Missing MP4s in the compact archive are therefore not reported as broken production media. The input hashes and file counts are in `source_records/input_integrity.json`.

I inventoried and text-extracted all **71 actual FINLIT PDFs, 233 physical pages**, and closely inspected selected assignments/quizzes for the source map. I viewed the first pages of the phone, deductions and compounding assignments. The collection contains **36 assignment PDFs and 35 quiz PDFs**, not a complete narrative textbook. A saved Needs/Wants web activity is also present; I did not approve or execute its third-party scripts.

I inspected metadata for all 23 embedded MP4s, selected captions/transcripts and four sampled video frames. I did not listen through and approve every clip. I rendered all 40 routes in Chromium in memory, tested a sample saved response and first/latest practice record across in-document navigation, opened the case reader, and checked all lesson routes at 390-pixel width. Actual local/HTTP navigation was blocked by the environment. These checks do not certify reload persistence, media playback in Brightspace, screen-reader access or SCORM.

## 2. The resource problem is real, but it is not “zero links”

| Independently observed in the current candidate | What that establishes—and what it does not |
|---|---|
| 69 external link instances, pointing to 47 distinct URLs | Links exist. Each lesson has one external source link, generally in a final “Check the source” section. This is not equivalent to teaching students how to use the relevant source before they need it. |
| 40 case-reader buttons | The reader works in the sampled test, but `case-reader.js` clones the lesson's own `.source-document` table. It is not a reader for original FINLIT PDFs, a live occupation profile or a government source. |
| Zero PDFs in the learner workspace; zero iframe/object/embed elements in its HTML | The supplied FINLIT PDFs are not connected to an original-document reading layer in this candidate. This does not mean the existing case-reader feature is broken. |
| 23 embedded videos: 17 FINLIT excerpts and six original demonstrations | Actual media is present. Approximately 27 minutes 32 seconds total, including about 11 minutes 54 seconds of FINLIT excerpts. Placement, transitions, caption quality and teaching contribution still require review. |
| 240 practice items | All are single-select radio questions, six per lesson. Twelve larger activities add other interaction, but the 240 count is not a count of 240 distinct instructional activity types. |

The 390-pixel reader screenshot also requires sideways scrolling to read the wide case table. A document-level “no overflow” check does not establish that all its values are immediately readable. Preserve the reader, but improve its mobile table presentation.

**Repair the relationship between resources and learning.** A student should know what to open, where to look, what to notice, how it supports the decision, and where to return. A resource library at the end does not replace that relationship.

## 3. Specific failures that can make a diligent student get stuck

These are not hypothetical concerns. Each has a route and a source locator in the evidence records and repair matrix.

### 3.1 The story changes while the student is learning

**CE1-03:** the opening and table use Leah. The FINLIT viewing instruction names Riley. The original demonstration uses Riley and a different cost comparison: $900 versus $3,200 + $1,800, while the lesson's Leah table uses $2,000 + $1,200 and $4,500 + $600. A second example can be valuable; it needs an explicit introduction and a clear boundary. Here, the instructional handoff is unclear. The automatically repeated reminder also leaves out the travel-cost row used in the calculation.

**CE1-04:** the opening uses Noor, the video uses Sam, and the final source instruction mentions Jordan. The table labelled “Two fictional pieces of labour-market evidence” has three rows. Students are told how to read graph axes without being given the graph. The lesson contains relevant cautions, but it does not give the student one continuous source-reading demonstration.

**Required repair:** give every worked case a stable record: person, goal, evidence, dates, numbers, conditions and intended product. Bind the explanation, media, worked steps and checks to that record. Deliberately changed cases get a new label and a sentence explaining what changed.

### 3.2 Independent tasks ask for unavailable information

**CO1-03:** the new interview asks about a *team disagreement*, using a supplied event record about a cancelled volunteer and task reassignment. The record does not supply the disagreement, response or result. Asking for a truthful answer while withholding its evidence pushes the learner toward invention.

**FL1-05:** the independent music-subscription question asks students to calculate from supplied terms, but neither the discount price nor regular price is supplied. The field label additionally calls for two supplied plans over twelve months and a usage-profile comparison, but still supplies no subscription prices or usage profile.

**FL1-06:** the bicycle transfer says the purchase price is supplied, but the lesson does not provide a bicycle price. The required numeric response cannot be completed as written.

**FL3-05:** the second two-goal case requires a long-term gap calculation, but does not state the longer goal's starting balance or clearly allocate the shared contribution. The field then tells the learner to create different goals.

A deliberate missing-information task is legitimate. It must ask students to identify the missing information—not require a total that depends on it. Do not repair these by silently assuming zero fees, zero starting savings or invented prices.

### 3.3 Time and money assumptions disagree

**CO1-04:** 10:05 a.m. to 11:00 a.m. is 55 minutes, not the stated 35. An unstated twenty-minute preparation buffer is not a usable case fact.

**FL1-03:** the opener says pay arrives every two weeks; the evidence table says the first and fifteenth. The teaching itself warns that these are not the same schedule. The cash-flow example needs one selected pay frequency, an opening balance and a dated sequence of deposits and costs.

**FL3-06:** prose places an $80 expense in month two of a six-month savings plan, but the worked total starts from $200 − $80 and adds six further deposits. It omits the timeline effect and any deposits already made. The table effectively uses a different restart assumption. Choose one timeline and reconcile it.

**FL2-06:** practice question q6 states that the fictional payment exceeds $230 in a stress scenario. Under the actual supplied path—$5,000, 24 months, 5% nominal compounded semi-annually for twelve months, then 7% with the payment recalculated—the new payment is approximately **$221.54**, not above $230. The initial payment is approximately $219.24 and the month-12 balance is approximately $2,561.72. Either make q6 an explicitly different fully specified scenario or correct its premise. See `developer/verify_audit_evidence.py` for the independently reproduced calculation.

These failures explain why adding polished paragraphs has not made the whole course feel coherent.

## 4. Where the teaching is still acting like an assignment sheet

### Directions are not demonstrations

“Check the current rule,” “compare the alternatives,” “make a conditional recommendation” and “write a clear report” are useful instructions. But the learner needs to see those actions performed with the actual evidence.

For example, CO2-01 gives a fifteen-year-old retail worker and a late shift. Its worked response largely stops at checking a rule. The teaching should display the relevant rule, point to the worker's age and industry, split the shift into applicable time intervals, and write the resulting conclusion. Alberta's current page distinguishes supervised work from 9 p.m. to midnight and prohibited work from 12:01 a.m. to 6 a.m. for that retail age group; it also identifies scope exceptions. That is the source-backed reasoning the model needs—not an unsupported general slogan. [W1]

A good student-facing model would begin: “First, find the age category. Our worker is fifteen, so we are not using the thirteen-to-fourteen section. Next, check the industry: this is retail. Now place the start and finish times beside the rule. Notice that adult supervision does not automatically make every part of the shift acceptable.” Then it would complete the case with the actual times and source conditions.

### A table of conclusions is not always the source evidence

Several `.source-document` tables already include interpretations such as “possible controls,” “what it shows” or “possible routes.” That is useful in a completed model, but weak as independent evidence. A student cannot practise extracting a message's cue or a contract's condition when a summary table has already performed the interpretation.

Use real task-shaped documents: a complete fictional posting, a readable pay stub, a contract summary, a timetable, a message or a feedback record. Put raw evidence and the teacher's interpretation in visibly different places.

### A worked example must finish the work

Many numbered examples identify the right actions but never produce the requested final artifact. For a report, show the finished report. For a decision, show the final recommendation and the evidence supporting it. For a budget, show the revised dated balance. For an interview, show the answer the applicant would actually say.

Retain useful existing calculations. FL1-05 correctly totals the supplied phone offers at $582 and $516. FL3-05 clearly demonstrates a near-term $480 target and a longer-term $350 gap. These should be developed into fuller teaching, not thrown away.

### Generic headings and editorial caveats interrupt the teacher's voice

The repeated “Understand the evidence / Make the calculation or comparison / Use the result carefully” labels often do not name what the next paragraph teaches. The second example is sometimes presented as a changed situation when it is only the next calculation in the same problem.

The learner text also contains author-facing commentary about cropping FINLIT, source limitations and checks a teacher must perform before release. Keep a short fictional-data note and necessary safety/uncertainty qualifications. Move production decisions, permissions and unreconciled review work to developer/teacher metadata. Student prose should explain the concept directly, not narrate the rebuild.

## 5. What the Grade 10 teacher needs to provide in each lesson

This is a proposed teaching standard, not a claim that all forty lessons must have an identical number of words, questions or videos.

**Introduce the situation.** Who is involved? What are they trying to do? Why does the decision matter? What do we already know? Name the output the learner will produce.

**Teach the necessary idea before using it.** Define a term in ordinary language, give a concrete instance, contrast a common confusion, and connect it to the current case. A vocabulary popup helps recall; it cannot carry the whole explanation of an unfamiliar concept.

**Read evidence together.** Open the exact page, document field or video moment. Explain why that detail matters. Use the same record in the visible explanation, narration and worked answer.

**Perform the whole task.** Narrate the reasoning: “I am multiplying by nine because the promotion ends after three of the twelve months.” Show the calculation, interpretation and finished recommendation. Include a plausible wrong approach and explain exactly why it fails.

**Let the learner finish part of a similar task.** Supply a table with one row unfinished, a partially annotated document, a paragraph to repair or a constrained calculation. Feedback should explain the error and link to the precise step to revisit.

**Then give independent transfer.** Supply all needed facts, make one meaningful change, state the required output and show the success criteria. Do not reveal its answer in the instruction. Distinguish a supported correction from fresh evidence.

**Connect the result to the next lesson.** Tell the learner which saved artifact returns later and why. When a later lesson reuses a case, carry its facts forward or explicitly introduce a new one.

The separate **FL1-05 teacher-voice specimen** demonstrates this with the existing phone prices, a clear period-by-period explanation, a partial calculation and a complete new subscription case. It is not installed in the course and introduces clearly documented fictional facts for review.

## 6. FINLIT: use it substantively, but do not ask a worksheet to be the teacher

The latest materials are more usable than the earlier text-only source package. There are actual PDF bytes, and the course already contains seventeen FINLIT excerpts. No new asset search is necessary to start integrating those specific items.

However, the available PDFs are predominantly assignments and quizzes. The phone assignment, physical page 1, asks students to research phone features and costs. It does not supply a two-contract worked calculation. The deductions assignment asks about EI, CPP and CPP Investments; it is not a pay-stub lesson. The compounding assignment asks students to use a calculator with several contribution assumptions; it assumes teaching has already happened. The source map identifies the precise pages/questions and proposed uses.

Use the strongest selected source question or concept **after** a developed explanation and model. For a useful source passage, give an in-course reader or an accessible authored adaptation with attribution. Remove captured website profile/navigation/submit controls from adapted learner material. Do not imply a saved PDF's former “Submit” control submits work to Brightspace.

Do not import the scam quiz unchanged. Its first question asks which organizations the video says never call for personal information. The exact answer and underlying teaching require careful review; current CRA guidance explicitly allows genuine phone contact and some identity-verification questions. The current course's rejection of “CRA never calls” should be retained. [W2]

### A resource card needs six things

A title and publisher; exact page/section or clip range; why the learner is opening it; a small observation task; a working opening/reader route plus accessible fallback; and a return point to the lesson's next step.

For FL1-05, a source card should direct the learner to **CRTC Wireless Code, Section C: Critical Information Summary**, not simply the entire long page. That section describes a summary containing the key terms, monthly charges and one-time/additional fees. The teacher can explain how those fields answer the current comparison questions. This is a proposed addition supported by the current official source, not content already embedded in the course. [W3]

For original PDFs, use physical page numbers and record any different printed labels. For public websites that block framing, use a clearly scoped, permitted local adaptation plus the original-source link; do not show a blank frame or pretend an external page is embedded. Test keyboard, mobile, fallback and return focus. `case-reader.js` should remain for fictional cases; a separate resource reader should not silently redefine it.

## 7. Media and practice need closer integration, not another volume target

The FL1-05 FINLIT clip is **12.93 seconds**. It says that plans vary and that a person should consider use and spending. That can introduce a question. It cannot, by itself, demonstrate comparing promotion periods, device installments and total cost.

The CE1-06 VTT starts with a sentence fragment and ends mid-sentence. It includes “Arrows the possible opportunities,” “Ever gets tied to a specific idea” and “Employees the resources.” At least the captions require checking and correction against the original audio/visual sequence. The audit does not claim that the speaker actually said those faulty captions.

Keep usable FINLIT excerpts. Recut, replace or supplement each weak clip deliberately. Do not remove all restored media as a blanket operation. Give each clip a short before-watch question and a specific after-watch application. Full audio/caption review remains open.

The 240 practice items are not uniformly useless: many offer specific, defensible feedback. But some same-lesson pairs ask nearly the same recognition question, such as CO2-01 q1/q4 about age and conditions, and q3/q6 about using current official guidance. Repetition can support retrieval; it does not demonstrate applying the rule. Add or substitute partial performance tasks where the learner must read the evidence, calculate a value, complete a message or justify a choice. Version changed questions so earlier attempts retain their original meaning.

## 8. Shared assessment and participation gaps

The assessment page lists task titles and weights, but the actual A1–A7 prompts and case materials are in teacher-only metadata. A self-contained learner course needs the full relevant brief and success criteria, or an actual tested Brightspace assignment handoff, when students reach the end of the module. Do not publish the answer keys with those briefs.

The integrated Morgan challenge assumes an earlier budget, program and pathway but provides no single complete baseline for a learner who uses the supplied fictional route. Add a carry-forward record or a complete fallback case. The stated hours are planning allocations, not evidence that the work supports that much meaningful learning.

The current candidate calls A3 an online simulation, and teacher metadata explicitly says it does not establish authentic supervised participation. Preserve that honesty. The official exact PEW0770 KUSP text could not be retrieved in this audit; the local procedure codes and school proposal are not independent proof of the provincial requirement. Alberta's official page does confirm optional CALM 10 draft field testing in 2026/27. [W4] Full official statement reconciliation and a school decision on genuine participation remain separate release gates—not reasons to stop repairing instruction.

## 9. Repair order

**First: remove ambiguity that prevents completion.** Correct the eleven P0-marked lesson records in the matrix: missing data, conflicting task/field instructions, timeline errors and the unsupported rate-change premise. P0 means the indicated case/task needs correction before student use; it is not a numerical quality score for the whole module.

**Second: complete the teaching within the existing interface.** Work module by module, retaining connected case records. Add the finished teacher demonstration and partial student practice before revising independent work. Do not launch another layout redesign.

**Third: connect selected resources at the point of need.** Use the source map, exact pages/segments and reader/fallback requirements. Do not indiscriminately import all 71 PDFs or manufacture a replacement video for every page.

**Fourth: align assessment and progression.** Match the learner task, field label, evidence collected and teacher criteria. Expose actual student briefs without keys. Preserve old prompt versions and responses.

**Fifth: run a cold learner walkthrough.** A reviewer who has not authored the lesson should perform it using only the learner-visible material and allowed supplied sources. Log the exact point of uncertainty; repair the lesson rather than explain the missing step privately. Representative Grade 10 students should then try the repaired sequence. Automated route checks remain useful, but cannot replace this test.

## 10. What counts as finished

For each lesson, require evidence that (a) every necessary fact/term is introduced, (b) one complete worked product is visible, (c) the learner practises the actual skill with support, (d) the independent case is complete and meaningfully different, (e) all text/media/data are consistent, (f) source opening and return paths work, (g) feedback addresses the specific error, and (h) old work is preserved under its original prompt version.

Do not require a minimum word count or a video quota as a substitute. Do not count a link, a generated paragraph or a passing browser test as proof that the student has been taught.

**Conclusion:** the interface is a foundation worth retaining. The important remaining work is substantial instructional completion and consistency checking—not another cosmetic polish pass, and not an entirely new architecture.

## External verification used in this audit

These sources support only the specific current-fact checks or proposed resource integrations above. They do not substitute for the uploaded lesson evidence.

- **W1 — Alberta, Youth employment laws**, checked 25 September 2026, section “Employees aged 15 to 17”: https://www.alberta.ca/youth-employment-laws
- **W2 — CRA, Recognize a scam**, checked 25 September 2026, “Why the CRA may contact you”: https://www.canada.ca/en/revenue-agency/corporate/scams-fraud/recognize-scam.html
- **W3 — CRTC, The Wireless Code, simplified**, checked 25 September 2026, Section C. The page also displays some future-effective amendments; do not automatically treat every displayed amendment as already in force: https://crtc.gc.ca/eng/phone/mobile/codesimpl.htm
- **W4 — Alberta, Career education and financial literacy**, checked 25 September 2026, “Draft career and life management 10”: https://www.alberta.ca/curriculum-career-education-and-financial-literacy
- **W5 — ALIS, Learn What’s on Your Pay Stub**, inspected as a possible matched source for FL1-01: https://alis.alberta.ca/tools-and-resources/resources-for-people-with-low-literacy/easy-reading-work-laws-and-your-pay-stub/learn-what-s-on-your-pay-stub/
- **W6 — Bank of Canada, Inflation**, inspected as a possible matched source for FL3-04: https://www.bankofcanada.ca/core-functions/monetary-policy/inflation/

The public PEW0770 URL returned no usable curriculum text. No complete KUSP or provincial compliance certification is claimed.
