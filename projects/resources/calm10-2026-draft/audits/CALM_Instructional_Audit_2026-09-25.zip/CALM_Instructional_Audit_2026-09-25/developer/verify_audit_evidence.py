#!/usr/bin/env python3
"""Reproduce selected observations about the UNMODIFIED 25 September audit baseline.

Usage:
  python verify_audit_evidence.py --workspace /path/to/workspace --output evidence.json
Requires beautifulsoup4. These are evidence checks, NOT teaching-quality or release tests.
A corrected production candidate should not be expected to satisfy old defect assertions.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from bs4 import BeautifulSoup

BASELINE_SHA256 = 'faaf77777f2cffcf092e5f596ebdbda02ff01bb773be43cb13d04843d875652b'

def payment(principal: float, monthly_rate: float, periods: int) -> float:
    if principal < 0 or monthly_rate < 0 or periods < 1:
        raise ValueError('Invalid principal, rate or period count')
    return principal / periods if monthly_rate == 0 else principal * monthly_rate / (1 - (1 + monthly_rate) ** -periods)

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    index = args.workspace / 'index.html'
    if not index.is_file():
        parser.error(f'No index.html found: {index}')
    raw = index.read_bytes()
    soup = BeautifulSoup(raw, 'html.parser')
    lessons = {a['id']: a for a in soup.find_all('article', id=re.compile(r'^(?:ce1|co[12]|fl[1-4])-\d\d$'))}
    checks = []
    def record(name: str, condition: bool, observed: object) -> None:
        checks.append({'name': name, 'passed': bool(condition), 'observed': observed})
    digest = hashlib.sha256(raw).hexdigest()
    record('Canonical HTML identity', digest == BASELINE_SHA256, digest)
    record('Forty lesson routes', len(lessons) == 40, len(lessons))
    urls = [a['href'] for a in soup.select('a[href]') if a['href'].startswith(('https://', 'http://'))]
    record('External links exist', len(urls) == 69 and len(set(urls)) == 47, {'instances': len(urls), 'unique': len(set(urls))})
    counts = {'videos': len(soup.select('video')), 'case_readers': len(soup.select('[data-open-case-reader]')), 'external_frames': len(soup.select('iframe, object, embed')), 'local_pdfs': len(list(args.workspace.rglob('*.pdf')))}
    record('Media and reader baseline inventory', counts == {'videos':23,'case_readers':40,'external_frames':0,'local_pdfs':0}, counts)
    questions = soup.select('[data-practice-id]')
    radios = sum(len(q.select('input[type=radio]')) for q in questions)
    record('Practice uses six radio questions per route', len(questions)==240 and radios==960 and all(len(a.select('[data-practice-id]')) == 6 for a in lessons.values()), {'questions':len(questions),'radio_options':radios})
    activity_count = len(soup.select('[data-activity-id]'))
    record('Twelve larger activities', activity_count==12, activity_count)
    table = lessons['co1-04'].select_one('.source-document').get_text(' ',strip=True)
    clock = (11*60) - (10*60+5)
    record('CO1-04 clock mismatch', all(t in table for t in ('10:05','11 a.m.','Thirty-five')) and clock==55, {'source':table, 'elapsed_minutes':clock})
    opener = lessons['fl1-03'].select_one('.lesson-opening').get_text(' ',strip=True)
    table2 = lessons['fl1-03'].select_one('.source-document').get_text(' ',strip=True)
    record('FL1-03 pay-frequency mismatch', 'every two weeks' in opener.lower() and '1st and 15th' in table2, {'opening':opener,'evidence_table':table2})
    transfer = lessons['fl1-05'].select_one('.transfer-work').get_text(' ',strip=True)
    record('FL1-05 task requires totals without subscription prices', 'music' in transfer.lower() and '12-month horizon' in transfer.lower() and not re.search(r'\$\s*\d', transfer), transfer)
    a_total = 3*20 + 9*38 + 12*15
    b_total = 12*43
    record('FL1-05 existing phone arithmetic retained', (a_total,b_total,a_total-b_total)==(582,516,66), {'A':a_total,'B':b_total,'difference':a_total-b_total})
    scenario = lessons['fl2-06'].select_one('.source-document').get_text(' ',strip=True)
    record('FL2-06 supplied rate-path assumptions', all(t in scenario for t in ('$5,000','24 months','5%','7%','12 months','$230')), scenario)
    r5 = (1+.05/2)**(1/6)-1
    r7 = (1+.07/2)**(1/6)-1
    p1 = payment(5000,r5,24)
    remaining = 5000*(1+r5)**12 - p1*((1+r5)**12-1)/r5
    p2 = payment(remaining,r7,12)
    rate_result = {'first_payment':p1,'balance_after_12':remaining,'recalculated_payment':p2,'margin':230-p2, 'assumptions':'Monthly payments in arrears; stated nominal rates compounded semi-annually converted to equivalent monthly rates; unrounded intermediate amounts; no invented fees.'}
    record('FL2-06 independently reproduced repayment', math.isclose(p1,219.24209136595545,abs_tol=1e-7) and math.isclose(remaining,2561.7189881133827,abs_tol=1e-7) and math.isclose(p2,221.53918667512076,abs_tol=1e-7) and p2<230, rate_result)
    q6 = lessons['fl2-06'].select_one('[data-practice-id="fl2-06-q6"]').get_text(' ',strip=True)
    record('FL2-06 q6 asserts exceedance without another supplied path', 'exceeds the $230' in q6 and p2<230, q6)
    result = {'purpose':'Selected audit evidence reproduction, not production approval', 'workspace':str(args.workspace), 'checks_passed':sum(c['passed'] for c in checks), 'checks_total':len(checks), 'checks':checks, 'limitations':['Does not assess teaching completeness.','Does not validate original audio or every source claim.','Does not test browser reload, SCORM or Brightspace.','Defect assertions describe the original candidate, not desired repaired behaviour.']}
    text = json.dumps(result,indent=2,ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(text,encoding='utf-8')
    print(text)
    return 0 if all(c['passed'] for c in checks) else 1

if __name__ == '__main__':
    raise SystemExit(main())
