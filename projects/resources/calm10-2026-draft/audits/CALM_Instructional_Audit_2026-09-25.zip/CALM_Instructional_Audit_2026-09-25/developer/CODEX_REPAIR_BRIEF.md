# CALM 10 — targeted instructional repair specification

## Authority and scope

Implement an instructional repair of the current 25 September 2026 CALM candidate. Read `../AUDIT.md`, `../LESSON_REPAIR_MATRIX.json`, and `../RESOURCE_INTEGRATION_MAP.md` before editing. These files are an audit and proposed specification; they are not evidence that repairs have already been made.

Use the current canonical `workspace/index.html` and its actual sources, not the older 24 September full-course package. The large and compact 25 September archives share identical common workspace files; the large archive supplies the video files omitted from the compact one. Work in a new branch/candidate. Keep the uploaded archives immutable.

Preserve the existing Biology-derived interface and seven-module architecture. Preserve all 40 routes, current navigation, reader entry points, work exports and usable media. Do not solve this task with another redesign, word-count expansion, wholesale video deletion, or a new lesson-generation template that repeats directions instead of teaching.

## Non-negotiable state protection

Retain `calm10-2026-draft:learning:v3`, `calm10-2026-draft:vocabulary:v1`, legacy v1/v2 export access, and existing lesson/activity/practice/evidence identifiers. Do not silently clear, truncate or reinterpret learner work.

Stable IDs alone do not preserve meaning when a question changes. Store an explicit content/task version and preserve the old prompt/answer association. A student's earlier answer to an underspecified question must not be marked against the newly completed question as if the student had seen the new information. Retain first attempts and revisions; introduce an explicit teacher-controlled reassessment route where necessary. Any new response structure must round-trip the previous flat-field records and exports. Report capacity/migration decisions before changing limits.

Do not put teacher formal-test keys or complete marking exemplars into learner JavaScript. Learner-visible applied briefs and success criteria must be available; formal keys remain in teacher metadata/Brightspace.

## Pass 1 — fix task validity and inconsistent case facts

Implement the P0 rows in `LESSON_REPAIR_MATRIX.json` before expanding media. For each:

1. Establish a complete case record: case ID/version, fictional person, goal, time period, facts, numbers with units, constraints, deliberate unknowns, allowed assumptions, and requested output.
2. Reconcile the opener, table, figure, source mission, narration/transcript, worked response, practice, independent prompt, field label and teacher criteria against that record.
3. If information is intentionally missing, ask students to identify the unknown; do not require a numerical answer that depends on it.
4. If an independent case needs additional fictional values, label the additions in the developer change log. Do not pretend they came from FINLIT or an official source.
5. Recalculate using the stated convention. Preserve the existing semi-annual nominal-rate convention unless an explicitly reviewed change is made across teaching, tools, questions, keys and saved-work handling.

Mandatory fixtures include: CO1-04 clock arithmetic; FL1-03 pay-frequency/date consistency; FL1-05 complete subscription terms; FL1-06 bicycle price; FL3-05 two-goal allocations; FL3-06 deposits/event/deadline; FL2-06 the actual 5%→7% rate path and q6 premise. Current-source audit values are in `verify_audit_evidence.py`; those assertions verify the audit baseline, not a repaired production build.

## Pass 2 — write as the teacher, keeping the interface

Repair complete connected modules, not isolated decorative sections. For every lesson:

- Introduce the person, goal, stakes and what the student will produce. Connect to relevant prior learning.
- Teach each unfamiliar term before it is needed, with a concrete example and contrast. Popups support this explanation; they do not replace it.
- Give the exact evidence students must read. Prefer a task-shaped document over a table that has already supplied all interpretations.
- Show a complete teacher think-aloud using that evidence. Explain why each action follows. Finish the actual artifact: recommendation, calculation table, message, interview answer, report or revised plan.
- Give a partially completed similar task and feedback specific to the learner's likely mistake. Move gradually from support to independent performance.
- Supply one complete, genuinely changed independent case. Match the task paragraph, field labels and criteria exactly. Allow more than one defensible answer where the information warrants it.
- State what is saved and how it is used later. A draft/attempt is not a mastery or submission state.

Do not use a rigid minimum word count or “one video per lesson” requirement. Do not pad with generic cautions or duplicate multiple-choice questions. Keep necessary fictional-data, privacy and legal uncertainty notes brief and clear. Move authoring instructions such as “before release, a teacher must verify…” and accounts of media cropping/correction to metadata.

Use the separate FL1-05 specimen as an instructional demonstration, not a new application shell or an approved rubric. Review and selectively adopt its teaching; its added fictional facts are documented.

## Pass 3 — integrate actual resources

The current sources now include actual FINLIT PDFs and 17 playable excerpt files; do not revert to the old “only transcripts are available” assumption. The original full source videos may still be outside this package: do not claim that a longer unprovided segment was reviewed or embedded.

For each selected source create a record with: source ID, original filename/hash, publisher, user-reported FINLIT adaptation permission, curriculum/lesson purpose, physical/printed page or excerpt timing, selected passage, current-fact check/date, accessible equivalent, view/open route, and reviewer status. Do not extend the reported FINLIT permission to unrelated publishers or embedded third-party assets automatically.

Implement a resource card at the moment the source is needed. It must tell the student exactly what to open, where to look, what to notice, what to do with it, and how to return. Retain the existing fictional-case reader separately.

For a permitted local PDF, support open-at-physical-page, readable zoom/scroll, keyboard access, a normal open/download fallback and an accessible text alternative. The PDF's former website controls are not course submission controls. For a website that cannot be framed, provide a scoped permitted local adaptation plus the original link, not an empty frame or an unsupported “embedded” claim. Test a deliberately blocked source and show the fallback.

The FINLIT PDFs are assignment/quiz captures, not a narrative textbook. Do not import all 71 as mandatory reading. Develop teaching around selected items. Inspect the actual page/content, not just the filename. Keep raw originals immutable; adapted student material should remove captured profile/navigation controls and irrelevant questions.

## Pass 4 — deliberate media repair

Keep the 17 FINLIT and six original video entries until each has a documented keep/recut/revise/replace decision. No blanket removal. Confirm meaningful start/end points and correct captions against the audio/visual sequence. Resolve person/number drift between clips and lessons.

The ~13-second phone excerpt is an introduction, not a full calculation lesson. The entrepreneurship VTT contains wording that changes or obscures meaning; review against the original audio before correcting. For new/revised demonstrations, show the same source document and calculation that the learner will use. Include equivalent text and captions; log whether audio quality and synchronization were actually listened to/reviewed.

## Pass 5 — align assessment and the student route

Publish complete student A1–A7 briefs and criteria at the appropriate point, or provide tested links to the actual Brightspace tasks. Do not leave those briefs solely in teacher metadata. Provide a full fallback baseline for the final Morgan challenge when a learner uses the supplied fictional route.

The current A3 simulation does not establish authentic participation. Preserve that distinction and the school approval/verification gate. Do not mark the local condensed CO1-SP04 ledger as independently verified provincial text. Obtain a stable official curriculum export before certifying complete KUSP alignment.

Reassess the need for adjacent tasks that ask for the same reflection. In FL4-03 versus FL4-05, deliberately escalate the exposure types and require a revised response rather than another copied checklist. In practice, retain useful retrieval but add performance of the skill where repeated recognition questions dominate.

## Acceptance gates

### A. Cold learner walkthrough

For every repaired lesson, a reviewer who did not write it completes the learner path using only what a student can see and the explicitly allowed sources. Record each stop: unknown term, missing number, unclear person, unmodelled action, inaccessible source, contradictory instruction or ambiguous expected output. The lesson—not a private explanation—must resolve the stop. Follow with representative Grade 10 student trials before release.

### B. Source and scenario consistency

Export a per-lesson manifest linking each question to the facts and prior teaching required. Every independent numerical task must have all inputs and an independently computed result. Every narrative claim required of a student must have a supplied record or a clear permitted investigation route. Unknowns must be deliberate and assessable as unknowns.

### C. Technical regression

Test all routes, navigation/focus, case/resource readers, exact page opening, blocked-source fallback, media/transcripts, feedback, exports and keyboard/390-pixel views. Check inner table/dialog clipping as well as document width. Validate unchanged old-work restore, first-attempt history, multi-tab conflicts, and actual reload under the target origin. Do not infer storage, SCORM or Brightspace success from `set_content` rendering.

### D. Teacher review

Check prompt/field/rubric agreement, actual cognitive demand, response-space sufficiency, current rules and dates, assessment/key separation, and authentic-participation status. Record unresolved items without granting a release label.

## Return the implementation, not another plan

Deliver the changed source candidate, a focused diff, case/source manifest, updated lesson-by-lesson evidence matrix, numerical fixtures, accessibility/reader captures, state-preservation tests, and a confidence report separating executed checks from unrun Studio/SCORM/Brightspace/student-trial gates. Report any requirement that remains incomplete. Do not call the course instructionally complete merely because every route has text and six questions.
