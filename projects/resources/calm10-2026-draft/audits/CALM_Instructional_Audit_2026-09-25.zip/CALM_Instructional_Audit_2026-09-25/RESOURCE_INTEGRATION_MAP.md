# Source-to-lesson integration map

This map separates actual source content from proposed instructional use. FINLIT adaptation permission is recorded as reported by Dean. Original PDFs and supplied videos remain immutable. An external original-source URL is not automatically a permission to reproduce unrelated material.

The new `Archive(1).zip` contains 71 PDF files (36 assignments, 35 quizzes), 233 physical pages, plus saved-web material. The current large course archive contains seventeen FINLIT excerpts and six original demonstrations. The PDFs below were inspected in text; the phone, deductions and compounding first pages were also inspected visually. This is not blanket content/currency approval of the collection.

| Resource / exact locator | What it actually supplies | Recommended use and necessary teaching | Proposed route |
|---|---|---|---|
| Career Planning Assignment 3.6, physical p1 Q1–2; SHA begins `252a80c93d53` | Reflection on self-assessment tools and prioritizing career options | Use after a complete evidence card and route comparison. Model how a survey suggestion becomes a research question; do not make it a career verdict. | CE1-01, CE1-03 |
| Decision Making–Key Steps Assignment 2.6, physical p1 Q1–2 and p2 Q4; `ede0020e0e6d` | Prompts applying previously taught decision steps to training, careers and a concert | Supply the actual steps and a fully worked case, then a partial decision table. Selected original question can become transfer; it is not the explanation itself. | CE1-03, FL1-02 |
| Contributions of Entrepreneurs Assignment 4.2, physical p1 Q3; `fcccf2eb7962` | Identifying a community need, want or problem | Provide a fictional customer brief and cost sheet first. Develop one small venture with clear trade-offs, then use the community-need question as supported investigation. | CE1-06 |
| Tips for Preparing a Resume Assignment 3.8, physical p1 Q1–2; `5a1c077f4353` | A hypothetical job/resume task and selecting resume guidance from linked material | Show a posting, experience record, annotated resume and a completed truthful skill statement. This does not by itself demonstrate an interview response. | CO1-01, supporting CO1-03 |
| Paycheque Deductions Assignment 3.5, physical p1 Q1–3; `76ae2891a946` | EI/CPP/CPP Investments research; a suggested survey of other people | Keep as selected extension after pay-stub teaching. Do not require private family data or access to other people. It does not supply a pay stub or gross-to-net walkthrough. | FL1-01 extension |
| Smartphones and Plans Assignment 5.3, physical p1 Q1–2; `e76b36144f4d` | Research comparing phone features and costs | Reuse the comparison purpose. Teach twelve-month service/device arithmetic with complete supplied offers. The source does not provide the lesson's plan prices. Q3 parental rules need not become a required contract task. | FL1-05 |
| Why Borrow Money Assignment 6.1, physical p1 Q1–2; `889547e1b092` | Payday-loan and line-of-credit research | Explain lending terms first and provide bounded dated source records. Model a comparison before independent research; verify current rules and do not ask students to seek actual credit. | FL2-01, FL2-05 |
| How Financial Institutions Work Assignment 1.3, physical p2 Q4–6; `124983aedd96` | Interest-rate spread, bank-failure history and CDIC research | Select the banking/protection idea only where it fits. Teach an accessible account/product distinction first. Verify current protection rules rather than importing an unsourced limit. | FL3-03 extension |
| The Magic of Compounding Assignment 7.1, physical p1 Q3 continuing p2; `125a0a2d3394` | $500 initial saving, different contribution levels and a hypothetical 5% return over time | First show what earns interest in the first periods. Use controlled changes to one input and explain assumed return versus guarantee. The larger retirement-calculator task is not a substitute for basic teaching. | FL3-01, FL3-06 |
| Investing Money Assignment 7.3, physical p1 Q1–2; `1c0ca45bcb91` | Hypothetical $100,000 portfolio and observing changes over a month; institution comparison | Use a supplied, clearly labelled historical or fictional sequence before asking learners to investigate changes. Do not infer risk from a single month or impose a month-long live-data wait without planning. | FL3-03, FL3-06 |
| Avoiding Frauds and Scams Quiz, physical p1 Q1 and p2 Q3–4; `919e3701e8f7` | Video-recall questions about phone contact, identity theft and solicitation | Do not adopt the blanket phone-contact premise as current fact. Create an evidence-based verification task; preserve the current course's accurate distinction that genuine CRA calls are possible. | FL4-02, FL4-05 |
| Saved Needs/Wants web activity in Archive(1).zip | Exported HTML, supporting files and scripts | Inspect code/content, remove obsolete account/submit/tracking dependencies, and adapt only the pedagogical interaction if useful. Not executed or approved in this audit. | FL1-02, optional |

## Lesson-linked external sources: selected repairs

| Lesson | Existing situation | Proposed integration |
|---|---|---|
| CO2-01 | Appropriate Alberta link, but worked application of the rule is incomplete | Put “Employees aged 15 to 17” beside the supplied shift. Read age → sector → time → supervision together. Explain scope exceptions and complete the decision. |
| FL1-01 | ALIS pay-stub link exists at the end | Move its relevant explanation/example to the point where the fictional stub is read. Show the reader where hours, earnings, deductions and net appear. |
| FL1-05 | Correct CRTC destination, too broad for novice use | Specify Section C, Critical Information Summary; connect the listed fields to Maya's missing charges/terms. Keep a normal open-in-browser link and a short accessible paraphrase. |
| FL3-04 | The inflation lesson ends with a registered-plan/CRA source mission | Use the Bank of Canada inflation explanation for the nominal-versus-basket distinction. Keep registered-plan material in the account/goal lesson instead. |
| FL4-02 | Much of the case concerns CRA, but its source link is e-transfer guidance | Add the actual CRA contact-verification/recognize-scam section beside the caller model; retain e-transfer guidance for the bank-transfer case. |
| CE1-02/04 | Broad ALIS occupation entry points | Choose a specific current occupation profile and source fields for the worked reading; let independent research start from a directory only after the method has been demonstrated. |

## Media decisions grounded in the actual files

- FL1-05's FINLIT excerpt `0869641a49fe.mp4` is about 12.93 seconds. Retain as a needs/budget prompt or extend from an accessible full original after review. It is not the cost walkthrough.
- CE1-03's excerpt `2d68f4c8ee26.mp4` begins partway through numbered advice. Supply the missing frame/steps or recut at a meaningful boundary. Reconcile Riley/Leah.
- CE1-06's `54963081799d.vtt` includes fragments and suspect wording at approximately 8.2–13.0, 37.6–45.1 and 45.1–50.1 seconds. Verify the audio and visual before editing captions; do not assume the caption error was spoken.
- CO1-03's `331ef31a8aa7.mp4` concerns resume preparation. Use it for evidence selection and explicitly bridge to interviews; add a complete interview response demonstration.
- Original demonstrations should show the same case as the lesson, or be clearly introduced as a separate example. Preserve existing useful media while review is completed; no blanket deletion.

## Resource-card contract

Each selected item needs: source ID and hash; publisher/title; exact physical page or clip range; a one-sentence reading/watching purpose; one specific observation task; a working open/view route; accessible text/transcript; fallback when PDF/iframe/media is blocked; a clear return point; currency and reviewer status.

Original local PDFs can be shown with a PDF reader and a physical-page deep link. A webpage that blocks framing needs a permitted local adaptation and original-source link instead of a blank frame. Distinguish “fictional case,” “adapted reading” and “original source.” Do not label a clone of a case table as the original FINLIT resource.

The teaching specimen includes the actual phone PDF, a visual fallback and the existing short FINLIT excerpt to demonstrate placement. Actual native PDF rendering and media playback still need a target-browser test; in-memory document rendering is not that test.
