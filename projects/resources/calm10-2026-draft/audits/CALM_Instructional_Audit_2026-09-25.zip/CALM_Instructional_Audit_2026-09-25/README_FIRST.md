# CALM instructional audit — start here

Open `AUDIT.html` for the findings, `LESSON_REPAIR_MATRIX.html` for all 40 routes, and `RESOURCE_INTEGRATION_MAP.html` for actual-source use. `developer/CODEX_REPAIR_BRIEF.md` is the implementation brief.

`TEACHER_VOICE_SPECIMEN_SINGLE_FILE.html` demonstrates one fuller teacher-led lesson and embeds its source/media bytes. It is a separate proposal, not a production course. Reviewer-only additions and arithmetic are documented under `sample/REVIEWER_NOTES.md`. Do not distribute the audit ZIP as a student course; it contains teacher/developer information.

Original uploads and canonical course files were not edited. All current-source evidence comes from the 25 September candidate; do not use the older generated 24 September course as an interchangeable baseline. The full and compact current archives have 94 identical common workspace files.

Tests and inspection limits are stated in the audit. No full audio approval, legal/curriculum certification, Studio/SCORM/Brightspace validation, native PDF/media playback sign-off or representative student trial is claimed.
