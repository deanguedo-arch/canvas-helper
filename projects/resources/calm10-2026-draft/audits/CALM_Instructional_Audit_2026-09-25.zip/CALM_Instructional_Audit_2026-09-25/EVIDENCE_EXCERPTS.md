# Current-source evidence excerpts

These excerpts are from the reviewed 25 September canonical HTML. Locators are DOM selectors, not invented page numbers. They are evidence of the current candidate, not replacement teaching.

Canonical SHA-256: `faaf77777f2cffcf092e5f596ebdbda02ff01bb773be43cb13d04843d875652b`

## ce1-03 — Person/number continuity

**Locator:** `workspace/index.html → #ce1-03 .lesson-opening`

```text

Start with a decision
What would you do?
Leah wants work involving electrical systems. A paid apprenticeship and a longer school route both sound possible. Which comparison would help without pretending one route is best for everyone?

```

**Locator:** `workspace/index.html → #ce1-03 .source-document`

```text

Leah’s route sketch — fictional figures
Feature
Route A
Route B
Training
Paid work plus required training blocks
Two-year program
Known direct cost
$2,000 tools and fees
$4,500 tuition and fees
Travel estimate
$1,200
$600
Need to verify
Entry and employer availability
Program admission and credential relevance
These figures and routes are teaching examples, not current program prices or credential rules.

```

**Locator:** `workspace/index.html → #ce1-03 .worked`

```text

See a decision worked out
Use the case, then follow the steps
What are the stated direct costs?
Pause · example 1
Answer the question above using the case evidence. Then compare your reasoning with the model.
Open the full case ↑
Keep these details in view
Training
Route A:
Paid work plus required training blocks
Route B:
Two-year program
Known direct cost
Route A:
$2,000 tools and fees
Route B:
$4,500 tuition and fees
Selected facts from the full case above.
Now compare your answer with the model. Each numbered step shows what to notice, how to use it, and where the conclusion has a limit.
Route A: $2,000 + $1,200 = $3,200.
Route B: $4,500 + $600 = $5,100.
The $1,900 difference covers only listed costs, not earnings, living costs or future opportunity.
Check the common mistake:
A calculation is useful only when its scope is explicit.
Leah chooses Route A only because its direct cost is lower.
Pause · example 2
The situation changed. Decide what still holds and what you need to check before reading the model.
Open the full case ↑
Now compare your answer with the model. Each numbered step shows what to notice, how to use it, and where the conclusion has a limit.
Ask whether Route A actually grants access to the desired regulated role.
Check whether paid placements are available in Leah’s region.
Compare time, support needs and a backup if an employer place is unavailable.
Check the common mistake:
Cost alone cannot establish pathway fit.

```

## co1-03 — Missing disagreement record

**Locator:** `workspace/index.html → #co1-03 .source-document`

```text

Fictional interview notes
Answer
What the listener learns
I am good under pressure
A claim, but no observable example
A volunteer cancelled; I reallocated sign-in and welcomed arrivals
Situation and action
The line stayed short; next time I would train a backup before opening
Result and learning
The case is supplied for practice. Students may answer using this fictional record.

```

**Locator:** `workspace/index.html → #co1-03 .transfer-work`

```text

Use the idea in a new case
Make the decision yourself
A second interviewer asks about a team disagreement. Use the supplied event record to draft an answer that shows Rowan’s action, the team’s result and a limitation.
Record and revise two fictional interview answers using situation, action, result and learning, then write two role-research questions.
Saved as a draft in this browser. Open My Work to review or download your response.

```

## co1-04 — Clock mismatch

**Locator:** `workspace/index.html → #co1-04 .lesson-teaching`

```text

Learn
Build the idea
Triage by consequence and authority
In a busy shift, urgency is not the same as importance. Check immediate safety, deadlines, permissions and who can help. Rowan cannot disclose a visitor’s reservation merely because the person asks confidently. The activity setup has a known deadline; the printer failure may block it, but a safe alternative might exist. A good first response is to protect the record, alert the shift lead about the printer, and propose an achievable setup plan.
Make the decision visible
A short update to a
supervisor
should state the problem, what Rowan has already checked, a suggested next step and the help needed. ‘Everything is broken’ leaves the lead to investigate from scratch. ‘The printer stopped after one page; the 11 a.m. cards are not ready. I can use blank cards if you approve’ gives actionable information. Record what was decided so the next task is clear.
Learn from supplied feedback
The fictional shift lead notes that Rowan kept visitor information private and solved the activity setup, but waited too long to report the printer problem.
Feedback
is evidence about a behaviour in this scenario, not a judgement about Rowan’s worth or entire career. Compare the action with the result, choose one specific improvement, and test it in the next changed case. The complete shift record is in this lesson; no real workplace experience is needed to answer.
Use a simple priority test
When several tasks arrive, sort them by safety, privacy, deadline, and dependency. A task involving private records may have a strict permission boundary. An activity setup due soon may be urgent but can sometimes use an approved alternative. Ask what blocks other work and which decisions require supervisor authority. This is not a formula that replaces judgement; it gives a reasoned order and makes uncertainty visible. If safety is immediate, use the site procedure before trying to protect a deadline.
Review what the outcome actually shows
A busy shift can produce mixed evidence: a learner may protect confidential information and meet a setup deadline yet report equipment failure too late. Write each observation separately, then identify one behaviour to repeat and one to practise earlier. Avoid “I am bad under pressure,” which turns one case into a permanent identity. A useful next test is concrete: send a short supervisor update as soon as a blocker threatens the deadline, then record whether the new timing helped. When two tasks compete, tell the lead early if one cannot be completed safely or on time. A timely request lets the authorized person reset expectations.

```

**Locator:** `workspace/index.html → #co1-04 .source-document`

```text

Prairie Library Hub — 10:05 a.m. shift board
Event
Constraint
Possible action
Printer stops
Activity begins at 11 a.m.
Report and ask about approved backup
Visitor asks for another person’s reservation
Private record
Do not disclose; use approved identity process
Activity cards unfinished
Thirty-five minutes remain
Prioritize safe setup with lead guidance
Lead feedback at noon
Early report was needed
Revise communication timing
All events and feedback are fictional. The table provides every fact needed for the simulation.

```

## fl1-03 — Pay-frequency mismatch

**Locator:** `workspace/index.html → #fl1-03 .lesson-opening`

```text

Start with a decision
What would you do?
Sam’s fictional summer pay arrives every two weeks, but rent for a room, phone service, and a one-time course fee are due on different dates. A monthly total can balance on paper while cash runs short before payday.

```

**Locator:** `workspace/index.html → #fl1-03 .source-document`

```text

Sam’s fictional monthly plan and due-date strip
Document field
Value
Take-home income, paid on the 1st and 15th
$900 per month
Room share, due on the 1st
$420
Phone, due on the 8th
$45
Transit, spread across month
$80
Food contribution, flexible schedule
$180
Course fee, one-time and due on the 20th
$60
Goal: save toward a laptop
$70
Flexible recreation
$35
All dates, work hours, pay, expenses, and amounts are invented for practice. The pay shown is take-home income for this fictional calculation, not a real wage or cost-of-living estimate.

```

## fl1-05 — Missing subscription prices and usage profile

**Locator:** `workspace/index.html → #fl1-05 .transfer-work`

```text

Use the idea in a new case
Make the decision yourself
A fictional learner compares a music subscription with a student discount for six months followed by a regular price, against a free tier with limited offline access. State the comparison horizon, calculate only from supplied terms, and identify one non-price factor and one unknown condition that matter.
Create a comparison of two supplied fictional plans for a shared 12-month horizon. Calculate the total, test service fit against a fictional usage profile, and list terms to confirm before signing.
Saved as a draft in this browser. Open My Work to review or download your response.

```

## fl1-06 — Missing bicycle price

**Locator:** `workspace/index.html → #fl1-06 .transfer-work`

```text

Use the idea in a new case
Make the decision yourself
A fictional learner considers buying a used bicycle for a seasonal job. The purchase price is supplied, but a lock, repairs, and winter storage are not. Separate one-time and recurring costs, identify unknowns, and explain what must be true for the purchase to be practical.
Analyse a fictional major-purchase or move estimate. Separate one-time and recurring values, calculate known costs, flag unknowns, and recommend the next evidence to gather before a decision.
Saved as a draft in this browser. Open My Work to review or download your response.

```

## fl2-06 — Stress-case premise

**Locator:** `workspace/index.html → #fl2-06 .source-document`

```text

Fictional fixed and variable rate scenario card
Document field
Value
Principal and horizon
$5,000 over 24 months
Offer F
Fixed nominal annual rate 6%, compounded semi-annually for this model
Offer V starting scenario
Variable nominal annual rate 5% for first 12 months
Offer V stress scenario
Rate rises to 7% for remaining 12 months; payment recalculates over remaining term
Budget room for scheduled payment
$230/month in the fictional case
Fees and penalties
Not supplied
All principals, rates, periods, payments, and margins are invented stress-test assumptions, not current or expected market rates. For classroom comparison only, both offers use the same 24-month schedule and the stated equivalent monthly-rate calculation; real variable products may recalculate differently.

```

## fl3-05 — Incomplete two-goal transfer

**Locator:** `workspace/index.html → #fl3-05 .transfer-work`

```text

Use the idea in a new case
Make the decision yourself
In a new fictional case, a learner needs $300 in five months for a required course item and has $80 saved. They can set aside $35 per month. A separate $900 goal is due in two years. Build a brief plan for both goals. Calculate whether the near-term target is reached, identify the long-term gap under a no-growth assumption, and name two checks before choosing an account or product.
Create two fictional goals with different horizons. Show starting amounts, contributions, period totals, a cash-access need, and one plan change you would make if income, cost, or timing changed. State what account/product terms need verification.
Saved as a draft in this browser. Open My Work to review or download your response.

```

## fl3-06 — Event/deposit timeline

**Locator:** `workspace/index.html → #fl3-06 .lesson-teaching`

```text

Learn
Build the idea
Understand the evidence
A scenario test asks, “If this specified change occurs, what happens to the plan?” It is not a prediction. Name the baseline, alter one or two variables, recalculate, and explain the consequence. This isolates cause and effect. For example, use fictional market value $500 and compare three one-year outcomes: a 15% loss, no change, or a 6% increase. Applying those percentages gives $425, $500, and $530 before any fees, tax,
inflation
, contributions, or product rules. These are simple arithmetic illustrations, not expected outcomes or financial advice.
Make the calculation or comparison
The lesson’s simulator separates time horizon from uncertainty. Money required soon may have little time to recover from a decline; money intended for a distant goal can still lose value, and a longer timeline does not eliminate
risk
. A scenario is useful when it exposes consequences the student can tolerate or cannot tolerate. Never present the positive case as the normal result or the loss case as impossible. If a product has fees or withdrawals, those terms would need to be added from current verified documentation. Keep the basic calculator transparent so every student can reproduce it without trusting a black box.
Use the result carefully
Test cash flow too. Suppose a fictional learner begins with $200 for a goal and plans to contribute $25 per month for six months. The simple no-growth total is $350. If an $80 unexpected expense is paid from that same goal fund in month two, the remaining amount becomes $120 at that point. Six further deposits of $30 would add $180, producing $300, still below the original $350 target. The plan must change: amount, timeline, target, or another funding source. State which resource is actually available; do not count the same dollars for two goals.
Understand the evidence
A useful revision has a reason and a check date. If a short-term goal is underfunded, extending the date may be safer than taking more risk, but circumstances vary. If the need is essential and immediate, the student should seek a trusted adult or appropriate support instead of treating a classroom simulation as personal advice. The FINLIT compounding lesson can help students visualize how time and reinvested gains interact, but its later numerical examples must not be used as guaranteed growth or copied uncritically. This lesson uses the conceptual “snowball” segment only, then contrasts it with negative, flat, and positive scenarios.
Make the calculation or comparison
When reviewing a result, ask four questions: (1) What changed? (2) Which total or risk changed because of it? (3) What is the consequence if the original target date stays fixed? (4) What revision best fits the stated priorities? A strong response can say what remains unknown. It should also name the simplifications: no fees, taxes, inflation, contributions, or product-specific rules unless the scenario explicitly includes them. This habit makes a student’s reasoning inspectable and transferable to future information without claiming to forecast markets.

```

**Locator:** `workspace/index.html → #fl3-06 .source-document`

```text

Fictional scenario simulator inputs and outputs
Document field
Value
Starting illustrative value
$500.00
Loss scenario
−15% over one year → $425
Flat scenario
0% over one year → $500
Gain scenario
+6% over one year → $530
Goal cash-flow baseline
$200 start + $25 × 6 months = $350
Change event
$80 expense, then $30 × 6 months
Changed total
$200 − $80 + (6 × $30) = $300
Every value below is invented to practise scenario reasoning. The return percentages are hypothetical stress-test inputs, not forecasts, guaranteed rates, market history, or a recommended portfolio. No fees, tax, inflation, contribution, or product terms are included unless explicitly stated.

```

**Locator:** `workspace/index.html → #fl3-06 .worked`

```text

See a decision worked out
Use the case, then follow the steps
Compare three outcomes without selecting a forecast
Pause · example 1
Answer the question above using the case evidence. Then compare your reasoning with the model.
Open the full case ↑
Keep these details in view
Starting illustrative value
$500.00
Loss scenario
−15% over one year → $425
Selected facts from the full case above.
Now compare your answer with the model. Each numbered step shows what to notice, how to use it, and where the conclusion has a limit.
Start each scenario at the same fictional $500.
Loss case: a 15% decline means 0.15 × $500 = $75 lost; $500 − $75 = $425.
Flat case leaves the value at $500 before excluded costs. Gain case adds 0.06 × $500 = $30, giving $530.
Label every result illustrative. Compare what happens if the money is needed at the end of that one year.
Check the common mistake:
“The +6% case is the expected or promised result.” It is only one hypothetical input; the other outcomes demonstrate uncertainty.
Revise after an unexpected expense
Pause · example 2
The situation changed. Decide what still holds and what you need to check before reading the model.
Open the full case ↑
Now compare your answer with the model. Each numbered step shows what to notice, how to use it, and where the conclusion has a limit.
Baseline: $200 + six deposits of $25 = $350.
After the $80 expense, the fund has $200 − $80 = $120.
Six later deposits of $30 add $180, so the revised balance is $300.
Compare $300 with the $350 target: the remaining gap is $50. Propose a feasible next step and disclose its trade-off.
Check the common mistake:
Counting the original six deposits and the later six deposits together double-counts the timeline; the changed case specifies six future deposits after the expense.

```

## FL2-06 practice premise

`workspace/index.html → [data-practice-id="fl2-06-q6"]`

```text

The fictional payment exceeds the $230 margin in one stress scenario. What conclusion is supported?
The borrower must accept anyway
The offer is illegal
It creates a modeled shortfall under that scenario and deserves investigation
The actual household will certainly have the same result

```

## Reader implementation

`workspace/case-reader.js` uses `source.cloneNode(true)` on the lesson `.source-document` and puts that clone in the dialog. It does not fetch or embed an original PDF.

## Mobile evidence

The sampled 390px reader screenshot shows only part of the wider table at a time. CSS sets `.source-document table` to a 480px minimum width with an inner horizontal-scroll container. Document-level width success therefore does not prove all source values are visible without sideways scrolling. Add a responsive card/table alternative or a clear scroll affordance and keyboard-accessible handling.