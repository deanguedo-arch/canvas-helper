# Current source/provenance boundary

The reconciled unit retains the eight-section NXT Math 10C Chapter 3 sequence and newly authored teaching/question bank from the previous unit artifact. The historical per-section PDF/workbook locations and seven optional CBE video references are in `reference/PRIOR_UNIT_SOURCE_AND_SCOPE.md`. That file describes the prior artifact and does not govern this build's new trig/state/testing status. This pass did not redo the source-course audit or verify every external video.

The authoritative prior plan is preserved exactly in `reference/RECONCILED_MASTER_PLAN_v0.3.md`. The current user's explicit full-unit request is reconciled through `RECONCILIATION_v0.4.md`. No unchanged original planning fixture is silently broadened.

The optional triangle contrast is now implemented and remains outside the Chapter 3 completion count. Its authored diagram, labels and givens are local; it is not copied science content. System-font fallbacks preserve a working standalone page without distributing font files. Routine teaching remains canonical source HTML; generated activity/report displays are runtime owned.

Original course ZIPs, textbook PDFs, formal teacher keys, shared credentials, learner data and fonts are excluded. Current curriculum/source permissions and actual course delivery acceptance remain teacher/tenant decisions, not conclusions from a source-layout match.
