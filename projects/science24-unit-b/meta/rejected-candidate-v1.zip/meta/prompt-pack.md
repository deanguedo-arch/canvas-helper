# Science 24 Unit B review candidate

- Project: `science24-unit-b`
- Workflow: Brightspace conversion; Pilot 3 presentation reference
- Status: blocked, previewable; Studio Edit and export disabled
- Canonical learner source: `workspace/index.html`, `course-data.json` (compile `course-data.js`), `main.js`, `state-store.js`, `styles.css`, `assets/**`
- Immutable source: `projects/resources/science24-unit-a/_sources/3d6a4d094ca3ebee56a750117dcbdc33a4e889ea1396bf2306bd544225b2de02.zip` (shared with Unit A to avoid three redundant archive copies)

## Editing rules

Edit the canonical workspace. Keep `s24-b-*` activity IDs and `science24-unit-b-review-v1` browser save namespace stable. Static lesson copy is HTML with edit keys. The textbook page picker, vocabulary Frayer, saved-work list and checks are runtime rendered and marked Annotation only where appropriate. Brightspace quiz and hidden test remain outside learner pages. Online checks are authored formative work. Source mapping and limitations are in `source-review.json`.

## Next review

Inspect all eight lessons, source PDF links, textbook practice, Frayer saving and mobile layout against Unit A and Biology 30 Pilot 3. Guided notes are OCR-mapped by chapter in `guided-notes-ocr.json`; inspect the original PDF for exact diagrams and wording before making any native conversion claim. Run rollout readiness and teacher review on an exact frozen candidate before activation.
